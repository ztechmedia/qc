# MySQL dump of database 'acc_wmi_2020_01' on host 'localhost'
# Backup Date and Time: 2021-01-07 12:17
# Built by FrontAccounting 2.4.8
# http://frontaccounting.com
# Company: wmi01
# User: Administrator

# Compatibility: 2.4.1


SET NAMES latin1;


### Structure of table `0_areas` ###

DROP TABLE IF EXISTS `0_areas`;

CREATE TABLE `0_areas` (
  `area_code` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`area_code`),
  UNIQUE KEY `description` (`description`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_areas` ###

INSERT INTO `0_areas` VALUES
('1', 'Global', '0');

### Structure of table `0_attachments` ###

DROP TABLE IF EXISTS `0_attachments`;

CREATE TABLE `0_attachments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type_no` int(11) NOT NULL DEFAULT '0',
  `trans_no` int(11) NOT NULL DEFAULT '0',
  `unique_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tran_date` date NOT NULL DEFAULT '0000-00-00',
  `filename` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `filetype` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `type_no` (`type_no`,`trans_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_attachments` ###


### Structure of table `0_audit_trail` ###

DROP TABLE IF EXISTS `0_audit_trail`;

CREATE TABLE `0_audit_trail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` smallint(6) unsigned NOT NULL DEFAULT '0',
  `trans_no` int(11) unsigned NOT NULL DEFAULT '0',
  `user` smallint(6) unsigned NOT NULL DEFAULT '0',
  `stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `description` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fiscal_year` int(11) NOT NULL DEFAULT '0',
  `gl_date` date NOT NULL DEFAULT '0000-00-00',
  `gl_seq` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Seq` (`fiscal_year`,`gl_date`,`gl_seq`),
  KEY `Type_and_Number` (`type`,`trans_no`)
) ENGINE=InnoDB AUTO_INCREMENT=222 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_audit_trail` ###

INSERT INTO `0_audit_trail` VALUES
('1', '18', '1', '1', '2021-01-04 11:43:27', NULL, '4', '2020-12-22', '0'),
('2', '25', '1', '1', '2021-01-07 18:17:40', NULL, '4', '2020-12-28', '0'),
('3', '20', '1', '1', '2021-01-04 12:41:38', NULL, '5', '2021-01-04', NULL),
('4', '18', '2', '2', '2021-01-04 13:32:28', NULL, '5', '2021-04-01', NULL),
('5', '20', '1', '1', '2021-01-04 12:41:38', 'Voided.\n', '5', '2021-01-04', '0'),
('6', '18', '3', '1', '2021-01-04 13:04:34', NULL, '4', '2020-12-22', '0'),
('7', '25', '2', '1', '2021-01-04 13:10:54', NULL, '5', '2021-01-04', '0'),
('8', '20', '2', '1', '2021-01-04 13:13:26', NULL, '5', '2021-01-04', '0'),
('9', '18', '2', '1', '2021-01-04 13:32:28', 'Updated.', '5', '2021-01-04', '0'),
('10', '18', '4', '1', '2021-01-04 14:17:23', NULL, '5', '2021-01-04', NULL),
('11', '18', '4', '1', '2021-01-04 14:17:59', 'Updated.', '5', '2021-01-04', NULL),
('12', '18', '4', '1', '2021-01-04 14:18:28', 'Updated.', '5', '2021-01-04', NULL),
('13', '18', '4', '1', '2021-01-04 17:19:00', 'Updated.', '5', '2021-01-04', NULL),
('14', '18', '5', '1', '2021-01-04 14:53:27', NULL, '4', '2020-03-12', '0'),
('15', '18', '6', '1', '2021-01-04 14:54:43', NULL, '4', '2020-03-12', '0'),
('16', '18', '7', '1', '2021-01-04 14:58:25', NULL, '5', '2021-01-01', '0'),
('17', '18', '8', '1', '2021-01-04 15:02:29', NULL, '5', '2021-01-01', '0'),
('18', '18', '9', '1', '2021-01-04 15:10:26', NULL, '5', '2021-01-01', '0'),
('19', '18', '10', '1', '2021-01-05 08:39:46', NULL, '5', '2021-04-01', NULL),
('20', '20', '3', '1', '2021-01-04 16:24:46', NULL, '5', '2021-04-01', NULL),
('21', '18', '11', '1', '2021-01-04 16:14:12', NULL, '5', '2021-01-04', '0'),
('22', '20', '4', '1', '2021-01-04 16:23:29', NULL, '5', '2021-01-04', '0'),
('23', '20', '3', '1', '2021-01-04 16:24:46', 'Voided.\nDocument reentered.', '5', '2021-01-04', '0'),
('24', '20', '5', '1', '2021-01-04 16:24:46', NULL, '5', '2021-01-04', '0'),
('25', '18', '12', '1', '2021-01-04 17:19:36', NULL, '5', '2021-01-04', NULL),
('26', '18', '13', '1', '2021-01-04 16:48:35', NULL, '5', '2021-01-04', '0'),
('27', '18', '14', '1', '2021-01-04 17:19:50', NULL, '5', '2021-01-04', NULL),
('28', '18', '15', '1', '2021-01-05 08:42:55', NULL, '5', '2021-04-01', NULL),
('29', '18', '16', '1', '2021-01-05 08:47:58', NULL, '5', '2021-04-01', NULL),
('30', '18', '4', '1', '2021-01-05 08:40:17', 'Updated.', '5', '2021-01-04', NULL),
('31', '18', '12', '1', '2021-01-05 08:41:02', 'Updated.', '5', '2021-01-04', NULL),
('32', '18', '14', '1', '2021-01-05 08:40:36', 'Updated.', '5', '2021-01-04', NULL),
('33', '18', '17', '1', '2021-01-04 17:32:20', NULL, '4', '2020-09-11', '0'),
('34', '18', '10', '1', '2021-01-05 08:39:46', 'Updated.', '5', '2021-01-05', '0'),
('35', '18', '4', '1', '2021-01-05 08:40:17', 'Updated.', '5', '2021-01-05', '0'),
('36', '18', '14', '1', '2021-01-05 08:40:36', 'Updated.', '5', '2021-01-05', '0'),
('37', '18', '12', '1', '2021-01-05 08:41:02', 'Updated.', '5', '2021-01-05', '0'),
('38', '18', '15', '2', '2021-01-05 08:42:55', 'Updated.', '5', '2021-01-05', '0'),
('39', '18', '16', '1', '2021-01-05 08:47:58', 'Updated.', '5', '2021-01-05', '0'),
('40', '18', '18', '1', '2021-01-05 08:53:46', NULL, '5', '2021-01-05', '0'),
('41', '18', '19', '1', '2021-01-05 09:54:42', NULL, '5', '2021-01-05', NULL),
('42', '18', '19', '1', '2021-01-05 09:54:42', 'Updated.', '5', '2021-01-05', '0'),
('43', '18', '20', '1', '2021-01-05 11:42:16', NULL, '5', '2021-01-05', '0'),
('44', '18', '21', '1', '2021-01-05 14:24:44', NULL, '5', '2021-01-05', NULL),
('45', '18', '21', '1', '2021-01-05 14:24:44', 'Updated.', '5', '2021-01-05', '0'),
('46', '18', '22', '1', '2021-01-05 14:25:57', NULL, '4', '2020-11-18', '0'),
('47', '18', '23', '1', '2021-01-05 14:29:08', NULL, '4', '2020-11-18', '0'),
('48', '18', '24', '1', '2021-01-05 14:38:45', NULL, '5', '2021-01-05', NULL),
('49', '18', '24', '1', '2021-01-05 14:38:45', 'Updated.', '5', '2021-01-05', '0'),
('50', '18', '25', '1', '2021-01-05 14:47:42', NULL, '4', '2020-11-30', '0'),
('51', '18', '26', '1', '2021-01-05 14:56:55', NULL, '4', '2020-12-22', '0'),
('52', '18', '27', '1', '2021-01-05 15:04:22', NULL, '5', '2021-01-05', NULL),
('53', '18', '27', '1', '2021-01-05 15:04:22', 'Updated.', '5', '2021-01-05', '0'),
('54', '18', '28', '1', '2021-01-05 15:05:17', NULL, '4', '2020-12-23', '0'),
('55', '18', '29', '1', '2021-01-05 15:07:44', NULL, '4', '2020-12-16', '0'),
('56', '25', '3', '1', '2021-01-05 15:16:27', NULL, '5', '2021-01-04', '0'),
('57', '25', '4', '1', '2021-01-05 15:22:45', NULL, '5', '2021-01-05', '0'),
('58', '20', '6', '1', '2021-01-05 15:23:32', NULL, '5', '2021-01-05', '0'),
('59', '18', '30', '1', '2021-01-05 15:28:37', NULL, '5', '2021-01-05', '0'),
('60', '25', '5', '1', '2021-01-05 16:03:32', NULL, '5', '2021-01-05', '0'),
('61', '20', '7', '1', '2021-01-05 16:04:09', NULL, '5', '2021-01-05', '0'),
('62', '18', '31', '1', '2021-01-05 16:08:46', NULL, '4', '2020-10-28', '0'),
('63', '25', '6', '1', '2021-01-05 16:10:48', NULL, '5', '2021-01-05', '0'),
('64', '20', '8', '1', '2021-01-05 16:11:28', NULL, '5', '2021-01-05', '0'),
('65', '25', '7', '1', '2021-01-05 16:19:47', NULL, '5', '2021-01-05', '0'),
('66', '20', '9', '1', '2021-01-05 16:20:15', NULL, '5', '2021-01-05', '0'),
('67', '25', '8', '1', '2021-01-05 16:21:58', NULL, '5', '2021-01-05', '0'),
('68', '20', '10', '1', '2021-01-05 16:22:30', NULL, '5', '2021-01-05', '0'),
('69', '25', '9', '1', '2021-01-05 16:30:19', NULL, '5', '2021-01-05', '0'),
('70', '20', '11', '1', '2021-01-05 16:31:11', NULL, '5', '2021-01-05', '0'),
('71', '25', '10', '1', '2021-01-05 16:33:00', NULL, '5', '2021-01-05', '0'),
('72', '20', '12', '1', '2021-01-05 16:35:06', NULL, '5', '2021-01-05', '0'),
('73', '25', '11', '1', '2021-01-05 16:36:36', NULL, '5', '2021-01-05', '0'),
('74', '20', '13', '1', '2021-01-05 16:37:02', NULL, '5', '2021-01-05', '0'),
('75', '25', '12', '1', '2021-01-05 16:39:41', NULL, '5', '2021-01-05', '0'),
('76', '20', '14', '1', '2021-01-05 16:40:57', NULL, '5', '2021-01-05', '0'),
('77', '25', '13', '1', '2021-01-05 16:42:22', NULL, '5', '2021-01-05', '0'),
('78', '30', '1', '1', '2021-01-05 16:42:30', NULL, '4', '2020-12-22', '0'),
('79', '20', '15', '1', '2021-01-05 16:43:12', NULL, '5', '2021-01-05', '0'),
('80', '25', '14', '1', '2021-01-05 16:48:30', NULL, '5', '2021-01-05', '0'),
('81', '20', '16', '1', '2021-01-05 16:48:59', NULL, '5', '2021-01-05', '0'),
('82', '30', '2', '1', '2021-01-05 16:49:25', NULL, '4', '2020-12-19', '0'),
('83', '30', '3', '1', '2021-01-05 16:52:43', NULL, '4', '2020-12-18', '0'),
('84', '30', '4', '1', '2021-01-05 16:55:42', NULL, '4', '2020-12-18', '0'),
('85', '25', '15', '1', '2021-01-05 16:55:53', NULL, '5', '2021-01-05', '0'),
('86', '20', '17', '1', '2021-01-05 16:56:19', NULL, '5', '2021-01-05', '0'),
('87', '25', '16', '1', '2021-01-05 16:57:44', NULL, '5', '2021-01-05', '0'),
('88', '20', '18', '1', '2021-01-05 16:58:09', NULL, '5', '2021-01-05', '0'),
('89', '30', '5', '1', '2021-01-05 16:58:15', NULL, '4', '2020-12-16', '0'),
('90', '30', '6', '1', '2021-01-05 17:01:43', NULL, '4', '2020-12-16', '0'),
('91', '30', '7', '1', '2021-01-05 17:10:43', NULL, '4', '2020-12-15', '0'),
('92', '30', '8', '1', '2021-01-05 17:17:12', NULL, '4', '2020-12-15', '0'),
('93', '25', '17', '1', '2021-01-06 08:04:35', NULL, '5', '2021-01-06', '0'),
('94', '20', '19', '1', '2021-01-06 08:05:18', NULL, '5', '2021-01-06', '0'),
('95', '18', '32', '1', '2021-01-06 08:25:57', NULL, '5', '2021-01-06', '0'),
('96', '25', '18', '1', '2021-01-06 08:25:57', NULL, '5', '2021-01-06', '0'),
('97', '20', '20', '1', '2021-01-06 08:26:42', NULL, '5', '2021-01-06', '0'),
('98', '30', '9', '1', '2021-01-06 08:41:18', NULL, '4', '2020-11-20', '0'),
('99', '30', '10', '1', '2021-01-07 12:06:45', NULL, '4', '2020-11-25', NULL),
('100', '30', '11', '1', '2021-01-06 08:53:28', NULL, '4', '2020-10-23', '0'),
('101', '30', '12', '1', '2021-01-06 08:56:15', NULL, '4', '2020-10-07', '0'),
('102', '30', '13', '1', '2021-01-06 08:58:26', NULL, '4', '2020-11-20', '0'),
('103', '30', '14', '1', '2021-01-06 09:00:33', NULL, '4', '2020-10-02', '0'),
('104', '30', '15', '1', '2021-01-06 09:26:58', NULL, '4', '2020-10-01', '0'),
('105', '30', '16', '1', '2021-01-07 11:43:54', NULL, '5', '2020-11-30', NULL),
('106', '30', '17', '1', '2021-01-06 09:38:11', NULL, '4', '2020-03-19', '0'),
('107', '30', '18', '1', '2021-01-06 09:41:22', NULL, '4', '2020-06-12', '0'),
('108', '30', '19', '1', '2021-01-06 09:47:26', NULL, '4', '2020-10-22', '0'),
('109', '18', '33', '1', '2021-01-06 10:12:16', NULL, '5', '2021-01-06', NULL),
('110', '30', '20', '1', '2021-01-06 09:49:41', NULL, '4', '2020-11-04', '0'),
('111', '30', '21', '1', '2021-01-06 09:54:13', NULL, '4', '2020-03-19', '0'),
('112', '30', '22', '1', '2021-01-06 09:57:15', NULL, '4', '2020-02-29', '0'),
('113', '30', '23', '1', '2021-01-06 10:00:30', NULL, '4', '2020-03-19', '0'),
('114', '30', '24', '1', '2021-01-06 10:02:18', NULL, '4', '2020-11-05', '0'),
('115', '30', '25', '1', '2021-01-06 10:04:49', NULL, '4', '2020-10-01', '0'),
('116', '30', '26', '1', '2021-01-06 10:09:10', NULL, '4', '2020-11-27', '0'),
('117', '18', '33', '1', '2021-01-06 10:12:16', 'Updated.', '5', '2021-01-06', '0'),
('118', '30', '27', '1', '2021-01-06 10:14:26', NULL, '4', '2020-12-09', '0'),
('119', '30', '28', '1', '2021-01-06 10:15:59', NULL, '4', '2020-07-13', '0'),
('120', '30', '29', '1', '2021-01-06 10:20:41', NULL, '4', '2020-11-05', '0'),
('121', '30', '30', '1', '2021-01-06 10:22:36', NULL, '4', '2020-10-21', '0'),
('122', '18', '34', '1', '2021-01-06 10:34:08', NULL, '5', '2021-01-06', NULL),
('123', '18', '34', '1', '2021-01-06 10:34:08', 'Updated.', '5', '2021-01-06', '0'),
('124', '20', '21', '1', '2021-01-06 11:34:52', NULL, '5', '2021-01-01', '0'),
('125', '20', '22', '1', '2021-01-06 11:39:17', NULL, '5', '2021-01-01', '0'),
('126', '20', '23', '1', '2021-01-06 11:44:56', NULL, '5', '2021-01-01', '0'),
('127', '20', '24', '1', '2021-01-06 11:49:50', NULL, '5', '2021-01-01', '0'),
('128', '20', '25', '1', '2021-01-06 11:50:57', NULL, '5', '2021-01-01', '0'),
('129', '20', '26', '1', '2021-01-06 11:53:27', NULL, '5', '2021-01-01', '0'),
('130', '20', '27', '1', '2021-01-06 11:58:13', NULL, '5', '2021-01-01', NULL),
('131', '20', '27', '1', '2021-01-06 11:58:13', 'Voided.\n', '5', '2021-01-06', '0'),
('132', '20', '28', '1', '2021-01-06 11:59:19', NULL, '5', '2021-01-01', '0'),
('133', '20', '29', '1', '2021-01-06 12:00:10', NULL, '5', '2021-01-01', '0'),
('134', '20', '30', '1', '2021-01-06 12:00:44', NULL, '5', '2021-01-01', '0'),
('135', '20', '31', '1', '2021-01-06 12:41:46', NULL, '5', '2021-01-01', '0'),
('136', '20', '32', '1', '2021-01-06 12:43:35', NULL, '5', '2021-01-01', '0'),
('137', '20', '33', '1', '2021-01-06 13:00:10', NULL, '5', '2021-01-01', '0'),
('138', '20', '34', '1', '2021-01-06 13:00:51', NULL, '5', '2021-01-01', '0'),
('139', '20', '35', '1', '2021-01-06 13:01:22', NULL, '5', '2021-01-01', '0'),
('140', '20', '36', '1', '2021-01-06 13:14:01', NULL, '5', '2021-01-01', '0'),
('141', '20', '37', '1', '2021-01-06 13:15:02', NULL, '5', '2021-01-01', '0'),
('142', '20', '38', '1', '2021-01-06 13:15:46', NULL, '5', '2021-01-01', '0'),
('143', '20', '39', '1', '2021-01-06 13:16:59', NULL, '5', '2021-01-01', '0'),
('144', '20', '40', '1', '2021-01-06 13:20:37', NULL, '5', '2021-01-01', '0'),
('145', '20', '41', '1', '2021-01-06 13:22:33', NULL, '5', '2021-01-01', '0'),
('146', '20', '42', '1', '2021-01-06 13:24:31', NULL, '5', '2021-01-01', '0'),
('147', '20', '43', '1', '2021-01-06 13:27:00', NULL, '5', '2021-01-01', '0'),
('148', '20', '44', '1', '2021-01-06 13:31:08', NULL, '5', '2021-01-01', '0'),
('149', '20', '45', '1', '2021-01-06 13:32:17', NULL, '5', '2021-01-01', '0'),
('150', '20', '46', '1', '2021-01-06 13:34:42', NULL, '5', '2021-01-01', '0'),
('151', '20', '47', '1', '2021-01-06 13:37:05', NULL, '5', '2021-01-01', '0'),
('152', '20', '48', '1', '2021-01-06 13:37:51', NULL, '5', '2021-01-01', '0'),
('153', '20', '49', '1', '2021-01-06 13:40:07', NULL, '5', '2021-01-01', '0'),
('154', '20', '50', '1', '2021-01-06 13:41:03', NULL, '5', '2021-01-01', '0'),
('155', '20', '51', '1', '2021-01-06 13:44:15', NULL, '5', '2021-01-01', '0'),
('156', '18', '35', '1', '2021-01-06 14:02:25', NULL, '5', '2021-01-06', NULL),
('157', '18', '35', '1', '2021-01-06 14:02:25', 'Updated.', '5', '2021-01-06', '0'),
('158', '20', '52', '1', '2021-01-06 14:05:47', NULL, '5', '2021-01-01', '0'),
('159', '20', '53', '1', '2021-01-06 14:06:39', NULL, '5', '2021-01-01', '0'),
('160', '20', '54', '1', '2021-01-06 14:07:19', NULL, '5', '2021-01-06', '0'),
('161', '20', '55', '1', '2021-01-06 14:08:06', NULL, '5', '2021-01-01', '0'),
('162', '20', '56', '1', '2021-01-06 14:08:37', NULL, '5', '2021-01-01', '0'),
('163', '20', '57', '1', '2021-01-06 14:09:11', NULL, '5', '2021-01-01', '0'),
('164', '20', '58', '1', '2021-01-06 14:09:41', NULL, '5', '2021-01-01', '0'),
('165', '20', '59', '1', '2021-01-06 14:12:24', NULL, '5', '2021-01-01', '0'),
('166', '20', '60', '1', '2021-01-06 14:15:16', NULL, '5', '2021-01-01', '0'),
('167', '20', '61', '1', '2021-01-06 14:23:55', NULL, '5', '2021-01-01', '0'),
('168', '18', '36', '1', '2021-01-06 15:18:13', NULL, '5', '2021-01-06', NULL),
('169', '18', '36', '1', '2021-01-06 15:18:13', 'Updated.', '5', '2021-01-06', '0'),
('170', '25', '19', '1', '2021-01-06 16:25:34', NULL, '5', '2021-01-06', '0'),
('171', '20', '62', '1', '2021-01-06 16:27:52', NULL, '5', '2021-01-06', '0'),
('172', '25', '20', '1', '2021-01-06 16:29:05', NULL, '5', '2021-01-06', '0'),
('173', '20', '63', '1', '2021-01-06 16:29:28', NULL, '5', '2021-01-06', '0'),
('174', '25', '21', '1', '2021-01-06 16:29:53', NULL, '5', '2021-01-06', '0'),
('175', '20', '64', '1', '2021-01-06 16:30:20', NULL, '5', '2021-01-06', '0'),
('176', '25', '22', '1', '2021-01-06 16:32:33', NULL, '5', '2021-01-06', '0'),
('177', '20', '65', '1', '2021-01-06 16:36:33', NULL, '5', '2021-01-06', '0'),
('178', '30', '31', '1', '2021-01-06 17:40:40', NULL, '4', '2020-10-23', '0'),
('179', '30', '32', '1', '2021-01-07 08:48:43', NULL, '4', '2020-02-29', '0'),
('180', '30', '33', '1', '2021-01-07 08:50:54', NULL, '4', '2020-06-18', '0'),
('181', '30', '34', '1', '2021-01-07 08:52:32', NULL, '4', '2020-04-07', '0'),
('182', '20', '66', '1', '2021-01-07 09:45:16', NULL, '5', '2021-01-01', NULL),
('183', '20', '67', '1', '2021-01-07 09:44:20', NULL, '5', '2021-01-01', '0'),
('184', '20', '66', '1', '2021-01-07 09:45:16', 'Voided.\n', '5', '2021-01-07', '0'),
('185', '20', '68', '1', '2021-01-07 09:46:04', NULL, '5', '2021-01-01', '0'),
('186', '20', '69', '1', '2021-01-07 09:50:46', NULL, '5', '2021-01-01', '0'),
('187', '18', '37', '1', '2021-01-07 09:58:46', NULL, '5', '2021-01-07', NULL),
('188', '18', '37', '1', '2021-01-07 09:58:46', 'Updated.', '5', '2021-01-07', '0'),
('189', '30', '16', '1', '2021-01-07 11:43:54', 'Updated.', '5', '2021-01-04', '0'),
('190', '13', '1', '1', '2021-01-07 11:48:33', NULL, '5', '2021-01-04', NULL),
('191', '10', '1', '1', '2021-01-07 11:48:09', NULL, '5', '2021-01-07', NULL),
('192', '10', '1', '1', '2021-01-07 11:48:09', 'Voided.\n', '5', '2021-01-07', '0'),
('193', '13', '1', '1', '2021-01-07 11:48:33', 'Updated.', '5', '2021-01-04', '0'),
('194', '10', '2', '1', '2021-01-07 11:49:01', NULL, '5', '2021-01-04', '0'),
('195', '13', '2', '1', '2021-01-07 11:54:33', NULL, '5', '2021-01-04', '0'),
('196', '10', '3', '1', '2021-01-07 11:55:14', NULL, '5', '2021-01-07', NULL),
('197', '10', '3', '1', '2021-01-07 11:55:14', 'Voided.\n', '5', '2021-01-07', '0'),
('198', '10', '4', '1', '2021-01-07 11:55:45', NULL, '5', '2021-01-04', '0'),
('199', '13', '3', '1', '2021-01-07 11:57:17', NULL, '5', '2021-01-04', '0'),
('200', '10', '5', '1', '2021-01-07 11:57:39', NULL, '5', '2021-01-04', '0'),
('201', '13', '4', '1', '2021-01-07 11:58:44', NULL, '5', '2021-01-04', '0'),
('202', '10', '6', '1', '2021-01-07 12:09:49', NULL, '5', '2021-01-07', NULL),
('203', '30', '10', '1', '2021-01-07 12:06:45', 'Updated.', '4', '2020-11-25', '0'),
('204', '13', '5', '1', '2021-01-07 12:07:14', NULL, '5', '2021-01-04', '0'),
('205', '10', '7', '1', '2021-01-07 12:09:53', NULL, '5', '2021-01-07', NULL),
('206', '10', '6', '1', '2021-01-07 12:09:49', 'Voided.\n', '5', '2021-01-07', '0'),
('207', '10', '7', '1', '2021-01-07 12:09:53', 'Voided.\n', '5', '2021-01-07', '0'),
('208', '10', '8', '1', '2021-01-07 12:10:32', NULL, '5', '2021-01-04', '0'),
('209', '10', '9', '1', '2021-01-07 12:12:17', NULL, '5', '2021-01-04', '0'),
('210', '13', '6', '1', '2021-01-07 12:15:58', NULL, '5', '2021-01-04', '0'),
('211', '10', '10', '1', '2021-01-07 12:16:20', NULL, '5', '2021-01-04', '0'),
('212', '13', '7', '1', '2021-01-07 13:28:58', NULL, '5', '2021-01-04', '0'),
('213', '10', '11', '1', '2021-01-07 13:31:04', NULL, '5', '2021-01-07', NULL),
('214', '10', '11', '1', '2021-01-07 13:31:04', 'Voided.\n', '5', '2021-01-07', '0'),
('215', '10', '12', '1', '2021-01-07 13:31:36', NULL, '5', '2021-01-04', '0'),
('216', '13', '8', '1', '2021-01-07 13:33:09', NULL, '5', '2021-01-04', '0'),
('217', '10', '13', '1', '2021-01-07 13:33:44', NULL, '5', '2021-01-04', '0'),
('218', '13', '9', '1', '2021-01-07 13:37:01', NULL, '5', '2021-01-04', '0'),
('219', '10', '14', '1', '2021-01-07 13:37:24', NULL, '5', '2021-01-04', '0'),
('220', '18', '38', '1', '2021-01-07 15:18:59', NULL, '5', '2021-01-07', NULL),
('221', '18', '38', '1', '2021-01-07 15:18:59', 'Updated.', '5', '2021-01-07', '0');

### Structure of table `0_bank_accounts` ###

DROP TABLE IF EXISTS `0_bank_accounts`;

CREATE TABLE `0_bank_accounts` (
  `account_code` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `account_type` smallint(6) NOT NULL DEFAULT '0',
  `bank_account_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bank_account_number` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bank_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bank_address` tinytext COLLATE utf8_unicode_ci,
  `bank_curr_code` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_curr_act` tinyint(1) NOT NULL DEFAULT '0',
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `bank_charge_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_reconciled_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ending_reconcile_balance` double NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `bank_account_name` (`bank_account_name`),
  KEY `bank_account_number` (`bank_account_number`),
  KEY `account_code` (`account_code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_bank_accounts` ###

INSERT INTO `0_bank_accounts` VALUES
('1100', '3', 'Kas Kecil', 'N/A', 'N/A', NULL, 'IDR', '0', '1', '8101', '0000-00-00 00:00:00', '0', '0'),
('1101', '3', 'Kas USD', '', '', NULL, 'USD', '0', '2', '8101', '0000-00-00 00:00:00', '0', '0'),
('1110', '0', 'Bank BCA IDR 161.302.868.8', '', '', NULL, 'IDR', '0', '3', '8101', '0000-00-00 00:00:00', '0', '0'),
('1111', '0', 'BANK MANDIRI IDR 125.00.1338983.8', '', '', NULL, 'IDR', '0', '4', '8101', '0000-00-00 00:00:00', '0', '0'),
('1112', '0', 'Bank BCA USD 161.250.5050', '', '', NULL, 'USD', '0', '5', '8101', '0000-00-00 00:00:00', '0', '0'),
('1113', '0', 'BANK MANDIRI NO. 125-01-00707124', '125-01-00707124', 'BANK MANDIRI', NULL, 'IDR', '0', '6', '8101', '0000-00-00 00:00:00', '0', '0');

### Structure of table `0_bank_trans` ###

DROP TABLE IF EXISTS `0_bank_trans`;

CREATE TABLE `0_bank_trans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` smallint(6) DEFAULT NULL,
  `trans_no` int(11) DEFAULT NULL,
  `bank_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ref` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trans_date` date NOT NULL DEFAULT '0000-00-00',
  `amount` double DEFAULT NULL,
  `dimension_id` int(11) NOT NULL DEFAULT '0',
  `dimension2_id` int(11) NOT NULL DEFAULT '0',
  `person_type_id` int(11) NOT NULL DEFAULT '0',
  `person_id` tinyblob,
  `reconciled` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bank_act` (`bank_act`,`ref`),
  KEY `type` (`type`,`trans_no`),
  KEY `bank_act_2` (`bank_act`,`reconciled`),
  KEY `bank_act_3` (`bank_act`,`trans_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_bank_trans` ###


### Structure of table `0_bom` ###

DROP TABLE IF EXISTS `0_bom`;

CREATE TABLE `0_bom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `component` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `workcentre_added` int(11) NOT NULL DEFAULT '0',
  `loc_code` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `quantity` double NOT NULL DEFAULT '1',
  PRIMARY KEY (`parent`,`component`,`workcentre_added`,`loc_code`),
  KEY `component` (`component`),
  KEY `id` (`id`),
  KEY `loc_code` (`loc_code`),
  KEY `parent` (`parent`,`loc_code`),
  KEY `workcentre_added` (`workcentre_added`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_bom` ###


### Structure of table `0_budget_trans` ###

DROP TABLE IF EXISTS `0_budget_trans`;

CREATE TABLE `0_budget_trans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tran_date` date NOT NULL DEFAULT '0000-00-00',
  `account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `amount` double NOT NULL DEFAULT '0',
  `dimension_id` int(11) DEFAULT '0',
  `dimension2_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `Account` (`account`,`tran_date`,`dimension_id`,`dimension2_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_budget_trans` ###


### Structure of table `0_chart_class` ###

DROP TABLE IF EXISTS `0_chart_class`;

CREATE TABLE `0_chart_class` (
  `cid` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `class_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ctype` tinyint(1) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_chart_class` ###

INSERT INTO `0_chart_class` VALUES
('1', 'HARTA', '1', '0'),
('2', 'KEWAJIBAN', '2', '0'),
('3', 'PENDAPATAN', '4', '0'),
('4', 'BIAYA', '6', '0');

### Structure of table `0_chart_master` ###

DROP TABLE IF EXISTS `0_chart_master`;

CREATE TABLE `0_chart_master` (
  `account_code` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `account_code2` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `account_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `account_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`account_code`),
  KEY `account_name` (`account_name`),
  KEY `accounts_by_type` (`account_type`,`account_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_chart_master` ###

INSERT INTO `0_chart_master` VALUES
('1100', '', 'Kas IDR', '10', '0'),
('1101', '', 'Kas USD', '10', '0'),
('1110', '', 'Bank BCA IDR 161.302.868.8', '10', '0'),
('1111', '', 'Bank Mandiri 125.00.1338983.8', '10', '0'),
('1112', '', 'BANK BCA USD no. 161.250.5050', '10', '0'),
('1113', '', 'BANK MANDIRI NO. 125-01-00707124', '10', '0'),
('1200', '', 'Piutang Usaha/AR', '12', '0'),
('1201', '', 'Piutang Karyawan', '12', '0'),
('1300', '', 'Bangunan Pabrik', '13', '0'),
('1301', '', 'Kendaraan', '13', '0'),
('1302', '', 'Peralatan &amp; Perlengkapan-GA', '13', '0'),
('1303', '', 'Peralatan &amp; Perlengkapan-Pabrik', '13', '0'),
('1304', '', 'Mesin', '13', '0'),
('1340', '', 'Akumulasi Penyusutan Aktiva Tetap (Fisik)', '13', '0'),
('1350', '', 'Aktiva Tetap (Non Fisik)', '13', '0'),
('1390', '', 'Akumulasi Amortisasi Aktiva Tetap (Non Fisik)', '13', '0'),
('1410', '', 'Persediaan - Bahan Baku', '14', '0'),
('1415', '', 'Persediaan - WIP', '14', '0'),
('1416', '', 'Persediaan - Barang Diterima', '14', '0'),
('1420', '', 'Persediaan - FG', '14', '0'),
('1421', '', 'Persediaan - Packing', '14', '0'),
('1422', '', 'Persediaan - Bahan Penolong', '14', '0'),
('1501', '', 'Uang Muka Pembelian Resin', '15', '0'),
('1502', '', 'Uang Muka Pembelian Mesin', '15', '0'),
('1503', '', 'Uang Muka Pembelian Lain-Lain', '15', '0'),
('1504', '', 'PPN Masukan di bayar di muka', '15', '0'),
('1505', '', 'PPh Pasal 22 ', '15', '0'),
('1506', '', 'Asuransi Dibayar Dimuka', '15', '0'),
('2000', '', 'Pembayaran Pajak', '22', '0'),
('2100', '', 'Utang Usaha/AP', '20', '0'),
('2101', '', 'Hutang Pembelian Aktiva', '20', '0'),
('2102', '', 'Hutang Biaya', '20', '0'),
('2103', '', 'Hutang Bank Mandiri', '20', '0'),
('2201', '', 'PPN Keluaran', '22', '0'),
('2202', '', 'PPN Pembelian', '22', '0'),
('2203', '', 'Hutang PPH 21', '22', '0'),
('2204', '', 'Hutang PPH 23', '22', '0'),
('2205', '', 'Hutang PPh Pasal 4(2)', '22', '0'),
('3100', '', 'Modal Awal', '30', '0'),
('3200', '', 'Perubahan Modal', '30', '0'),
('3400', '', 'Laba ditahan', '30', '0'),
('3500', '', 'Opening Balance Equity', '30', '0'),
('4100', '', 'Penjualan CPP', '40', '0'),
('4101', '', 'Penjualan VMCPP', '40', '0'),
('4200', '', 'Diskon Penjualan', '40', '0'),
('4250', '', 'Beban Pengiriman dan Pengepakan', '40', '0'),
('5101', '', 'Harga Pokok Penjualan', '50', '0'),
('5102', '', 'Ongkos Produksi', '50', '0'),
('5104', '', 'Penyesuaian Persediaan', '50', '0'),
('5200', '', 'Pabrik-Biaya Gaji dan Tunjangan', '50', '0'),
('5201', '', 'Pabrik-Biaya Bonus dan THR', '50', '0'),
('5202', '', 'Pabrik-Biaya Bahan Pendukung', '50', '0'),
('5203', '', 'Pabrik-Biaya Bahan Packing', '50', '0'),
('5204', '', 'Pabrik-Biaya Listrik', '50', '0'),
('5205', '', 'Pabrik-Biaya Perbaikan dan Pemeliharaan', '50', '0'),
('5206', '', 'Pabrik-Biaya Kunjungan Teknisi', '50', '0'),
('5208', '', 'Pabrik-Biaya Ekspedisi', '50', '0'),
('5209', '', 'Pabrik-Biaya Bea Masuk', '50', '0'),
('5210', '', 'Pabrik-Biaya Peny Bangunan', '50', '0'),
('5211', '', 'Pabrik-Biaya Peny Mesin', '50', '0'),
('5212', '', 'Pabrik-Biaya Peny Inventaris Pabrik', '50', '0'),
('5213', '', 'Pabrik-Biaya Peny Kendaraan', '50', '0'),
('5214', '5214', 'Pabrik-Biaya Trucking', '50', '0'),
('6100', '', 'Beban Penjualan', '60', '0'),
('6200', '', 'Administrasi dan Beban Umum', '60', '0'),
('6205', '', 'Beban Penyusutan', '60', '0'),
('6206', '', 'Beban Amortisasi', '60', '0'),
('6300', '', 'Selisih Mata Uang Asing', '60', '0'),
('6401', '', 'G&amp;A-Biaya Gaji dan Tunjangan', '60', '0'),
('6402', '', 'G&amp;A-Biaya Bonus dan THR', '60', '0'),
('6403', '', 'G&amp;A-Biaya Pengobatan', '60', '0'),
('6404', '', 'G&amp;A-Biaya Training karyawan', '60', '0'),
('6405', '', 'G&amp;A-Biaya Bensin', '60', '0'),
('6406', '', 'G&amp;A-Biaya Tol dan Parkir', '60', '0'),
('6407', '', 'G&amp;A-Biaya Perbaikan dan Pemeliharaan', '60', '0'),
('6408', '', 'G&amp;A-Biaya Listrik (Office dan Security)', '60', '0'),
('6409', '', 'G&amp;A Biaya Sumbangan dan Donasi', '60', '0'),
('6410', '', 'G&amp;A-Biaya Perjalanan Dinas', '60', '0'),
('6411', '', 'G&amp;A-Biaya Konsultan', '60', '0'),
('6412', '', 'G&amp;A-Biaya Perizinan', '60', '0'),
('6413', '', 'G&amp;A-Biaya Asuransi', '60', '0'),
('6414', '', 'G&amp;A-Biaya Denda Administratif pajak', '60', '0'),
('6415', '', 'G&amp;A-Biaya Sewa', '60', '0'),
('6416', '', 'G&amp;A-Biaya Stationery', '60', '0'),
('6417', '', 'G&amp;A-Biaya Telephone dan Internet', '60', '0'),
('6418', '', 'G&amp;A-Biaya Pos dan Meterai', '60', '0'),
('6419', '', 'G&amp;A-Biaya Makan', '60', '0'),
('6420', '', 'G&amp;A-Biaya PPh', '60', '0'),
('6421', '', 'G&amp;A-Biaya Claim Customer', '60', '0'),
('6422', '', 'G&amp;A-Biaya Penghapusan Piutang', '60', '0'),
('6423', '', 'G&amp;A-Biaya Lain-Lain', '60', '0'),
('6424', '', 'G&amp;A-Biaya Pest Control', '60', '0'),
('6425', '', 'G&amp;A-Biaya insentif karyawan', '60', '0'),
('7100', '', 'Penjualan lain-lain', '70', '0'),
('7101', '', 'Pendapatan Bunga Bank', '70', '0'),
('7102', '', 'Pendapatan Kas', '70', '0'),
('7103', '', 'Diskon Pembelian', '70', '0'),
('8101', '', 'Beban Administrasi Bank', '80', '0'),
('8102', '', 'Beban Bunga Bank', '80', '0'),
('8200', '', 'Marketing-Biaya Entertainment', '80', '0'),
('8201', '', 'Marketing-Biaya Perjalanan Dinas', '80', '0'),
('8202', '', 'Marketing-Biaya Tol dan Parkir', '80', '0'),
('8203', '', 'Marketing-Biaya Bahan Bakar', '80', '0'),
('8204', '', 'Marketing-Biaya Perbaikan dan Servis Kendaraan', '80', '0'),
('8205', '', 'Marketing-Biaya Pulsa', '80', '0'),
('9990', '', 'Laba/Rugi Berjalan', '80', '0');

### Structure of table `0_chart_types` ###

DROP TABLE IF EXISTS `0_chart_types`;

CREATE TABLE `0_chart_types` (
  `id` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `class_id` varchar(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `parent` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-1',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `class_id` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_chart_types` ###

INSERT INTO `0_chart_types` VALUES
('10', 'Kas Bank', '1', '', '0'),
('12', 'Piutang Usaha', '1', '', '0'),
('13', 'Aktiva Tetap', '1', '', '0'),
('14', 'Inventaris', '1', '', '0'),
('15', 'Aktiva Lain', '1', '', '0'),
('20', 'Utang Usaha', '2', '', '0'),
('22', 'Kewajiban', '2', '', '0'),
('30', 'Modal', '2', '', '0'),
('40', 'Pendapatan', '3', '', '0'),
('50', 'Harga Pokok Penjualan', '4', '', '0'),
('60', 'Beban', '4', '', '0'),
('70', 'Pendapatan Lain', '3', '', '0'),
('80', 'Beban Lain-Lain', '4', '', '0');

### Structure of table `0_comments` ###

DROP TABLE IF EXISTS `0_comments`;

CREATE TABLE `0_comments` (
  `type` int(11) NOT NULL DEFAULT '0',
  `id` int(11) NOT NULL DEFAULT '0',
  `date_` date DEFAULT '0000-00-00',
  `memo_` tinytext COLLATE utf8_unicode_ci,
  KEY `type_and_id` (`type`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_comments` ###

INSERT INTO `0_comments` VALUES
('20', '1', '2021-01-04', 'Pembelian 1000kg aluminium wire'),
('20', '3', '2021-04-01', 'Biaya catering 1855paket periode 16-29 Desember 2020'),
('20', '4', '2021-01-04', 'Biaya ekspedisi ke SPK dan Sindomas tgl 23/12/2020'),
('20', '5', '2021-01-04', 'Biaya catering 1855paket periode 16-29 Desember 2020'),
('20', '6', '2021-01-05', 'Pembelian 225kg ASIBLOCK AB 0085-1'),
('20', '7', '2021-01-05', 'Pembelian 1000kg Vistamaxx 3588 FL'),
('20', '8', '2021-01-05', 'Pembelian 2000pcs bantalan kayu'),
('20', '9', '2021-01-05', 'Pembelian 100pcs palang kayu 106cm'),
('20', '10', '2021-01-05', 'Pembelian 15pcs palet 1100x1100'),
('20', '11', '2021-01-05', 'Pembelian 32pcs palet 1000x1100'),
('20', '12', '2021-01-05', 'Pembelian 60pcs palang 87cm, 60pcs palang 90cm, 60cm palang 93cm, 60pcs palang 99cm, 60pcs palang 117cm'),
('20', '13', '2021-01-05', 'Pembelian 100pcs palang kayu 126cm'),
('20', '14', '2021-01-05', 'Pembelian 100pcs palang 120cm, 80pcs palang 90cm, 300pcs palang 921cm, 100pcs palang 870cm, 300pcs palang 180cm'),
('20', '15', '2021-01-05', 'Pembelian 190pcs palet 1200x1100, 16pcs palet 1100x550, 11pcs palet 1200x980'),
('20', '16', '2021-01-05', 'Pembelian 10pcs palet 1200x720'),
('20', '17', '2021-01-05', 'Pembelian 90pcs palet 1100x1100'),
('20', '18', '2021-01-05', 'Pembelian 50 pcs palet 1000x1100'),
('20', '19', '2021-01-06', 'Pembelian 51pcs palet 1200x1100, 6pcs palet 550x1100'),
('20', '20', '2021-01-06', 'Pembelian 305pcs plywood 50x50, 28pcs plywood 55x55 dan 26pcs profil H'),
('20', '62', '2021-01-06', 'Pembelian palet dan palang kayu'),
('20', '63', '2021-01-06', 'Pembelian palang kayu'),
('20', '64', '2021-01-06', 'Pembelian palang kayu'),
('20', '65', '2021-01-06', 'Pembelian palet kayu');

### Structure of table `0_credit_status` ###

DROP TABLE IF EXISTS `0_credit_status`;

CREATE TABLE `0_credit_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reason_description` char(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dissallow_invoices` tinyint(1) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `reason_description` (`reason_description`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_credit_status` ###

INSERT INTO `0_credit_status` VALUES
('1', 'Good History', '0', '0'),
('3', 'No more work until payment received', '1', '0'),
('4', 'In liquidation', '1', '0');

### Structure of table `0_crm_categories` ###

DROP TABLE IF EXISTS `0_crm_categories`;

CREATE TABLE `0_crm_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'pure technical key',
  `type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `action` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `description` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `system` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'nonzero for core system usage',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`,`action`),
  UNIQUE KEY `type_2` (`type`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_crm_categories` ###

INSERT INTO `0_crm_categories` VALUES
('1', 'cust_branch', 'general', 'General', 'General contact data for customer branch (overrides company setting)', '1', '0'),
('2', 'cust_branch', 'invoice', 'Invoices', 'Invoice posting (overrides company setting)', '1', '0'),
('3', 'cust_branch', 'order', 'Orders', 'Order confirmation (overrides company setting)', '1', '0'),
('4', 'cust_branch', 'delivery', 'Deliveries', 'Delivery coordination (overrides company setting)', '1', '0'),
('5', 'customer', 'general', 'General', 'General contact data for customer', '1', '0'),
('6', 'customer', 'order', 'Orders', 'Order confirmation', '1', '0'),
('7', 'customer', 'delivery', 'Deliveries', 'Delivery coordination', '1', '0'),
('8', 'customer', 'invoice', 'Invoices', 'Invoice posting', '1', '0'),
('9', 'supplier', 'general', 'General', 'General contact data for supplier', '1', '0'),
('10', 'supplier', 'order', 'Orders', 'Order confirmation', '1', '0'),
('11', 'supplier', 'delivery', 'Deliveries', 'Delivery coordination', '1', '0'),
('12', 'supplier', 'invoice', 'Invoices', 'Invoice posting', '1', '0');

### Structure of table `0_crm_contacts` ###

DROP TABLE IF EXISTS `0_crm_contacts`;

CREATE TABLE `0_crm_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL DEFAULT '0' COMMENT 'foreign key to crm_contacts',
  `type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `action` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `entity_id` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`,`action`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_crm_contacts` ###

INSERT INTO `0_crm_contacts` VALUES
('1', '1', 'supplier', 'general', '1'),
('2', '2', 'cust_branch', 'general', '1'),
('3', '2', 'customer', 'general', '1'),
('4', '3', 'cust_branch', 'general', '2'),
('5', '3', 'customer', 'general', '3'),
('6', '4', 'cust_branch', 'general', '3'),
('7', '4', 'customer', 'general', '4'),
('8', '5', 'cust_branch', 'general', '4'),
('9', '5', 'customer', 'general', '5'),
('10', '6', 'cust_branch', 'general', '5'),
('11', '6', 'customer', 'general', '6'),
('12', '7', 'cust_branch', 'general', '6'),
('13', '7', 'customer', 'general', '7'),
('14', '8', 'cust_branch', 'general', '7'),
('15', '8', 'customer', 'general', '8'),
('16', '9', 'cust_branch', 'general', '8'),
('17', '9', 'customer', 'general', '9'),
('18', '10', 'cust_branch', 'general', '9'),
('19', '10', 'customer', 'general', '10'),
('20', '11', 'cust_branch', 'general', '10'),
('21', '11', 'customer', 'general', '11'),
('22', '12', 'cust_branch', 'general', '11'),
('23', '12', 'customer', 'general', '12'),
('24', '13', 'cust_branch', 'general', '12'),
('25', '13', 'customer', 'general', '13'),
('26', '14', 'cust_branch', 'general', '13'),
('27', '14', 'customer', 'general', '14'),
('28', '15', 'cust_branch', 'general', '14'),
('29', '15', 'customer', 'general', '15'),
('30', '16', 'cust_branch', 'general', '15'),
('31', '16', 'customer', 'general', '16'),
('32', '17', 'cust_branch', 'general', '16'),
('33', '17', 'customer', 'general', '17'),
('34', '18', 'cust_branch', 'general', '17'),
('35', '18', 'customer', 'general', '18'),
('36', '19', 'cust_branch', 'general', '18'),
('37', '19', 'customer', 'general', '19'),
('38', '20', 'cust_branch', 'general', '19'),
('39', '20', 'customer', 'general', '20'),
('40', '21', 'cust_branch', 'general', '20'),
('41', '21', 'customer', 'general', '21'),
('42', '22', 'cust_branch', 'general', '21'),
('43', '22', 'customer', 'general', '22'),
('44', '23', 'cust_branch', 'general', '22'),
('45', '23', 'customer', 'general', '23'),
('46', '24', 'cust_branch', 'general', '23'),
('47', '24', 'customer', 'general', '24'),
('48', '25', 'cust_branch', 'general', '24'),
('49', '25', 'customer', 'general', '25'),
('50', '26', 'cust_branch', 'general', '25'),
('51', '26', 'customer', 'general', '26'),
('52', '27', 'cust_branch', 'general', '26'),
('53', '27', 'customer', 'general', '27'),
('54', '28', 'cust_branch', 'general', '27'),
('55', '28', 'customer', 'general', '28'),
('56', '29', 'cust_branch', 'general', '28'),
('57', '29', 'customer', 'general', '29'),
('58', '30', 'cust_branch', 'general', '29'),
('59', '30', 'customer', 'general', '30'),
('60', '31', 'supplier', 'general', '2'),
('61', '32', 'supplier', 'general', '3'),
('62', '33', 'supplier', 'general', '4'),
('63', '34', 'supplier', 'general', '5'),
('64', '35', 'supplier', 'general', '6'),
('65', '36', 'supplier', 'general', '7'),
('66', '37', 'supplier', 'general', '8'),
('67', '38', 'supplier', 'general', '9'),
('68', '39', 'supplier', 'general', '10'),
('69', '40', 'supplier', 'general', '11'),
('70', '41', 'supplier', 'general', '12'),
('71', '42', 'supplier', 'general', '13'),
('72', '43', 'supplier', 'general', '14'),
('73', '44', 'supplier', 'general', '15'),
('74', '45', 'cust_branch', 'general', '30'),
('75', '45', 'customer', 'general', '31'),
('76', '46', 'cust_branch', 'general', '31'),
('77', '46', 'customer', 'general', '32'),
('78', '47', 'cust_branch', 'general', '32'),
('79', '47', 'customer', 'general', '33'),
('80', '48', 'cust_branch', 'general', '33'),
('81', '48', 'customer', 'general', '34'),
('82', '49', 'cust_branch', 'general', '34'),
('83', '49', 'customer', 'general', '35'),
('84', '50', 'cust_branch', 'general', '35'),
('85', '50', 'customer', 'general', '36'),
('86', '51', 'cust_branch', 'general', '36'),
('87', '51', 'customer', 'general', '37'),
('88', '52', 'cust_branch', 'general', '37'),
('89', '52', 'customer', 'general', '38'),
('90', '53', 'supplier', 'general', '16'),
('91', '54', 'supplier', 'general', '17'),
('92', '55', 'supplier', 'general', '18'),
('93', '56', 'supplier', 'general', '19'),
('94', '57', 'supplier', 'general', '20'),
('95', '58', 'supplier', 'general', '21'),
('96', '59', 'supplier', 'general', '22'),
('97', '60', 'supplier', 'general', '23'),
('98', '61', 'supplier', 'general', '24'),
('99', '62', 'supplier', 'general', '25'),
('100', '63', 'supplier', 'general', '26'),
('101', '64', 'supplier', 'general', '27'),
('102', '65', 'supplier', 'general', '28'),
('103', '66', 'supplier', 'general', '29'),
('104', '67', 'supplier', 'general', '30'),
('105', '68', 'supplier', 'general', '31'),
('106', '69', 'supplier', 'general', '32'),
('107', '70', 'supplier', 'general', '33'),
('108', '71', 'supplier', 'general', '34'),
('109', '72', 'supplier', 'general', '35'),
('110', '73', 'supplier', 'general', '36'),
('111', '74', 'supplier', 'general', '37'),
('112', '75', 'supplier', 'general', '38');

### Structure of table `0_crm_persons` ###

DROP TABLE IF EXISTS `0_crm_persons`;

CREATE TABLE `0_crm_persons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `name2` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` tinytext COLLATE utf8_unicode_ci,
  `phone` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone2` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang` char(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ref` (`ref`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_crm_persons` ###

INSERT INTO `0_crm_persons` VALUES
('1', 'TEST', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('2', 'Abadi Jaya Plasindo, PT', 'Abadi Jaya Plasindo, PT', NULL, 'PT.ABADI JAYA PLASINDO\r\nKP PENGASINAN RT.005 RW.018 , PENGASINAN\r\nRAWA LUMBU , BEKASI , JAWA BARAT', NULL, NULL, NULL, NULL, NULL, '', '0'),
('3', 'ACK', 'ARDA CIPTA KEMASINDO, PT', NULL, 'Jl. Raya Dayeuhkolot No.36 Rt.001 Rw.005\r\nPasawahan, Dayeuhkolot Kab.Bandung Jawa Barat', NULL, NULL, NULL, NULL, NULL, '', '0'),
('4', 'AJP', 'ANEKA JASUMA PLASTIK, PT', NULL, 'JL. KEDINDING INDAH 25-27 SURABAYA', NULL, NULL, NULL, NULL, NULL, '', '0'),
('5', 'AJS', 'ANEKA JASUMA SEJAHTERA, PT', NULL, 'Jl. Raya Mauk km.7 Kawasan Industri Mekar Jaya IV\r\nMekar Jaya - Sepatan, Tangerang - Banten', NULL, NULL, NULL, NULL, NULL, '', '0'),
('6', 'ARDA', 'PT ARDA CIPTA KEMASINDO', NULL, 'Jl.Raya Dayeuhkolot No.36 RT/RW:01/05\r\nPasawahan , Dayeuhkolot\r\nBandung', NULL, NULL, NULL, NULL, NULL, '', '0'),
('7', 'ARKA PACK', 'ARKA PACK', NULL, 'JALAN DAAN MOGOT 119 BLOK A-14\r\nDURI KEPA - JAKARTA BARAT', NULL, NULL, NULL, NULL, NULL, '', '0'),
('8', 'AWIE', 'AWIE JAYA PLASTIK', NULL, 'Jl.Medan Deli-Tua KM7,2 No.2\r\nMedan', NULL, NULL, NULL, NULL, NULL, '', '0'),
('9', 'AWS', 'ANEKA WARNA SEMESTA, PT', NULL, 'Jl. Kamal Raya No.18 Tegal Alur\r\nJakarta Barat DKI Jakarta', NULL, NULL, NULL, NULL, NULL, '', '0'),
('10', 'BAPAK BENNY', 'BAPAK BENNY', NULL, 'SURABAYA', NULL, NULL, NULL, NULL, NULL, '', '0'),
('11', 'BAPAK CANDRA', 'BAPAK CANDRA', NULL, 'BAPAK CANDRA\r\nSURABAYA\r\n', NULL, NULL, NULL, NULL, NULL, '', '0'),
('12', 'BAPAK DWI', 'BAPAK DWI', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('13', 'BAPAK IWAN', 'BAPAK IWAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('14', 'Bapak. MARTUKI', 'Bapak. MARTUKI', NULL, 'Banyu Urip Jaya 526-A\r\nRT 005 RW 005 , Putat jaya , \r\nSawahan , Surabaya', NULL, NULL, NULL, NULL, NULL, '', '0'),
('15', 'BHIRAWA', 'BHIRAWA ADIPRAMA, PT', NULL, 'Jl. Veteran No. 18 Kp. Ciserah Rt.002 Rw.001\r\nCukanggalih, Curug, Kab. Tangerang', NULL, NULL, NULL, NULL, NULL, '', '0'),
('16', 'BIG', 'BINTANG INDAH GEMILANG, PT', NULL, 'Jl. Raya By Pass Krian Km.28 Kel. Sidomoyo Kec. Krian Sidoarjo', NULL, NULL, NULL, NULL, NULL, '', '0'),
('17', 'CIPTA VERINDO', 'CIPTA VERINDO LESTARI, PT', NULL, 'MUARA KARANG RAYA BLOK I 1 SELATAN NO.62A, JAKARTA UTARA 14450', NULL, NULL, NULL, NULL, NULL, '', '0'),
('18', 'Cysindo', 'CV.CYSINDO SUKSES ABADI', NULL, 'Jl.Raya Gaga Kolot Kampung Kebon Cabe Kajangan 8 No.18 RT.008 RW.001 Gaga Pakuhaji , Kab.Tangerang Banten', NULL, NULL, NULL, NULL, NULL, '', '0'),
('19', 'DUA PUTRA JAYA', 'CV.DUA PUTRA JAYA', NULL, 'RUKO CITRA GARDEN 6 BLOK J5A NO.17 RT.009 RW.005 , TEGAL ALUR , KALIDERES , JAKARTA BARAT DKI JAKARTA', NULL, NULL, NULL, NULL, NULL, '', '0'),
('20', 'DWI SUMBER REJEKI', 'PT DWI SUMBER REJEKI', NULL, 'Jl.Salembaran Komplek Pergudangan , Salembaran II RT.004 RW.004 , Salembaran Jati - Kosambi , Kabupaten Tangerang', NULL, NULL, NULL, NULL, NULL, '', '0'),
('21', 'EDDY HARTADJAYA / ETA JAYA', 'EDDY HARTADJAYA / ETA JAYA', NULL, 'Jl. Ceylon No.26 Kebon Kelapa Gambir Jakarta Pusat 10120', NULL, NULL, NULL, NULL, NULL, '', '0'),
('22', 'ERA PRIMA ADI CIPTA KREASINDO', 'ERA PRIMA ADI CIPTA KREASINDO, PT', NULL, 'Mutiara Taman Palem Blok C8 No.2 Rt 006 Rw 014\r\nCengkareng Timur, Cengkareng, Jakarta Barat, DKI Jakarta Raya', NULL, NULL, NULL, NULL, NULL, '', '0'),
('23', 'FA. INDOMAS', 'FA. INDOMAS', NULL, 'Jl. Pulau Nusa Barung No.5 Km.10.5, Kawasan Industri Medan\r\nKel.Mabar-Kec.Medan Deli, Medan-Sumatera Utara-20242', NULL, NULL, NULL, NULL, NULL, '', '0'),
('24', 'FERAWATY', 'FERAWATY', NULL, 'JL.MEDAN DELI TUA KM.7\r\nRT.RW.TITI KUNING , MEDAN JOHOR\r\nMEDAN', NULL, NULL, NULL, NULL, NULL, '', '0'),
('25', 'GLOBAL', 'PT.GLOBAL PRINTPACK INDONESIA', NULL, 'Jl.Pajajaran No.98, Pasirandu Rt.003 RW.003 , Kadu , Curug\r\nKab.Tangerang - Banten', NULL, NULL, NULL, NULL, NULL, '', '0'),
('26', 'GOH YU LIONG', 'GOH YU LIONG', NULL, 'Jl.Semanan II / 55 RT.007/006, Semanan \r\nKalideres, Jakarta Barat, DKI Jakarta Raya 11850', NULL, NULL, NULL, NULL, NULL, '', '0'),
('27', 'GOLDEN FLEXIBLE', 'GOLDEN FLEXIBLE PACKAGING, PT', NULL, 'Jl. Raya Cituis, Kp. Sungai Turi RT 02/06\r\nDS. Laksana, Pakuhaji Tangerang', NULL, NULL, NULL, NULL, NULL, '', '0'),
('28', 'GOLDENPACK', 'GOLDENPACK PERKASA, PT', NULL, 'Lingkungan 04 Kranji RT 001 RW 010\r\nCiriung, Cibinong, Bogor, Jawa Barat', NULL, NULL, NULL, NULL, NULL, '', '0'),
('29', 'GRAND P', 'GRAND PREMIER PLASPACK, PT', NULL, 'Ds. Krikilan Rt.005 Rw.002 - Krikilan\r\nDriyorejo - Gresik - Jawa Timur', NULL, NULL, NULL, NULL, NULL, '', '0'),
('30', 'MAYORA', 'MAYORA INDAH TBK, PT', NULL, 'Jl. Telesonik, Kel. Pasir Jaya Jati Uwung\r\nTangerang Banten 15135', NULL, NULL, NULL, NULL, NULL, '', '0'),
('31', 'ADHI JAYA METALINDO, PT', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('32', 'CHANDRA ASRI PETROCHEMICAL, PT', 'Mr. ALBERT', NULL, NULL, '0215307950', NULL, '0215308930', NULL, NULL, '', '0'),
('33', 'INTERNAL SHOP', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('34', 'CATERING H AWAN', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('35', 'CV CAHAYA TRANS', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('36', 'MEGA RAMA PLASTINDO, PT', 'Mr. ALI RAHMAN', NULL, NULL, '021-55766090', NULL, '021-29006222', NULL, NULL, '', '0'),
('37', 'Prammindo Windukarya Cemerlang', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('38', 'EKA WARNA KIMIA, PT', 'Mr. YASIN', NULL, NULL, '021-5703810', NULL, '021-5703811', NULL, NULL, '', '0'),
('39', 'SPEEDY PRINTING, CV', 'Mr. YUDI SUPRIYADI', NULL, 'Komp. Mutiara Taman Palem Blok C2/33, Jakarta Barat 11730 Indonesia', '(021) 5435 7004 ', NULL, '(021) 5435 6974', 'speedy_printing@yahoo.com', NULL, '', '0'),
('40', 'ANDALIRA CIPTA ABADI, PT', 'Ms. ATIKAH', NULL, 'Kawasan Industi Jababeka 2, Jl. Industri Selatan 4 Blok GG No.5N Cikarang - Bekasi', '021-89841408', NULL, '021-89841410', NULL, NULL, '', '0'),
('41', 'SURYA TEKNIK MANDIRI, PD', 'Mr. ABDUL MAJID / Mr. SUDARTO', NULL, 'Pertokoan Glodok Jaya Lt.4 Blok C No. 26&amp; 37 Jakarta', '021-6242511', NULL, '021-6262703', NULL, NULL, '', '0'),
('42', 'VICTORY BLESSINGS INDONESIA', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('43', 'DUNIA KIMIA JAYA', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('44', 'VICTORY INDAH PRIMA, PT', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('45', 'TUNAS ALFIN', 'TUNAS ALFIN TBK, PT', NULL, 'Jl. H. Agus Salim No.9\r\nPoris Plawad - Cipondoh, Tangerang', NULL, NULL, NULL, NULL, NULL, '', '0'),
('46', 'MITRA MULTI ', 'MITRA MULTI PACKAGING, PT', NULL, 'Jl. Raya Serang Km.24 Kp.Hauan Tobat Balaraja Kab.Tangerang Banten', NULL, NULL, NULL, NULL, NULL, '', '0'),
('47', 'SWC', 'PT SAPTA WARNA CEMERLANG', NULL, 'Jl.Industri Raya Blok C NO.1\r\nKel.Pasirjaya , Kec.Jatiuwung\r\nTangerang - 15135', NULL, NULL, NULL, NULL, NULL, '', '0'),
('48', 'SPK', 'SINAR PELANGI KEMASINDO, PT', NULL, 'Jl. Tanjung Pura no. 8  RT. 005/05, Pegadungan \r\nKalideres, Jakarta Barat', NULL, NULL, NULL, NULL, NULL, '', '0'),
('49', 'SINDOMAS', 'SINDOMAS INTI PERKASA, PT', NULL, 'Jl.Sei Belumai Hilir No.103 A, Tanjung Morawa A\r\nTanjung Morawa, Deli Serdang - 20362', NULL, NULL, NULL, NULL, NULL, '', '0'),
('50', 'UNIVENUS', 'PT.THE UNIVENUS', NULL, 'Jl.Raya Serang KM.12, RT.005/001\r\nSuka Damai - Cikupta Tangerang', NULL, NULL, NULL, NULL, NULL, '', '0'),
('51', 'SPN', 'SARANA PRIMA NUSANTARA ABADI, PT', NULL, 'Kp. Cikedokan  RT/RW : 005/012, Sukadanau \r\nCikarang Barat Bekasi - Jawa Barat', NULL, NULL, NULL, NULL, NULL, '', '0'),
('52', 'PNI', 'PUTRA NAGA INDOTAMA, PT', NULL, 'Kawasan Industi Mekarjaya Km 7 Jl.Karet 2 /10\r\nMekar Jaya - Sepatan, Tangerang', NULL, NULL, NULL, NULL, NULL, '', '0'),
('53', 'LIBRA MAS PERMATA, PT', 'Mr. FAJAR', NULL, 'Jl. Jababeka VI Blok J No. 5D\r\nCikarang Industrial Estate', '021-89833104', NULL, '021-89833105', 'cikarang@libramas.co.id', NULL, '', '0'),
('54', 'CHEMINDO INTERBUANA', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('55', 'INTIDAYA DINAMIKA SEJATI, PT', '', NULL, 'JL. Pangeran Jayakarta 123 No 41', NULL, NULL, NULL, NULL, NULL, '', '0'),
('56', 'YAMATOGAWA', '', NULL, 'JL. MODERN INDUSTRI III NO.16\r\nKAWASAN INDUSTRI MODERN CIKANDE\r\nCIKANDE SERANG 42186', NULL, NULL, NULL, NULL, NULL, '', '0'),
('57', 'REINPLAS METAL PRIMA, PT', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('58', 'MULTI TEKNINDO NUSANTARA, PT', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('59', 'ECOLAB', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('60', 'ADONAI PRINTING', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('61', 'BALINA AGUNG PERKASA,PT', '', NULL, 'CIPENDAWA RAYA NAROGONG KM.7, BEKASI RT/RW 004/006\r\nBOJONG MENTENG BEKASI 17117', NULL, NULL, NULL, NULL, NULL, '', '0'),
('62', 'SAMATOR GAS (JABABEKA 1), PT', '', NULL, 'JABABEKA 1', NULL, NULL, NULL, NULL, NULL, '', '0'),
('63', 'BATUMAS INDAH S', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('64', 'WIRA FLOPACK. CV', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('65', 'FAJAR JAYA ELEKTRO, CV', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('66', 'BUNGA PERMATA KURNIA, PT', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('67', 'CITRA ABADI JAYA, CV', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('68', 'YAKIN MAJU SENTOSA, PT', 'Mr. ERIKSON', NULL, 'Cikarang Branch\r\nJl. Jababeka VII G Block R No. 1E\r\nLemah Abang, Bekasi 17530', '021-8935235', NULL, NULL, NULL, NULL, '', '0'),
('69', 'MAFATI INOVASI TECHNOLOGY, PT', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('70', 'WIRAFLOPACK, CV', 'Mr. UBALDUS', NULL, 'Jln. kebun Kelapa RT 02 RW 03\r\nTambun-Bekasi 17510', '021-88366297', NULL, '021-88326435', NULL, NULL, '', '0'),
('71', 'MITRA TEKNIK SEJAHTERA, CV', 'Mr. IRSYADUL IBAT', NULL, 'JL. Kancil Raya Blok a7 No. 50 Perum Cikarang Baru\r\nKabupaten Bekasi 17530', '021-89321140', '081288711126', NULL, NULL, NULL, '', '0'),
('72', 'GLOBAL TECHNIC INDONESIA, CV', 'Mr. BARONI', NULL, 'Jl. Raya Imam Bonjol\r\nRuko Telaga Pesona L 01/9\r\nTelaga Sakinah\r\nCikarang Barat\r\nBekasi 17520', '021-89100319', NULL, '021-89100319', NULL, NULL, '', '0'),
('73', 'PURYTEK TUNGGAL PRIMA, PT', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('74', 'ANUGERAH PUTRA KENCANA, PT', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('75', 'SARANAPRIMA NUSANTARA ABADI, P', 'Mrs. VERONICA', NULL, 'JL. Kp. Cikedokan RT 005 RW 012\r\nDesa Sukadanau, Cibitung\r\nBekasi Jawa Barat', '021-88365885', NULL, '021-88365641', NULL, NULL, '', '0');

### Structure of table `0_currencies` ###

DROP TABLE IF EXISTS `0_currencies`;

CREATE TABLE `0_currencies` (
  `currency` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `curr_abrev` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `curr_symbol` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `hundreds_name` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `auto_update` tinyint(1) NOT NULL DEFAULT '1',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`curr_abrev`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_currencies` ###

INSERT INTO `0_currencies` VALUES
('Euro', 'EUR', '?', 'Europe', 'Cents', '1', '0'),
('Rupiah', 'IDR', 'Rp', 'Indonesia', 'Sen', '1', '0'),
('US Dollars', 'USD', '$', 'United States', 'Cents', '1', '0');

### Structure of table `0_cust_allocations` ###

DROP TABLE IF EXISTS `0_cust_allocations`;

CREATE TABLE `0_cust_allocations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) DEFAULT NULL,
  `amt` double unsigned DEFAULT NULL,
  `date_alloc` date NOT NULL DEFAULT '0000-00-00',
  `trans_no_from` int(11) DEFAULT NULL,
  `trans_type_from` int(11) DEFAULT NULL,
  `trans_no_to` int(11) DEFAULT NULL,
  `trans_type_to` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `person_id` (`person_id`,`trans_type_from`,`trans_no_from`,`trans_type_to`,`trans_no_to`),
  KEY `From` (`trans_type_from`,`trans_no_from`),
  KEY `To` (`trans_type_to`,`trans_no_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_cust_allocations` ###


### Structure of table `0_cust_branch` ###

DROP TABLE IF EXISTS `0_cust_branch`;

CREATE TABLE `0_cust_branch` (
  `branch_code` int(11) NOT NULL AUTO_INCREMENT,
  `debtor_no` int(11) NOT NULL DEFAULT '0',
  `br_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `branch_ref` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `br_address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `area` int(11) DEFAULT NULL,
  `salesman` int(11) NOT NULL DEFAULT '0',
  `default_location` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tax_group_id` int(11) DEFAULT NULL,
  `sales_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sales_discount_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `receivables_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `payment_discount_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `default_ship_via` int(11) NOT NULL DEFAULT '1',
  `br_post_address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `group_no` int(11) NOT NULL DEFAULT '0',
  `notes` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `bank_account` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`branch_code`,`debtor_no`),
  KEY `branch_ref` (`branch_ref`),
  KEY `group_no` (`group_no`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_cust_branch` ###

INSERT INTO `0_cust_branch` VALUES
('1', '1', 'Abadi Jaya Plasindo, PT', 'Abadi Jaya Plasindo, PT', 'PT.ABADI JAYA PLASINDO\r\nKP PENGASINAN RT.005 RW.018 , PENGASINAN\r\nRAWA LUMBU , BEKASI , JAWA BARAT', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'PT.ABADI JAYA PLASINDO\r\nKP PENGASINAN RT.005 RW.018 , PENGASINAN\r\nRAWA LUMBU , BEKASI , JAWA BARAT', '0', '', NULL, '0'),
('2', '3', 'ARDA CIPTA KEMASINDO, PT', 'ACK', 'Jl. Raya Dayeuhkolot No.36 Rt.001 Rw.005\r\nPasawahan, Dayeuhkolot Kab.Bandung Jawa Barat', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl. Raya Dayeuhkolot No.36 Rt.001 Rw.005\r\nPasawahan, Dayeuhkolot Kab.Bandung Jawa Barat', '0', '', NULL, '0'),
('3', '4', 'ANEKA JASUMA PLASTIK, PT', 'AJP', 'JL. KEDINDING INDAH 25-27 SURABAYA', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'JL. KEDINDING INDAH 25-27 SURABAYA', '0', '', NULL, '0'),
('4', '5', 'ANEKA JASUMA SEJAHTERA, PT', 'AJS', 'Jl. Raya Mauk km.7 Kawasan Industri Mekar Jaya IV\r\nMekar Jaya - Sepatan, Tangerang - Banten', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl. Raya Mauk km.7 Kawasan Industri Mekar Jaya IV\r\nMekar Jaya - Sepatan, Tangerang - Banten', '0', '', NULL, '0'),
('5', '6', 'PT ARDA CIPTA KEMASINDO', 'ARDA', 'Jl.Raya Dayeuhkolot No.36 RT/RW:01/05\r\nPasawahan , Dayeuhkolot\r\nBandung', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl.Raya Dayeuhkolot No.36 RT/RW:01/05\r\nPasawahan , Dayeuhkolot\r\nBandung', '0', '', NULL, '0'),
('6', '7', 'ARKA PACK', 'ARKA PACK', 'JALAN DAAN MOGOT 119 BLOK A-14\r\nDURI KEPA - JAKARTA BARAT', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'JALAN DAAN MOGOT 119 BLOK A-14\r\nDURI KEPA - JAKARTA BARAT', '0', '', NULL, '0'),
('7', '8', 'AWIE JAYA PLASTIK', 'AWIE', 'Jl.Medan Deli-Tua KM7,2 No.2\r\nMedan', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl.Medan Deli-Tua KM7,2 No.2\r\nMedan', '0', '', NULL, '0'),
('8', '9', 'ANEKA WARNA SEMESTA, PT', 'AWS', 'Jl. Kamal Raya No.18 Tegal Alur\r\nJakarta Barat DKI Jakarta', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl. Kamal Raya No.18 Tegal Alur\r\nJakarta Barat DKI Jakarta', '0', '', NULL, '0'),
('9', '10', 'BAPAK BENNY', 'BAPAK BENNY', 'SURABAYA', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'SURABAYA', '0', '', NULL, '0'),
('10', '11', 'BAPAK CANDRA', 'BAPAK CANDRA', 'BAPAK CANDRA\r\nSURABAYA\r\n', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'BAPAK CANDRA\r\nSURABAYA\r\n', '0', '', NULL, '0'),
('11', '12', 'BAPAK DWI', 'BAPAK DWI', '', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', '', '0', '', NULL, '0'),
('12', '13', 'BAPAK IWAN', 'BAPAK IWAN', '', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', '', '0', '', NULL, '0'),
('13', '14', 'Bapak. MARTUKI', 'Bapak. MARTUKI', 'Banyu Urip Jaya 526-A\r\nRT 005 RW 005 , Putat jaya , \r\nSawahan , Surabaya', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Banyu Urip Jaya 526-A\r\nRT 005 RW 005 , Putat jaya , \r\nSawahan , Surabaya', '0', '', NULL, '0'),
('14', '15', 'BHIRAWA ADIPRAMA, PT', 'BHIRAWA', 'Jl. Veteran No. 18 Kp. Ciserah Rt.002 Rw.001\r\nCukanggalih, Curug, Kab. Tangerang', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl. Veteran No. 18 Kp. Ciserah Rt.002 Rw.001\r\nCukanggalih, Curug, Kab. Tangerang', '0', '', NULL, '0'),
('15', '16', 'BINTANG INDAH GEMILANG, PT', 'BIG', 'Jl. Raya By Pass Krian Km.28 Kel. Sidomoyo Kec. Krian Sidoarjo', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl. Raya By Pass Krian Km.28 Kel. Sidomoyo Kec. Krian Sidoarjo', '0', '', NULL, '0'),
('16', '17', 'CIPTA VERINDO LESTARI, PT', 'CIPTA VERINDO', 'MUARA KARANG RAYA BLOK I 1 SELATAN NO.62A, JAKARTA UTARA 14450', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'MUARA KARANG RAYA BLOK I 1 SELATAN NO.62A, JAKARTA UTARA 14450', '0', '', NULL, '0'),
('17', '18', 'CV.CYSINDO SUKSES ABADI', 'Cysindo', 'Jl.Raya Gaga Kolot Kampung Kebon Cabe Kajangan 8 No.18 RT.008 RW.001 Gaga Pakuhaji , Kab.Tangerang Banten', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl.Raya Gaga Kolot Kampung Kebon Cabe Kajangan 8 No.18 RT.008 RW.001 Gaga Pakuhaji , Kab.Tangerang Banten', '0', '', NULL, '0'),
('18', '19', 'CV.DUA PUTRA JAYA', 'DUA PUTRA JAYA', 'RUKO CITRA GARDEN 6 BLOK J5A NO.17 RT.009 RW.005 , TEGAL ALUR , KALIDERES , JAKARTA BARAT DKI JAKARTA', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'RUKO CITRA GARDEN 6 BLOK J5A NO.17 RT.009 RW.005 , TEGAL ALUR , KALIDERES , JAKARTA BARAT DKI JAKARTA', '0', '', NULL, '0'),
('19', '20', 'PT DWI SUMBER REJEKI', 'DWI SUMBER REJEKI', 'Jl.Salembaran Komplek Pergudangan , Salembaran II RT.004 RW.004 , Salembaran Jati - Kosambi , Kabupaten Tangerang', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl.Salembaran Komplek Pergudangan , Salembaran II RT.004 RW.004 , Salembaran Jati - Kosambi , Kabupaten Tangerang', '0', '', NULL, '0'),
('20', '21', 'EDDY HARTADJAYA / ETA JAYA', 'EDDY HARTADJAYA / ETA JAYA', 'Jl. Ceylon No.26 Kebon Kelapa Gambir Jakarta Pusat 10120', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl. Ceylon No.26 Kebon Kelapa Gambir Jakarta Pusat 10120', '0', '', NULL, '0'),
('21', '22', 'ERA PRIMA ADI CIPTA KREASINDO, PT', 'ERA PRIMA ADI CIPTA KREASINDO', 'Mutiara Taman Palem Blok C8 No.2 Rt 006 Rw 014\r\nCengkareng Timur, Cengkareng, Jakarta Barat, DKI Jakarta Raya', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Mutiara Taman Palem Blok C8 No.2 Rt 006 Rw 014\r\nCengkareng Timur, Cengkareng, Jakarta Barat, DKI Jakarta Raya', '0', '', NULL, '0'),
('22', '23', 'FA. INDOMAS', 'FA. INDOMAS', 'Jl. Pulau Nusa Barung No.5 Km.10.5, Kawasan Industri Medan\r\nKel.Mabar-Kec.Medan Deli, Medan-Sumatera Utara-20242', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl. Pulau Nusa Barung No.5 Km.10.5, Kawasan Industri Medan\r\nKel.Mabar-Kec.Medan Deli, Medan-Sumatera Utara-20242', '0', '', NULL, '0'),
('23', '24', 'FERAWATY', 'FERAWATY', 'JL.MEDAN DELI TUA KM.7\r\nRT.RW.TITI KUNING , MEDAN JOHOR\r\nMEDAN', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'JL.MEDAN DELI TUA KM.7\r\nRT.RW.TITI KUNING , MEDAN JOHOR\r\nMEDAN', '0', '', NULL, '0'),
('24', '25', 'PT.GLOBAL PRINTPACK INDONESIA', 'GLOBAL', 'Jl.Pajajaran No.98, Pasirandu Rt.003 RW.003 , Kadu , Curug\r\nKab.Tangerang - Banten', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl.Pajajaran No.98, Pasirandu Rt.003 RW.003 , Kadu , Curug\r\nKab.Tangerang - Banten', '0', '', NULL, '0'),
('25', '26', 'GOH YU LIONG', 'GOH YU LIONG', 'Jl.Semanan II / 55 RT.007/006, Semanan \r\nKalideres, Jakarta Barat, DKI Jakarta Raya 11850', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl.Semanan II / 55 RT.007/006, Semanan \r\nKalideres, Jakarta Barat, DKI Jakarta Raya 11850', '0', '', NULL, '0'),
('26', '27', 'GOLDEN FLEXIBLE PACKAGING, PT', 'GOLDEN FLEXIBLE', 'Jl. Raya Cituis, Kp. Sungai Turi RT 02/06\r\nDS. Laksana, Pakuhaji Tangerang', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl. Raya Cituis, Kp. Sungai Turi RT 02/06\r\nDS. Laksana, Pakuhaji Tangerang', '0', '', NULL, '0'),
('27', '28', 'GOLDENPACK PERKASA, PT', 'GOLDENPACK', 'Lingkungan 04 Kranji RT 001 RW 010\r\nCiriung, Cibinong, Bogor, Jawa Barat', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Lingkungan 04 Kranji RT 001 RW 010\r\nCiriung, Cibinong, Bogor, Jawa Barat', '0', '', NULL, '0'),
('28', '29', 'GRAND PREMIER PLASPACK, PT', 'GRAND P', 'Ds. Krikilan Rt.005 Rw.002 - Krikilan\r\nDriyorejo - Gresik - Jawa Timur', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Ds. Krikilan Rt.005 Rw.002 - Krikilan\r\nDriyorejo - Gresik - Jawa Timur', '0', '', NULL, '0'),
('29', '30', 'MAYORA INDAH TBK, PT', 'MAYORA', 'Jl. Telesonik, Kel. Pasir Jaya Jati Uwung\r\nTangerang Banten 15135', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl. Telesonik, Kel. Pasir Jaya Jati Uwung\r\nTangerang Banten 15135', '0', '', NULL, '0'),
('30', '31', 'TUNAS ALFIN TBK, PT', 'TUNAS ALFIN', 'Jl. H. Agus Salim No.9\r\nPoris Plawad - Cipondoh, Tangerang', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl. H. Agus Salim No.9\r\nPoris Plawad - Cipondoh, Tangerang', '0', '', NULL, '0'),
('31', '32', 'MITRA MULTI PACKAGING, PT', 'MITRA MULTI ', 'Jl. Raya Serang Km.24 Kp.Hauan Tobat Balaraja Kab.Tangerang Banten', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl. Raya Serang Km.24 Kp.Hauan Tobat Balaraja Kab.Tangerang Banten', '0', '', NULL, '0'),
('32', '33', 'PT SAPTA WARNA CEMERLANG', 'SWC', 'Jl.Industri Raya Blok C NO.1\r\nKel.Pasirjaya , Kec.Jatiuwung\r\nTangerang - 15135', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl.Industri Raya Blok C NO.1\r\nKel.Pasirjaya , Kec.Jatiuwung\r\nTangerang - 15135', '0', '', NULL, '0'),
('33', '34', 'SINAR PELANGI KEMASINDO, PT', 'SPK', 'Jl. Tanjung Pura no. 8  RT. 005/05, Pegadungan \r\nKalideres, Jakarta Barat', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl. Tanjung Pura no. 8  RT. 005/05, Pegadungan \r\nKalideres, Jakarta Barat', '0', '', NULL, '0'),
('34', '35', 'SINDOMAS INTI PERKASA, PT', 'SINDOMAS', 'Jl.Sei Belumai Hilir No.103 A, Tanjung Morawa A\r\nTanjung Morawa, Deli Serdang - 20362', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl.Sei Belumai Hilir No.103 A, Tanjung Morawa A\r\nTanjung Morawa, Deli Serdang - 20362', '0', '', NULL, '0'),
('35', '36', 'PT.THE UNIVENUS', 'UNIVENUS', 'Jl.Raya Serang KM.12, RT.005/001\r\nSuka Damai - Cikupta Tangerang', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Jl.Raya Serang KM.12, RT.005/001\r\nSuka Damai - Cikupta Tangerang', '0', '', NULL, '0'),
('36', '37', 'SARANA PRIMA NUSANTARA ABADI, PT', 'SPN', 'Kp. Cikedokan  RT/RW : 005/012, Sukadanau \r\nCikarang Barat Bekasi - Jawa Barat', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Kp. Cikedokan  RT/RW : 005/012, Sukadanau \r\nCikarang Barat Bekasi - Jawa Barat', '0', '', NULL, '0'),
('37', '38', 'PUTRA NAGA INDOTAMA, PT', 'PNI', 'Kawasan Industi Mekarjaya Km 7 Jl.Karet 2 /10\r\nMekar Jaya - Sepatan, Tangerang', '1', '1', 'DEF', '1', '', '4200', '1200', '4200', '1', 'Kawasan Industi Mekarjaya Km 7 Jl.Karet 2 /10\r\nMekar Jaya - Sepatan, Tangerang', '0', '', NULL, '0');

### Structure of table `0_debtor_trans` ###

DROP TABLE IF EXISTS `0_debtor_trans`;

CREATE TABLE `0_debtor_trans` (
  `trans_no` int(11) unsigned NOT NULL DEFAULT '0',
  `type` smallint(6) unsigned NOT NULL DEFAULT '0',
  `version` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `debtor_no` int(11) unsigned NOT NULL DEFAULT '0',
  `branch_code` int(11) NOT NULL DEFAULT '-1',
  `tran_date` date NOT NULL DEFAULT '0000-00-00',
  `due_date` date NOT NULL DEFAULT '0000-00-00',
  `reference` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tpe` int(11) NOT NULL DEFAULT '0',
  `order_` int(11) NOT NULL DEFAULT '0',
  `ov_amount` double NOT NULL DEFAULT '0',
  `ov_gst` double NOT NULL DEFAULT '0',
  `ov_freight` double NOT NULL DEFAULT '0',
  `ov_freight_tax` double NOT NULL DEFAULT '0',
  `ov_discount` double NOT NULL DEFAULT '0',
  `alloc` double NOT NULL DEFAULT '0',
  `prep_amount` double NOT NULL DEFAULT '0',
  `rate` double NOT NULL DEFAULT '1',
  `ship_via` int(11) DEFAULT NULL,
  `dimension_id` int(11) NOT NULL DEFAULT '0',
  `dimension2_id` int(11) NOT NULL DEFAULT '0',
  `payment_terms` int(11) DEFAULT NULL,
  `tax_included` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`type`,`trans_no`,`debtor_no`),
  KEY `debtor_no` (`debtor_no`,`branch_code`),
  KEY `tran_date` (`tran_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_debtor_trans` ###

INSERT INTO `0_debtor_trans` VALUES
('1', '10', '2', '37', '36', '2021-01-07', '2021-04-01', '46596652/I/FA-WMI/2021', '2', '16', '0', '0', '0', '0', '0', '0', '0', '1', '1', '0', '0', '5', '0'),
('2', '10', '0', '37', '36', '2021-01-04', '2021-04-01', '46596652/I/FA-WMI/2021', '2', '16', '91020384', '9102038.4', '0', '0', '0', '0', '0', '1', '1', '0', '0', '5', '0'),
('3', '10', '2', '37', '36', '2021-01-07', '2021-04-01', '46596654/I/FA-WMI/2021', '2', '15', '0', '0', '0', '0', '0', '0', '0', '1', '1', '0', '0', '5', '0'),
('4', '10', '0', '37', '36', '2021-01-04', '2021-04-01', '46596654/I/FA-WMI/2021', '2', '15', '94558464', '9455846.4', '0', '0', '0', '0', '0', '1', '1', '0', '0', '5', '0'),
('5', '10', '0', '32', '31', '2021-01-04', '2021-03-02', '46596655/I/FA-WMI/2021', '2', '11', '59033520', '5903352', '0', '0', '0', '0', '0', '1', '1', '0', '0', '7', '0'),
('6', '10', '2', '32', '31', '2021-01-07', '2021-03-02', '46596656/I/FA-WMI/2021', '2', '12', '0', '0', '0', '0', '0', '0', '0', '1', '1', '0', '0', '7', '0'),
('7', '10', '2', '36', '35', '2021-01-07', '2021-04-01', '46596657/I/FA-WMI/2021', '2', '10', '0', '0', '0', '0', '0', '0', '0', '1', '1', '0', '0', '5', '0'),
('8', '10', '0', '32', '31', '2021-01-04', '2021-03-02', '46596656/I/FA-WMI/2021', '2', '12', '22388184', '2238818.4', '0', '0', '0', '0', '0', '1', '1', '0', '0', '7', '0'),
('9', '10', '0', '36', '35', '2021-01-04', '2021-04-01', '46596657/I/FA-WMI/2021', '2', '10', '14484979.2', '1448497.92', '0', '0', '0', '0', '0', '1', '1', '0', '0', '5', '0'),
('10', '10', '0', '36', '35', '2021-01-04', '2021-04-01', '46596658/I/FA-WMI/2021', '2', '7', '14069145.6', '1406914.56', '0', '0', '0', '0', '0', '1', '1', '0', '0', '5', '0'),
('11', '10', '2', '36', '35', '2021-01-07', '2021-04-01', '46596659/I/FA-WMI/2021', '2', '9', '0', '0', '0', '0', '0', '0', '0', '1', '1', '0', '0', '5', '0'),
('12', '10', '0', '36', '35', '2021-01-04', '2021-04-01', '46596659/I/FA-WMI/2021', '2', '9', '25227238.4', '2522723.84', '0', '0', '0', '0', '0', '1', '1', '0', '0', '5', '0'),
('13', '10', '0', '33', '32', '2021-01-04', '2021-04-01', '46596660/I/FA-WMI/2020', '2', '14', '23639616', '2363961.6', '0', '0', '0', '0', '0', '1', '1', '0', '0', '5', '0'),
('14', '10', '0', '33', '32', '2021-01-04', '2021-04-01', '46596661/I/FA-WMI/2021', '2', '13', '22975680', '2297568', '0', '0', '0', '0', '0', '1', '1', '0', '0', '5', '0'),
('1', '13', '2', '37', '36', '2021-01-04', '2021-01-05', 'SJ19182', '2', '16', '91020384', '9102038.4', '0', '0', '0', '0', '0', '1', '1', '0', '0', '5', '0'),
('2', '13', '2', '37', '36', '2021-01-04', '2020-10-02', 'SJ19181', '2', '15', '94558464', '9455846.4', '0', '0', '0', '0', '0', '1', '1', '0', '0', '5', '0'),
('3', '13', '1', '32', '31', '2021-01-04', '2020-10-24', 'sj19176', '2', '11', '59033520', '5903352', '0', '0', '0', '0', '0', '1', '1', '0', '0', '7', '0'),
('4', '13', '2', '32', '31', '2021-01-04', '2020-10-08', 'SJ19177', '2', '12', '22388184', '2238818.4', '0', '0', '0', '0', '0', '1', '1', '0', '0', '7', '0'),
('5', '13', '2', '36', '35', '2021-01-04', '2020-11-26', 'sj19174', '2', '10', '14484979.2', '1448497.92', '0', '0', '0', '0', '0', '1', '1', '0', '0', '5', '0'),
('6', '13', '1', '36', '35', '2021-01-04', '2020-12-16', 'SJ19175', '2', '7', '14069145.6', '1406914.56', '0', '0', '0', '0', '0', '1', '1', '0', '0', '5', '0'),
('7', '13', '2', '36', '35', '2021-01-04', '2020-11-21', 'sj19173', '2', '9', '25227238.4', '2522723.84', '0', '0', '0', '0', '0', '1', '1', '0', '0', '5', '0'),
('8', '13', '1', '33', '32', '2021-01-04', '2020-10-03', 'sj19179', '2', '14', '23639616', '2363961.6', '0', '0', '0', '0', '0', '1', '1', '0', '0', '5', '0'),
('9', '13', '1', '33', '32', '2021-01-04', '2020-11-21', 'sj19178', '2', '13', '22975680', '2297568', '0', '0', '0', '0', '0', '1', '1', '0', '0', '5', '0');

### Structure of table `0_debtor_trans_details` ###

DROP TABLE IF EXISTS `0_debtor_trans_details`;

CREATE TABLE `0_debtor_trans_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `debtor_trans_no` int(11) DEFAULT NULL,
  `debtor_trans_type` int(11) DEFAULT NULL,
  `stock_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` tinytext COLLATE utf8_unicode_ci,
  `unit_price` double NOT NULL DEFAULT '0',
  `unit_tax` double NOT NULL DEFAULT '0',
  `quantity` double NOT NULL DEFAULT '0',
  `discount_percent` double NOT NULL DEFAULT '0',
  `standard_cost` double NOT NULL DEFAULT '0',
  `qty_done` double NOT NULL DEFAULT '0',
  `src_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Transaction` (`debtor_trans_type`,`debtor_trans_no`),
  KEY `src_id` (`src_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_debtor_trans_details` ###

INSERT INTO `0_debtor_trans_details` VALUES
('1', '1', '13', 'CPP', 'CPP 25 mic x 920 mm x 8000 m', '22650', '2265', '4018.56', '0', '46800', '4018.56', '39'),
('2', '1', '10', 'CPP', 'CPP 25 mic x 920 mm x 8000 m', '0', '0', '0', '0', '0', '0', '0'),
('3', '2', '10', 'CPP', 'CPP 25 mic x 920 mm x 8000 m', '22650', '2265', '4018.56', '0', '46800', '0', '1'),
('4', '2', '13', 'VMCPP', 'VMCPP 20 mic x 880 mm x 8000 m', '24600', '2460', '3843.84', '0', '0', '3843.84', '38'),
('5', '3', '10', 'VMCPP', 'VMCPP 20 mic x 880 mm x 8000 m', '0', '0', '0', '0', '0', '0', '0'),
('6', '4', '10', 'VMCPP', 'VMCPP 20 mic x 880 mm x 8000 m', '24600', '2460', '3843.84', '0', '0', '0', '4'),
('7', '3', '13', 'VMCPP', 'VMCPP 25 mic x 1005 mm x 8000 m', '26500', '0', '0', '0', '0', '0', '30'),
('8', '3', '13', 'VMCPP', 'VMCPP 25 mic x 1020 mm x 8000 m', '26500', '2650', '2227.68', '0', '0', '2227.68', '31'),
('9', '3', '13', 'VMCPP', 'VMCPP 30 mic x 1020 mm x 6000 m', '26500', '0', '0', '0', '0', '0', '32'),
('10', '3', '13', 'VMCPP', 'VMCPP 25 mic x 1040 mm x 8000 m', '26500', '0', '0', '0', '0', '0', '33'),
('11', '5', '10', 'VMCPP', 'VMCPP 25 mic x 1005 mm x 8000 m', '26500', '0', '0', '0', '0', '0', '7'),
('12', '5', '10', 'VMCPP', 'VMCPP 25 mic x 1020 mm x 8000 m', '26500', '2650', '2227.68', '0', '0', '0', '8'),
('13', '5', '10', 'VMCPP', 'VMCPP 30 mic x 1020 mm x 6000 m', '26500', '0', '0', '0', '0', '0', '9'),
('14', '5', '10', 'VMCPP', 'VMCPP 25 mic x 1040 mm x 8000 m', '26500', '0', '0', '0', '0', '0', '10'),
('15', '4', '13', 'VMCPP', 'VMCPP 30 mic x 1020 mm x 6000 m', '26800', '2680', '835.38', '0', '0', '835.38', '34'),
('16', '6', '10', 'VMCPP', 'VMCPP 30 mic x 1020 mm x 6000 m', '0', '0', '0', '0', '0', '0', '0'),
('17', '5', '13', 'CPP', 'CPP 35 mic x 1045 mm x 10000 m', '21760', '2176', '665.67', '0', '46800', '665.67', '29'),
('18', '7', '10', 'CPP', 'CPP 35 mic x 1045 mm x 10000 m', '0', '0', '0', '0', '0', '0', '0'),
('19', '8', '10', 'VMCPP', 'VMCPP 30 mic x 1020 mm x 6000 m', '26800', '2680', '835.38', '0', '0', '0', '15'),
('20', '9', '10', 'CPP', 'CPP 35 mic x 1045 mm x 10000 m', '21760', '2176', '665.67', '0', '46800', '0', '17'),
('21', '6', '13', 'CPP', 'CPP 35 mic x 1145 mm x 10000 m', '21760', '0', '0', '0', '46800', '0', '10'),
('22', '6', '13', 'CPP', 'CPP 35 mic x 1015 mm x 10000 m', '21760', '2176', '646.56', '0', '46800', '646.56', '11'),
('23', '6', '13', 'CPP', 'CPP 35 mic x 955 mm x 10000 m', '21760', '0', '0', '0', '46800', '0', '12'),
('24', '6', '13', 'CPP', 'CPP 35 mic x 885 mm x 5000 m', '21760', '0', '0', '0', '46800', '0', '13'),
('25', '6', '13', 'CPP', 'CPP 30 mic x 1125 mm x 10000 m', '21760', '0', '0', '0', '46800', '0', '14'),
('26', '6', '13', 'CPP', 'CPP 35 mic x 1045 mm x 10000 m', '21760', '0', '0', '0', '46800', '0', '15'),
('27', '6', '13', 'CPP', 'CPP 35 mic x 1020 mm x 10000 m', '21760', '0', '0', '0', '46800', '0', '16'),
('28', '6', '13', 'CPP', 'CPP 30 mic x 1165 mm x 10000 m', '21760', '0', '0', '0', '46800', '0', '17'),
('29', '6', '13', 'CPP', 'CPP 35 mic x 935 mm x 10000 m', '21760', '0', '0', '0', '46800', '0', '18'),
('30', '10', '10', 'CPP', 'CPP 35 mic x 1145 mm x 10000 m', '21760', '0', '0', '0', '46800', '0', '21'),
('31', '10', '10', 'CPP', 'CPP 35 mic x 1015 mm x 10000 m', '21760', '2176', '646.56', '0', '46800', '0', '22'),
('32', '10', '10', 'CPP', 'CPP 35 mic x 955 mm x 10000 m', '21760', '0', '0', '0', '46800', '0', '23'),
('33', '10', '10', 'CPP', 'CPP 35 mic x 885 mm x 5000 m', '21760', '0', '0', '0', '46800', '0', '24'),
('34', '10', '10', 'CPP', 'CPP 30 mic x 1125 mm x 10000 m', '21760', '0', '0', '0', '46800', '0', '25'),
('35', '10', '10', 'CPP', 'CPP 35 mic x 1045 mm x 10000 m', '21760', '0', '0', '0', '46800', '0', '26'),
('36', '10', '10', 'CPP', 'CPP 35 mic x 1020 mm x 10000 m', '21760', '0', '0', '0', '46800', '0', '27'),
('37', '10', '10', 'CPP', 'CPP 30 mic x 1165 mm x 10000 m', '21760', '0', '0', '0', '46800', '0', '28'),
('38', '10', '10', 'CPP', 'CPP 35 mic x 935 mm x 10000 m', '21760', '0', '0', '0', '46800', '0', '29'),
('39', '7', '13', 'CPP', 'CPP 35 mic x 910 mm x 10000 m', '21760', '2176', '1159.34', '0', '46800', '1159.34', '28'),
('40', '11', '10', 'CPP', 'CPP 35 mic x 910 mm x 10000 m', '0', '0', '0', '0', '0', '0', '0'),
('41', '12', '10', 'CPP', 'CPP 35 mic x 910 mm x 10000 m', '21760', '2176', '1159.34', '0', '46800', '0', '39'),
('42', '8', '13', 'VMCPP', 'VMCPP 40 mic x 1100 mm x 4000 m', '24600', '2460', '960.96', '0', '0', '960.96', '36'),
('43', '8', '13', 'VMCPP', 'VMCPP 30 mic x 1150 mm x 6000 m', '24600', '0', '0', '0', '0', '0', '37'),
('44', '13', '10', 'VMCPP', 'VMCPP 40 mic x 1100 mm x 4000 m', '24600', '2460', '960.96', '0', '0', '0', '42'),
('45', '13', '10', 'VMCPP', 'VMCPP 30 mic x 1150 mm x 6000 m', '24600', '0', '0', '0', '0', '0', '43'),
('46', '9', '13', 'VMCPP', 'VMCPP 20 mic x 1000 m x 8000 m', '26300', '2630', '873.6', '0', '0', '873.6', '35'),
('47', '14', '10', 'VMCPP', 'VMCPP 20 mic x 1000 m x 8000 m', '26300', '2630', '873.6', '0', '0', '0', '46');

### Structure of table `0_debtors_master` ###

DROP TABLE IF EXISTS `0_debtors_master`;

CREATE TABLE `0_debtors_master` (
  `debtor_no` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `debtor_ref` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `address` tinytext COLLATE utf8_unicode_ci,
  `tax_id` varchar(55) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `curr_code` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sales_type` int(11) NOT NULL DEFAULT '1',
  `dimension_id` int(11) NOT NULL DEFAULT '0',
  `dimension2_id` int(11) NOT NULL DEFAULT '0',
  `credit_status` int(11) NOT NULL DEFAULT '0',
  `payment_terms` int(11) DEFAULT NULL,
  `discount` double NOT NULL DEFAULT '0',
  `pymt_discount` double NOT NULL DEFAULT '0',
  `credit_limit` float NOT NULL DEFAULT '1000',
  `notes` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`debtor_no`),
  UNIQUE KEY `debtor_ref` (`debtor_ref`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_debtors_master` ###

INSERT INTO `0_debtors_master` VALUES
('1', 'Abadi Jaya Plasindo, PT', 'Abadi Jaya Plasindo, PT', 'PT.ABADI JAYA PLASINDO\r\nKP PENGASINAN RT.005 RW.018 , PENGASINAN\r\nRAWA LUMBU , BEKASI , JAWA BARAT', '', 'IDR', '2', '0', '0', '1', '2', '0', '0', '1000000', '', '0'),
('3', 'ARDA CIPTA KEMASINDO, PT', 'ACK', 'Jl. Raya Dayeuhkolot No.36 Rt.001 Rw.005\r\nPasawahan, Dayeuhkolot Kab.Bandung Jawa Barat', '', 'IDR', '2', '0', '0', '1', '6', '0', '0', '0', '', '0'),
('4', 'ANEKA JASUMA PLASTIK, PT', 'AJP', 'JL. KEDINDING INDAH 25-27 SURABAYA', '', 'IDR', '2', '0', '0', '1', '2', '0', '0', '0', '', '0'),
('5', 'ANEKA JASUMA SEJAHTERA, PT', 'AJS', 'Jl. Raya Mauk km.7 Kawasan Industri Mekar Jaya IV\r\nMekar Jaya - Sepatan, Tangerang - Banten', '', 'IDR', '2', '0', '0', '1', '5', '0', '0', '0', '', '0'),
('6', 'PT ARDA CIPTA KEMASINDO', 'ARDA', 'Jl.Raya Dayeuhkolot No.36 RT/RW:01/05\r\nPasawahan , Dayeuhkolot\r\nBandung', '', 'IDR', '2', '0', '0', '1', '2', '0', '0', '1000000', '', '0'),
('7', 'ARKAPACK, PT', 'ARKA PACK', 'KAWASAN INDUSTRI KENCANA ALAM, JL. RAYA SERANG KM 18,8, CIKUPA - TANGERANG', '', 'IDR', '2', '0', '0', '1', '2', '0', '0', '0', '', '0'),
('8', 'AWIE JAYA PLASTIK', 'AWIE', 'Jl.Medan Deli-Tua KM7,2 No.2\r\nMedan', '', 'IDR', '2', '0', '0', '1', '2', '0', '0', '1000000', '', '0'),
('9', 'ANEKA WARNA SEMESTA, PT', 'AWS', 'Jl. Kamal Raya No.18 Tegal Alur\r\nJakarta Barat DKI Jakarta', '', 'IDR', '2', '0', '0', '1', '2', '0', '0', '0', '', '0'),
('10', 'BAPAK BENNY', 'BAPAK BENNY', 'SURABAYA', '', 'IDR', '2', '0', '0', '1', '2', '0', '0', '0', '', '0'),
('11', 'BAPAK CANDRA', 'BAPAK CANDRA', 'BAPAK CANDRA\r\nSURABAYA\r\n', '', 'IDR', '2', '0', '0', '1', '2', '0', '0', '0', '', '0'),
('12', 'BAPAK DWI', 'BAPAK DWI', NULL, '', 'IDR', '2', '0', '0', '1', '2', '0', '0', '0', '', '0'),
('13', 'BAPAK IWAN', 'BAPAK IWAN', NULL, '', 'IDR', '2', '0', '0', '1', '1', '0', '0', '1000000', '', '0'),
('14', 'Bapak. MARTUKI', 'Bapak. MARTUKI', 'Banyu Urip Jaya 526-A\r\nRT 005 RW 005 , Putat jaya , \r\nSawahan , Surabaya', '', 'IDR', '2', '0', '0', '1', '2', '0', '0', '1000000', '', '0'),
('15', 'BHIRAWA ADIPRAMA, PT', 'BHIRAWA', 'Jl. Veteran No. 18 Kp. Ciserah Rt.002 Rw.001\r\nCukanggalih, Curug, Kab. Tangerang', '', 'IDR', '2', '0', '0', '1', '5', '0', '0', '0', '', '0'),
('16', 'BINTANG INDAH GEMILANG, PT', 'BIG', 'Jl. Raya By Pass Krian Km.28 Kel. Sidomoyo Kec. Krian Sidoarjo', '', 'IDR', '2', '0', '0', '1', '6', '0', '0', '1000000', '', '0'),
('17', 'CIPTA VERINDO LESTARI, PT', 'CIPTA VERINDO', 'MUARA KARANG RAYA BLOK I 1 SELATAN NO.62A, JAKARTA UTARA 14450', '', 'IDR', '2', '0', '0', '1', '6', '0', '0', '1000000', '', '0'),
('18', 'CV CYSINDO SUKSES ABADI', 'CYSINDO', 'JL.Raya Gaga Kolot Kampung Kebon Cabe Kajangan 8 no.18 RT.008 RW.001 Gaga Pakuhaji, Kab.Tangerang', '', 'IDR', '2', '0', '0', '1', '6', '0', '0', '0', '', '0'),
('19', 'CV.DUA PUTRA JAYA', 'DUA PUTRA JAYA', 'RUKO CITRA GARDEN 6 BLOK J5A NO.17 RT.009 RW.005 , TEGAL ALUR , KALIDERES , JAKARTA BARAT DKI JAKARTA', '', 'IDR', '2', '0', '0', '1', '1', '0', '0', '0', '', '0'),
('20', 'PT DWI SUMBER REJEKI', 'DWI SUMBER REJEKI', 'Jl.Salembaran Komplek Pergudangan , Salembaran II RT.004 RW.004 , Salembaran Jati - Kosambi , Kabupaten Tangerang', '', 'IDR', '2', '0', '0', '1', '1', '0', '0', '0', '', '0'),
('21', 'EDDY HARTADJAYA / ETA JAYA', 'EDDY HARTADJAYA / ETA JAYA', 'Jl. Ceylon No.26 Kebon Kelapa Gambir Jakarta Pusat 10120', '', 'IDR', '2', '0', '0', '1', '2', '0', '0', '1000000', '', '0'),
('22', 'ERA PRIMA ADI CIPTA KREASINDO, PT', 'ERA PRIMA ADI CIPTA KREASINDO', 'Mutiara Taman Palem Blok C8 No.2 Rt 006 Rw 014\r\nCengkareng Timur, Cengkareng, Jakarta Barat, DKI Jakarta Raya', '', 'IDR', '2', '0', '0', '1', '6', '0', '0', '1000000', '', '0'),
('23', 'FA. INDOMAS', 'FA. INDOMAS', 'Jl. Pulau Nusa Barung No.5 Km.10.5, Kawasan Industri Medan\r\nKel.Mabar-Kec.Medan Deli, Medan-Sumatera Utara-20242', '', 'IDR', '2', '0', '0', '1', '5', '0', '0', '0', '', '0'),
('24', 'FERAWATY', 'FERAWATY', 'JL.MEDAN DELI TUA KM.7\r\nRT.RW.TITI KUNING , MEDAN JOHOR\r\nMEDAN', '', 'IDR', '2', '0', '0', '1', '1', '0', '0', '0', '', '0'),
('25', 'PT.GLOBAL PRINTPACK INDONESIA', 'GLOBAL', 'Jl.Pajajaran No.98, Pasirandu Rt.003 RW.003 , Kadu , Curug\r\nKab.Tangerang - Banten', '', 'IDR', '2', '0', '0', '1', '1', '0', '0', '0', '', '0'),
('26', 'GOH YU LIONG', 'GOH YU LIONG', 'Jl.Semanan II / 55 RT.007/006, Semanan \r\nKalideres, Jakarta Barat, DKI Jakarta Raya 11850', '', 'IDR', '2', '0', '0', '1', '5', '0', '0', '0', '', '0'),
('27', 'GOLDEN FLEXIBLE PACKAGING, PT', 'GOLDEN FLEXIBLE', 'Jl. Raya Cituis, Kp. Sungai Turi RT 02/06\r\nDS. Laksana, Pakuhaji Tangerang', '', 'IDR', '2', '0', '0', '1', '6', '0', '0', '1000000', '', '0'),
('28', 'GOLDENPACK PERKASA, PT', 'GOLDENPACK', 'Lingkungan 04 Kranji RT 001 RW 010\r\nCiriung, Cibinong, Bogor, Jawa Barat', '', 'IDR', '2', '0', '0', '1', '5', '0', '0', '0', '', '0'),
('29', 'GRAND PREMIER PLASPACK, PT', 'GRAND PREMIER', 'Ds. Krikilan Rt.005 Rw.002 - Krikilan\r\nDriyorejo - Gresik - Jawa Timur', '', 'IDR', '2', '0', '0', '1', '2', '0', '0', '0', '', '0'),
('30', 'MAYORA INDAH TBK, PT', 'MAYORA', 'Jl. Telesonik, Kel. Pasir Jaya Jati Uwung\r\nTangerang Banten 15135', '', 'IDR', '2', '0', '0', '1', '2', '0', '0', '0', '', '0'),
('31', 'TUNAS ALFIN TBK, PT', 'TUNAS ALFIN', 'Jl. H. Agus Salim No.9\r\nPoris Plawad - Cipondoh, Tangerang', '', 'IDR', '2', '0', '0', '1', '5', '0', '0', '0', '', '0'),
('32', 'MITRA MULTI PACKAGING, PT', 'MITRA MULTI ', 'Jl. Raya Serang Km.24 Kp.Hauan Tobat Balaraja Kab.Tangerang Banten', '', 'IDR', '2', '0', '0', '1', '7', '0', '0', '1000000', '', '0'),
('33', 'PT SAPTA WARNA CEMERLANG', 'SWC', 'Jl.Industri Raya Blok C NO.1\r\nKel.Pasirjaya , Kec.Jatiuwung\r\nTangerang - 15135', '', 'IDR', '2', '0', '0', '1', '5', '0', '0', '1000000', '', '0'),
('34', 'SINAR PELANGI KEMASINDO, PT', 'SPK', 'Jl. Tanjung Pura no. 8  RT. 005/05, Pegadungan \r\nKalideres, Jakarta Barat', '', 'IDR', '2', '0', '0', '1', '5', '0', '0', '1000000', '', '0'),
('35', 'SINDOMAS INTI PERKASA, PT', 'SINDOMAS', 'Jl.Sei Belumai Hilir No.103 A, Tanjung Morawa A\r\nTanjung Morawa, Deli Serdang - 20362', '', 'IDR', '2', '0', '0', '1', '5', '0', '0', '1000000', '', '0'),
('36', 'PT.THE UNIVENUS', 'UNIVENUS', 'Jl.Raya Serang KM.12, RT.005/001\r\nSuka Damai - Cikupta Tangerang', '', 'IDR', '2', '0', '0', '1', '5', '0', '0', '1000000', '', '0'),
('37', 'SARANA PRIMA NUSANTARA ABADI, PT', 'SPN', 'Kp. Cikedokan  RT/RW : 005/012, Sukadanau \r\nCikarang Barat Bekasi - Jawa Barat', '', 'IDR', '2', '0', '0', '1', '5', '0', '0', '1000000', '', '0'),
('38', 'PUTRA NAGA INDOTAMA, PT', 'PNI', 'Kawasan Industi Mekarjaya Km 7 Jl.Karet 2 /10\r\nMekar Jaya - Sepatan, Tangerang', '', 'IDR', '2', '0', '0', '1', '5', '0', '0', '1000000', '', '0');

### Structure of table `0_dimensions` ###

DROP TABLE IF EXISTS `0_dimensions`;

CREATE TABLE `0_dimensions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type_` tinyint(1) NOT NULL DEFAULT '1',
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  `date_` date NOT NULL DEFAULT '0000-00-00',
  `due_date` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `date_` (`date_`),
  KEY `due_date` (`due_date`),
  KEY `type_` (`type_`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_dimensions` ###

INSERT INTO `0_dimensions` VALUES
('1', '1', 'Box', '1', '0', '2021-01-05', '2021-01-25');

### Structure of table `0_exchange_rates` ###

DROP TABLE IF EXISTS `0_exchange_rates`;

CREATE TABLE `0_exchange_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `curr_code` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `rate_buy` double NOT NULL DEFAULT '0',
  `rate_sell` double NOT NULL DEFAULT '0',
  `date_` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `curr_code` (`curr_code`,`date_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_exchange_rates` ###


### Structure of table `0_fiscal_year` ###

DROP TABLE IF EXISTS `0_fiscal_year`;

CREATE TABLE `0_fiscal_year` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `begin` date DEFAULT '0000-00-00',
  `end` date DEFAULT '0000-00-00',
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `begin` (`begin`),
  UNIQUE KEY `end` (`end`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_fiscal_year` ###

INSERT INTO `0_fiscal_year` VALUES
('1', '2017-01-01', '2017-12-31', '1'),
('2', '2018-01-01', '2018-12-31', '0'),
('3', '2019-01-01', '2019-12-31', '0'),
('4', '2020-01-01', '2020-12-31', '0'),
('5', '2021-01-01', '2021-12-31', '0');

### Structure of table `0_gl_trans` ###

DROP TABLE IF EXISTS `0_gl_trans`;

CREATE TABLE `0_gl_trans` (
  `counter` int(11) NOT NULL AUTO_INCREMENT,
  `type` smallint(6) NOT NULL DEFAULT '0',
  `type_no` int(11) NOT NULL DEFAULT '0',
  `tran_date` date NOT NULL DEFAULT '0000-00-00',
  `account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `memo_` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `dimension_id` int(11) NOT NULL DEFAULT '0',
  `dimension2_id` int(11) NOT NULL DEFAULT '0',
  `person_type_id` int(11) DEFAULT NULL,
  `person_id` tinyblob,
  PRIMARY KEY (`counter`),
  KEY `Type_and_Number` (`type`,`type_no`),
  KEY `dimension_id` (`dimension_id`),
  KEY `dimension2_id` (`dimension2_id`),
  KEY `tran_date` (`tran_date`),
  KEY `account_and_tran_date` (`account`,`tran_date`)
) ENGINE=InnoDB AUTO_INCREMENT=317 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_gl_trans` ###

INSERT INTO `0_gl_trans` VALUES
('1', '25', '1', '2020-12-28', '1420', 'CPP', '46800000', '0', '0', NULL, NULL),
('2', '25', '1', '2020-12-28', '1416', '', '-46800000', '0', '0', NULL, NULL),
('3', '20', '1', '2021-01-04', '1504', '', '0', '0', '0', NULL, NULL),
('4', '20', '1', '2021-01-04', '2100', '', '0', '0', '0', '3', '2'),
('5', '20', '1', '2021-01-04', '1416', '', '0', '0', '0', NULL, NULL),
('6', '25', '1', '2020-12-28', '1420', 'GRN Removal', '-46800000', '0', '0', NULL, NULL),
('7', '25', '1', '2020-12-28', '1416', 'GRN Removal', '46800000', '0', '0', NULL, NULL),
('8', '25', '2', '2021-01-04', '1422', 'BP-RMP-002', '46800000', '0', '0', NULL, NULL),
('9', '25', '2', '2021-01-04', '1416', '', '-46800000', '0', '0', NULL, NULL),
('10', '20', '2', '2021-01-04', '1504', '', '4680000', '0', '0', NULL, NULL),
('11', '20', '2', '2021-01-04', '2100', '', '-51480000', '0', '0', '3', '2'),
('12', '20', '2', '2021-01-04', '1416', '', '46800000', '0', '0', NULL, NULL),
('13', '20', '3', '2021-04-01', '2100', '', '0', '0', '0', '3', '5'),
('14', '20', '3', '2021-04-01', '2204', 'biaya makan 1855paket periode 16-29desember 2020', '0', '0', '0', NULL, NULL),
('15', '20', '3', '2021-04-01', '6419', 'biaya makan 1855paket periode 16-29desember 2020	', '0', '0', '0', NULL, NULL),
('16', '20', '4', '2021-01-04', '2100', '', '-3600000', '0', '0', '3', '6'),
('17', '20', '4', '2021-01-04', '5214', 'fuso ke SPK tgl 23/12/2020', '1800000', '0', '0', NULL, NULL),
('18', '20', '4', '2021-01-04', '5214', 'fuso ke Sindomas tgl 23/12/2020', '1800000', '0', '0', NULL, NULL),
('19', '20', '5', '2021-01-04', '2100', '', '-18179000', '0', '0', '3', '5'),
('20', '20', '5', '2021-01-04', '2204', 'biaya makan 1855paket periode 16-29desember 2020', '-371000', '0', '0', NULL, NULL),
('21', '20', '5', '2021-01-04', '6419', 'biaya makan 1855paket periode 16-29desember 2020	', '18550000', '0', '0', NULL, NULL),
('22', '25', '3', '2021-01-04', '1410', 'RA27', '11412500', '0', '0', NULL, NULL),
('23', '25', '3', '2021-01-04', '1416', '', '-11412500', '0', '0', NULL, NULL),
('24', '25', '4', '2021-01-05', '1410', 'RA27', '9337500', '0', '0', NULL, NULL),
('25', '25', '4', '2021-01-05', '1416', '', '-9337500', '0', '0', NULL, NULL),
('26', '20', '6', '2021-01-05', '1504', '', '933750', '0', '0', NULL, NULL),
('27', '20', '6', '2021-01-05', '2100', '', '-10271250', '0', '0', '3', '14'),
('28', '20', '6', '2021-01-05', '1416', '', '9337500', '0', '0', NULL, NULL),
('29', '25', '5', '2021-01-05', '1410', 'RA24', '33000000', '0', '0', NULL, NULL),
('30', '25', '5', '2021-01-05', '1416', '', '-33000000', '0', '0', NULL, NULL),
('31', '20', '7', '2021-01-05', '1504', '', '3300000', '0', '0', NULL, NULL),
('32', '20', '7', '2021-01-05', '2100', '', '-36300000', '0', '0', '3', '15'),
('33', '20', '7', '2021-01-05', '1416', '', '33000000', '0', '0', NULL, NULL),
('34', '25', '6', '2021-01-05', '1421', 'BANTALAN', '200000', '0', '0', NULL, NULL),
('35', '25', '6', '2021-01-05', '1416', '', '-200000', '0', '0', NULL, NULL),
('36', '20', '8', '2021-01-05', '2100', '', '-200000', '0', '0', '3', '4'),
('37', '20', '8', '2021-01-05', '1416', '', '200000', '0', '0', NULL, NULL),
('38', '25', '7', '2021-01-05', '1421', 'PL106', '400000', '0', '0', NULL, NULL),
('39', '25', '7', '2021-01-05', '1416', '', '-400000', '0', '0', NULL, NULL),
('40', '20', '9', '2021-01-05', '2100', '', '-400000', '0', '0', '3', '4'),
('41', '20', '9', '2021-01-05', '1416', '', '400000', '0', '0', NULL, NULL),
('42', '25', '8', '2021-01-05', '1421', 'PK1100X1100', '675000', '0', '0', NULL, NULL),
('43', '25', '8', '2021-01-05', '1416', '', '-675000', '0', '0', NULL, NULL),
('44', '20', '10', '2021-01-05', '2100', '', '-675000', '0', '0', '3', '4'),
('45', '20', '10', '2021-01-05', '1416', '', '675000', '0', '0', NULL, NULL),
('46', '25', '9', '2021-01-05', '1421', 'PK1000X1100', '1440000', '0', '0', NULL, NULL),
('47', '25', '9', '2021-01-05', '1416', '', '-1440000', '0', '0', NULL, NULL),
('48', '20', '11', '2021-01-05', '2100', '', '-1440000', '0', '0', '3', '4'),
('49', '20', '11', '2021-01-05', '1416', '', '1440000', '0', '0', NULL, NULL),
('50', '25', '10', '2021-01-05', '1421', 'PL87', '240000', '0', '0', NULL, NULL),
('51', '25', '10', '2021-01-05', '1421', 'PL90', '240000', '0', '0', NULL, NULL),
('52', '25', '10', '2021-01-05', '1421', 'PL930', '240000', '0', '0', NULL, NULL),
('53', '25', '10', '2021-01-05', '1421', 'PL99', '240000', '0', '0', NULL, NULL),
('54', '25', '10', '2021-01-05', '1421', 'PL117', '240000', '0', '0', NULL, NULL),
('55', '25', '10', '2021-01-05', '1416', '', '-1200000', '0', '0', NULL, NULL),
('56', '20', '12', '2021-01-05', '2100', '', '-1200000', '0', '0', '3', '4'),
('57', '20', '12', '2021-01-05', '1416', '', '240000', '0', '0', NULL, NULL),
('58', '20', '12', '2021-01-05', '1416', '', '240000', '0', '0', NULL, NULL),
('59', '20', '12', '2021-01-05', '1416', '', '240000', '0', '0', NULL, NULL),
('60', '20', '12', '2021-01-05', '1416', '', '240000', '0', '0', NULL, NULL),
('61', '20', '12', '2021-01-05', '1416', '', '240000', '0', '0', NULL, NULL),
('62', '25', '11', '2021-01-05', '1421', 'PL126', '400000', '0', '0', NULL, NULL),
('63', '25', '11', '2021-01-05', '1416', '', '-400000', '0', '0', NULL, NULL),
('64', '20', '13', '2021-01-05', '2100', '', '-400000', '0', '0', '3', '4'),
('65', '20', '13', '2021-01-05', '1416', '', '400000', '0', '0', NULL, NULL),
('66', '25', '12', '2021-01-05', '1421', 'PL921', '1200000', '0', '0', NULL, NULL),
('67', '25', '12', '2021-01-05', '1421', 'PL87', '400000', '0', '0', NULL, NULL),
('68', '25', '12', '2021-01-05', '1421', 'PL90', '320000', '0', '0', NULL, NULL),
('69', '25', '12', '2021-01-05', '1421', 'PL120', '400000', '0', '0', NULL, NULL),
('70', '25', '12', '2021-01-05', '1421', 'PL180', '750000', '0', '0', NULL, NULL),
('71', '25', '12', '2021-01-05', '1416', '', '-3070000', '0', '0', NULL, NULL),
('72', '20', '14', '2021-01-05', '2100', '', '-3070000', '0', '0', '3', '4'),
('73', '20', '14', '2021-01-05', '1416', '', '1200000', '0', '0', NULL, NULL),
('74', '20', '14', '2021-01-05', '1416', '', '400000', '0', '0', NULL, NULL),
('75', '20', '14', '2021-01-05', '1416', '', '320000', '0', '0', NULL, NULL),
('76', '20', '14', '2021-01-05', '1416', '', '400000', '0', '0', NULL, NULL),
('77', '20', '14', '2021-01-05', '1416', '', '750000', '0', '0', NULL, NULL),
('78', '25', '13', '2021-01-05', '1421', 'PK1200X1100', '8550000', '0', '0', NULL, NULL),
('79', '25', '13', '2021-01-05', '1421', 'PK1100X550', '400000', '0', '0', NULL, NULL),
('80', '25', '13', '2021-01-05', '1421', 'PK1200X980', '495000', '0', '0', NULL, NULL),
('81', '25', '13', '2021-01-05', '1416', '', '-9445000', '0', '0', NULL, NULL),
('82', '20', '15', '2021-01-05', '2100', '', '-9445000', '0', '0', '3', '4'),
('83', '20', '15', '2021-01-05', '1416', '', '8550000', '0', '0', NULL, NULL),
('84', '20', '15', '2021-01-05', '1416', '', '400000', '0', '0', NULL, NULL),
('85', '20', '15', '2021-01-05', '1416', '', '495000', '0', '0', NULL, NULL),
('86', '25', '14', '2021-01-05', '1421', 'PK1200X720', '450000', '0', '0', NULL, NULL),
('87', '25', '14', '2021-01-05', '1416', '', '-450000', '0', '0', NULL, NULL),
('88', '20', '16', '2021-01-05', '2100', '', '-450000', '0', '0', '3', '4'),
('89', '20', '16', '2021-01-05', '1416', '', '450000', '0', '0', NULL, NULL),
('90', '25', '15', '2021-01-05', '1421', 'PK1100X1100', '4050000', '0', '0', NULL, NULL),
('91', '25', '15', '2021-01-05', '1416', '', '-4050000', '0', '0', NULL, NULL),
('92', '20', '17', '2021-01-05', '2100', '', '-4050000', '0', '0', '3', '4'),
('93', '20', '17', '2021-01-05', '1416', '', '4050000', '0', '0', NULL, NULL),
('94', '25', '16', '2021-01-05', '1421', 'PK1000X1100', '2250000', '0', '0', NULL, NULL),
('95', '25', '16', '2021-01-05', '1416', '', '-2250000', '0', '0', NULL, NULL),
('96', '20', '18', '2021-01-05', '2100', '', '-2250000', '0', '0', '3', '4'),
('97', '20', '18', '2021-01-05', '1416', '', '2250000', '0', '0', NULL, NULL),
('98', '25', '17', '2021-01-06', '1421', 'PK1200X1100', '2295000', '0', '0', NULL, NULL),
('99', '25', '17', '2021-01-06', '1421', 'PK1100X550', '150000', '0', '0', NULL, NULL),
('100', '25', '17', '2021-01-06', '1416', '', '-2445000', '0', '0', NULL, NULL),
('101', '20', '19', '2021-01-06', '2100', '', '-2445000', '0', '0', '3', '4'),
('102', '20', '19', '2021-01-06', '1416', '', '2295000', '0', '0', NULL, NULL),
('103', '20', '19', '2021-01-06', '1416', '', '150000', '0', '0', NULL, NULL),
('104', '25', '18', '2021-01-06', '1421', 'PLY50X50', '2135000', '0', '0', NULL, NULL),
('105', '25', '18', '2021-01-06', '1421', 'PLY55X55', '196000', '0', '0', NULL, NULL),
('106', '25', '18', '2021-01-06', '1421', 'PROFILH', '650000', '0', '0', NULL, NULL),
('107', '25', '18', '2021-01-06', '1416', '', '-2981000', '0', '0', NULL, NULL),
('108', '20', '20', '2021-01-06', '2100', '', '-2981000', '0', '0', '3', '4'),
('109', '20', '20', '2021-01-06', '1416', '', '2135000', '0', '0', NULL, NULL),
('110', '20', '20', '2021-01-06', '1416', '', '196000', '0', '0', NULL, NULL),
('111', '20', '20', '2021-01-06', '1416', '', '650000', '0', '0', NULL, NULL),
('112', '20', '21', '2021-01-01', '2100', '', '-24462900', '0', '0', '3', '17'),
('113', '20', '21', '2021-01-01', '3500', '', '24462900', '0', '0', NULL, NULL),
('114', '20', '22', '2021-01-01', '2100', '', '-47552535', '0', '0', '3', '18'),
('115', '20', '22', '2021-01-01', '3500', '', '47552535', '0', '0', NULL, NULL),
('116', '20', '23', '2021-01-01', '2100', '', '-21671840.3', '0', '0', '3', '19'),
('117', '20', '23', '2021-01-01', '3500', '', '21671840.3', '0', '0', NULL, NULL),
('118', '20', '24', '2021-01-01', '2100', '', '-49430865', '0', '0', '3', '19'),
('119', '20', '24', '2021-01-01', '3500', '', '49430865', '0', '0', NULL, NULL),
('120', '20', '25', '2021-01-01', '2100', '', '-36515600', '0', '0', '3', '19'),
('121', '20', '25', '2021-01-01', '3500', '', '36515600', '0', '0', NULL, NULL),
('122', '20', '26', '2021-01-01', '2100', '', '-100100000', '0', '0', '3', '20'),
('123', '20', '26', '2021-01-01', '3500', '', '100100000', '0', '0', NULL, NULL),
('124', '20', '27', '2021-01-01', '2100', '', '0', '0', '0', '3', '20'),
('125', '20', '27', '2021-01-01', '3500', '', '0', '0', '0', NULL, NULL),
('126', '20', '28', '2021-01-01', '2100', '', '-5400000', '0', '0', '3', '21'),
('127', '20', '28', '2021-01-01', '3500', '', '5400000', '0', '0', NULL, NULL),
('128', '20', '29', '2021-01-01', '2100', '', '-22110000', '0', '0', '3', '21'),
('129', '20', '29', '2021-01-01', '3500', '', '22110000', '0', '0', NULL, NULL),
('130', '20', '30', '2021-01-01', '2100', '', '-45980000', '0', '0', '3', '21'),
('131', '20', '30', '2021-01-01', '3500', '', '45980000', '0', '0', NULL, NULL),
('132', '20', '31', '2021-01-01', '2100', '', '-101200000', '0', '0', '3', '2'),
('133', '20', '31', '2021-01-01', '3500', '', '101200000', '0', '0', NULL, NULL),
('134', '20', '32', '2021-01-01', '2100', '', '-51480000', '0', '0', '3', '2'),
('135', '20', '32', '2021-01-01', '3500', '', '51480000', '0', '0', NULL, NULL),
('136', '20', '33', '2021-01-01', '2100', '', '-3800000', '0', '0', '3', '6'),
('137', '20', '33', '2021-01-01', '3500', '', '3800000', '0', '0', NULL, NULL),
('138', '20', '34', '2021-01-01', '2100', '', '-10870000', '0', '0', '3', '6'),
('139', '20', '34', '2021-01-01', '3500', '', '10870000', '0', '0', NULL, NULL),
('140', '20', '35', '2021-01-01', '2100', '', '-7200000', '0', '0', '3', '6'),
('141', '20', '35', '2021-01-01', '3500', '', '7200000', '0', '0', NULL, NULL),
('142', '20', '36', '2021-01-01', '2100', '', '-55954800', '0', '0', '3', '7'),
('143', '20', '36', '2021-01-01', '3500', '', '55954800', '0', '0', NULL, NULL),
('144', '20', '37', '2021-01-01', '2100', '', '-112281400', '0', '0', '3', '7'),
('145', '20', '37', '2021-01-01', '3500', '', '112281400', '0', '0', NULL, NULL),
('146', '20', '38', '2021-01-01', '2100', '', '-58300000', '0', '0', '3', '7'),
('147', '20', '38', '2021-01-01', '3500', '', '58300000', '0', '0', NULL, NULL),
('148', '20', '39', '2021-01-01', '2100', '', '-172870500', '0', '0', '3', '7'),
('149', '20', '39', '2021-01-01', '3500', '', '172870500', '0', '0', NULL, NULL),
('150', '20', '40', '2021-01-01', '2100', '', '-5712000', '0', '0', '3', '22'),
('151', '20', '40', '2021-01-01', '3500', '', '5712000', '0', '0', NULL, NULL),
('152', '20', '41', '2021-01-01', '2100', '', '-3570000', '0', '0', '3', '23'),
('153', '20', '41', '2021-01-01', '3500', '', '3570000', '0', '0', NULL, NULL),
('154', '20', '42', '2021-01-01', '2100', '', '-3862700', '0', '0', '3', '23'),
('155', '20', '42', '2021-01-01', '3500', '', '3862700', '0', '0', NULL, NULL),
('156', '20', '43', '2021-01-01', '2100', '', '-990000', '0', '0', '3', '23'),
('157', '20', '43', '2021-01-01', '3500', '', '990000', '0', '0', NULL, NULL),
('158', '20', '44', '2021-01-01', '1504', '', '1141250', '0', '0', NULL, NULL),
('159', '20', '44', '2021-01-01', '2100', '', '-12553750', '0', '0', '3', '14'),
('160', '20', '44', '2021-01-01', '1416', '', '11412500', '0', '0', NULL, NULL),
('161', '20', '45', '2021-01-01', '2100', '', '-23650000', '0', '0', '3', '14'),
('162', '20', '45', '2021-01-01', '3500', '', '23650000', '0', '0', NULL, NULL),
('163', '20', '46', '2021-01-01', '2100', '', '-3996000', '0', '0', '3', '26'),
('164', '20', '46', '2021-01-01', '3500', '', '3996000', '0', '0', NULL, NULL),
('165', '20', '47', '2021-01-01', '2100', '', '-7507500', '0', '0', '3', '27'),
('166', '20', '47', '2021-01-01', '3500', '', '7507500', '0', '0', NULL, NULL),
('167', '20', '48', '2021-01-01', '2100', '', '-4504500', '0', '0', '3', '27'),
('168', '20', '48', '2021-01-01', '3500', '', '4504500', '0', '0', NULL, NULL),
('169', '20', '49', '2021-01-01', '2100', '', '-2485000', '0', '0', '3', '28'),
('170', '20', '49', '2021-01-01', '3500', '', '2485000', '0', '0', NULL, NULL),
('171', '20', '50', '2021-01-01', '2100', '', '-4927800', '0', '0', '3', '28'),
('172', '20', '50', '2021-01-01', '3500', '', '4927800', '0', '0', NULL, NULL),
('173', '20', '51', '2021-01-01', '2100', '', '-25221625', '0', '0', '3', '29'),
('174', '20', '51', '2021-01-01', '3500', '', '25221625', '0', '0', NULL, NULL),
('175', '20', '52', '2021-01-01', '2100', '', '-33000000', '0', '0', '3', '30'),
('176', '20', '52', '2021-01-01', '3500', '', '33000000', '0', '0', NULL, NULL),
('177', '20', '53', '2021-01-01', '2100', '', '-19800000', '0', '0', '3', '30'),
('178', '20', '53', '2021-01-01', '3500', '', '19800000', '0', '0', NULL, NULL),
('179', '20', '54', '2021-01-06', '2100', '', '-94050000', '0', '0', '3', '30'),
('180', '20', '54', '2021-01-06', '3500', '', '94050000', '0', '0', NULL, NULL),
('181', '20', '55', '2021-01-01', '2100', '', '-3850000', '0', '0', '3', '30'),
('182', '20', '55', '2021-01-01', '3500', '', '3850000', '0', '0', NULL, NULL),
('183', '20', '56', '2021-01-01', '2100', '', '-38885000', '0', '0', '3', '30'),
('184', '20', '56', '2021-01-01', '3500', '', '38885000', '0', '0', NULL, NULL),
('185', '20', '57', '2021-01-01', '2100', '', '-121066000', '0', '0', '3', '30'),
('186', '20', '57', '2021-01-01', '3500', '', '121066000', '0', '0', NULL, NULL),
('187', '20', '58', '2021-01-01', '2100', '', '-113685000', '0', '0', '3', '30'),
('188', '20', '58', '2021-01-01', '3500', '', '113685000', '0', '0', NULL, NULL),
('189', '20', '59', '2021-01-01', '2100', '', '-18150000', '0', '0', '3', '15'),
('190', '20', '59', '2021-01-01', '3500', '', '18150000', '0', '0', NULL, NULL),
('191', '20', '60', '2021-01-01', '2100', '', '-4345000', '0', '0', '3', '32'),
('192', '20', '60', '2021-01-01', '3500', '', '4345000', '0', '0', NULL, NULL),
('193', '20', '61', '2021-01-01', '2100', '', '-20129200', '0', '0', '3', '5'),
('194', '20', '61', '2021-01-01', '3500', '', '20129200', '0', '0', NULL, NULL),
('195', '25', '19', '2021-01-06', '1421', 'PK730X1010', '45000', '0', '0', NULL, NULL),
('196', '25', '19', '2021-01-06', '1421', 'PK1460X1060', '200000', '0', '0', NULL, NULL),
('197', '25', '19', '2021-01-06', '1421', 'PK1460X1100', '100000', '0', '0', NULL, NULL),
('198', '25', '19', '2021-01-06', '1421', 'PK1460X1120', '300000', '0', '0', NULL, NULL),
('199', '25', '19', '2021-01-06', '1421', 'PK1460X1200', '400000', '0', '0', NULL, NULL),
('200', '25', '19', '2021-01-06', '1421', 'PK730X1200', '100000', '0', '0', NULL, NULL),
('201', '25', '19', '2021-01-06', '1421', 'PK1460X1210', '200000', '0', '0', NULL, NULL),
('202', '25', '19', '2021-01-06', '1416', '', '-1345000', '0', '0', NULL, NULL),
('203', '20', '62', '2021-01-06', '2100', '', '-1290000', '0', '0', '3', '4'),
('204', '20', '62', '2021-01-06', '1416', '', '300000', '0', '0', NULL, NULL),
('205', '20', '62', '2021-01-06', '1416', '', '100000', '0', '0', NULL, NULL),
('206', '20', '62', '2021-01-06', '1416', '', '200000', '0', '0', NULL, NULL),
('207', '20', '62', '2021-01-06', '1416', '', '400000', '0', '0', NULL, NULL),
('208', '20', '62', '2021-01-06', '1416', '', '200000', '0', '0', NULL, NULL),
('209', '20', '62', '2021-01-06', '1416', '', '100000', '0', '0', NULL, NULL),
('210', '20', '62', '2021-01-06', '1421', 'GRN Provision', '-55000', '0', '0', NULL, NULL),
('211', '20', '62', '2021-01-06', '1416', '', '45000', '0', '0', NULL, NULL),
('212', '25', '20', '2021-01-06', '1421', 'PL930', '120000', '0', '0', NULL, NULL),
('213', '25', '20', '2021-01-06', '1421', 'PL945', '48000', '0', '0', NULL, NULL),
('214', '25', '20', '2021-01-06', '1421', 'PL99', '16000', '0', '0', NULL, NULL),
('215', '25', '20', '2021-01-06', '1421', 'PL97', '4000', '0', '0', NULL, NULL),
('216', '25', '20', '2021-01-06', '1421', 'PL1031', '4000', '0', '0', NULL, NULL),
('217', '25', '20', '2021-01-06', '1421', 'PL1066', '4000', '0', '0', NULL, NULL),
('218', '25', '20', '2021-01-06', '1421', 'PL1116', '4000', '0', '0', NULL, NULL),
('219', '25', '20', '2021-01-06', '1416', '', '-200000', '0', '0', NULL, NULL),
('220', '20', '63', '2021-01-06', '2100', '', '-200000', '0', '0', '3', '4'),
('221', '20', '63', '2021-01-06', '1416', '', '120000', '0', '0', NULL, NULL),
('222', '20', '63', '2021-01-06', '1416', '', '48000', '0', '0', NULL, NULL),
('223', '20', '63', '2021-01-06', '1416', '', '16000', '0', '0', NULL, NULL),
('224', '20', '63', '2021-01-06', '1416', '', '4000', '0', '0', NULL, NULL),
('225', '20', '63', '2021-01-06', '1416', '', '4000', '0', '0', NULL, NULL),
('226', '20', '63', '2021-01-06', '1416', '', '4000', '0', '0', NULL, NULL),
('227', '20', '63', '2021-01-06', '1416', '', '4000', '0', '0', NULL, NULL),
('228', '25', '21', '2021-01-06', '1421', 'PL111', '1360000', '0', '0', NULL, NULL),
('229', '25', '21', '2021-01-06', '1421', 'PL110', '40000', '0', '0', NULL, NULL),
('230', '25', '21', '2021-01-06', '1416', '', '-1400000', '0', '0', NULL, NULL),
('231', '20', '64', '2021-01-06', '2100', '', '-1400000', '0', '0', '3', '4'),
('232', '20', '64', '2021-01-06', '1416', '', '1360000', '0', '0', NULL, NULL),
('233', '20', '64', '2021-01-06', '1416', '', '40000', '0', '0', NULL, NULL),
('234', '25', '22', '2021-01-06', '1421', 'PK1460X1010', '100000', '0', '0', NULL, NULL),
('235', '25', '22', '2021-01-06', '1421', 'PK1460X1020', '500000', '0', '0', NULL, NULL),
('236', '25', '22', '2021-01-06', '1421', 'PK1460X1040', '200000', '0', '0', NULL, NULL),
('237', '25', '22', '2021-01-06', '1421', 'PK1460X1080', '200000', '0', '0', NULL, NULL),
('238', '25', '22', '2021-01-06', '1421', 'PK1460X1150', '200000', '0', '0', NULL, NULL),
('239', '25', '22', '2021-01-06', '1421', 'PK1460X1170', '100000', '0', '0', NULL, NULL),
('240', '25', '22', '2021-01-06', '1421', 'PK1340X1230', '100000', '0', '0', NULL, NULL),
('241', '25', '22', '2021-01-06', '1421', 'PK730X1250', '100000', '0', '0', NULL, NULL),
('242', '25', '22', '2021-01-06', '1421', 'PK1460X1260', '100000', '0', '0', NULL, NULL),
('243', '25', '22', '2021-01-06', '1421', 'PK1460X1270', '200000', '0', '0', NULL, NULL),
('244', '25', '22', '2021-01-06', '1416', '', '-1800000', '0', '0', NULL, NULL),
('245', '20', '65', '2021-01-06', '2100', '', '-1745000', '0', '0', '3', '4'),
('246', '20', '65', '2021-01-06', '1416', '', '100000', '0', '0', NULL, NULL),
('247', '20', '65', '2021-01-06', '1416', '', '500000', '0', '0', NULL, NULL),
('248', '20', '65', '2021-01-06', '1416', '', '200000', '0', '0', NULL, NULL),
('249', '20', '65', '2021-01-06', '1416', '', '200000', '0', '0', NULL, NULL),
('250', '20', '65', '2021-01-06', '1416', '', '200000', '0', '0', NULL, NULL),
('251', '20', '65', '2021-01-06', '1416', '', '100000', '0', '0', NULL, NULL),
('252', '20', '65', '2021-01-06', '1416', '', '100000', '0', '0', NULL, NULL),
('253', '20', '65', '2021-01-06', '1416', '', '100000', '0', '0', NULL, NULL),
('254', '20', '65', '2021-01-06', '1416', '', '200000', '0', '0', NULL, NULL),
('255', '20', '65', '2021-01-06', '1416', '', '100000', '0', '0', NULL, NULL),
('256', '20', '65', '2021-01-06', '1421', 'GRN Provision', '-55000', '0', '0', NULL, NULL),
('257', '20', '66', '2021-01-01', '2100', '', '0', '0', '0', '3', '2'),
('258', '20', '66', '2021-01-01', '3500', '', '0', '0', '0', NULL, NULL),
('259', '20', '67', '2021-01-01', '2100', '', '-31350000', '0', '0', '3', '36'),
('260', '20', '67', '2021-01-01', '3500', '', '31350000', '0', '0', NULL, NULL),
('261', '20', '68', '2021-01-01', '2100', '', '-20900000', '0', '0', '3', '36'),
('262', '20', '68', '2021-01-01', '3500', '', '20900000', '0', '0', NULL, NULL),
('263', '20', '69', '2021-01-01', '2100', '', '-3960000', '0', '0', '3', '37'),
('264', '20', '69', '2021-01-01', '3500', '', '3960000', '0', '0', NULL, NULL),
('265', '13', '1', '2021-01-04', '5101', '', '0', '0', '0', NULL, NULL),
('266', '13', '1', '2021-01-04', '1420', '', '0', '0', '0', NULL, NULL),
('267', '10', '1', '2021-01-07', '4100', '', '0', '0', '0', NULL, NULL),
('268', '10', '1', '2021-01-07', '1200', '', '0', '0', '0', '2', '37'),
('269', '10', '1', '2021-01-07', '2201', '', '0', '0', '0', NULL, NULL),
('270', '13', '1', '2021-01-04', '5101', '', '188068608', '0', '0', NULL, NULL),
('271', '13', '1', '2021-01-04', '1420', '', '-188068608', '0', '0', NULL, NULL),
('272', '10', '2', '2021-01-04', '4100', '', '-91020384', '0', '0', NULL, NULL),
('273', '10', '2', '2021-01-04', '1200', '', '100122422.4', '0', '0', '2', '37'),
('274', '10', '2', '2021-01-04', '2201', '', '-9102038.4', '0', '0', NULL, NULL),
('275', '10', '3', '2021-01-07', '4101', '', '0', '0', '0', NULL, NULL),
('276', '10', '3', '2021-01-07', '1200', '', '0', '0', '0', '2', '37'),
('277', '10', '3', '2021-01-07', '2201', '', '0', '0', '0', NULL, NULL),
('278', '10', '4', '2021-01-04', '4101', '', '-94558464', '0', '0', NULL, NULL),
('279', '10', '4', '2021-01-04', '1200', '', '104014310.4', '0', '0', '2', '37'),
('280', '10', '4', '2021-01-04', '2201', '', '-9455846.4', '0', '0', NULL, NULL),
('281', '10', '5', '2021-01-04', '4101', '', '-59033520', '0', '0', NULL, NULL),
('282', '10', '5', '2021-01-04', '1200', '', '64936872', '0', '0', '2', '32'),
('283', '10', '5', '2021-01-04', '2201', '', '-5903352', '0', '0', NULL, NULL),
('284', '10', '6', '2021-01-07', '4101', '', '0', '0', '0', NULL, NULL),
('285', '10', '6', '2021-01-07', '1200', '', '0', '0', '0', '2', '32'),
('286', '10', '6', '2021-01-07', '2201', '', '0', '0', '0', NULL, NULL),
('287', '13', '5', '2021-01-04', '5101', '', '31153356', '0', '0', NULL, NULL),
('288', '13', '5', '2021-01-04', '1420', '', '-31153356', '0', '0', NULL, NULL),
('289', '10', '7', '2021-01-07', '4100', '', '0', '0', '0', NULL, NULL),
('290', '10', '7', '2021-01-07', '1200', '', '0', '0', '0', '2', '36'),
('291', '10', '7', '2021-01-07', '2201', '', '0', '0', '0', NULL, NULL),
('292', '10', '8', '2021-01-04', '4101', '', '-22388184', '0', '0', NULL, NULL),
('293', '10', '8', '2021-01-04', '1200', '', '24627002.4', '0', '0', '2', '32'),
('294', '10', '8', '2021-01-04', '2201', '', '-2238818.4', '0', '0', NULL, NULL),
('295', '10', '9', '2021-01-04', '4100', '', '-14484979.2', '0', '0', NULL, NULL),
('296', '10', '9', '2021-01-04', '1200', '', '15933477.12', '0', '0', '2', '36'),
('297', '10', '9', '2021-01-04', '2201', '', '-1448497.92', '0', '0', NULL, NULL),
('298', '13', '6', '2021-01-04', '5101', '', '30259008', '0', '0', NULL, NULL),
('299', '13', '6', '2021-01-04', '1420', '', '-30259008', '0', '0', NULL, NULL),
('300', '10', '10', '2021-01-04', '4100', '', '-14069145.6', '0', '0', NULL, NULL),
('301', '10', '10', '2021-01-04', '1200', '', '15476060.16', '0', '0', '2', '36'),
('302', '10', '10', '2021-01-04', '2201', '', '-1406914.56', '0', '0', NULL, NULL),
('303', '13', '7', '2021-01-04', '5101', '', '54257112', '0', '0', NULL, NULL),
('304', '13', '7', '2021-01-04', '1420', '', '-54257112', '0', '0', NULL, NULL),
('305', '10', '11', '2021-01-07', '4100', '', '0', '0', '0', NULL, NULL),
('306', '10', '11', '2021-01-07', '1200', '', '0', '0', '0', '2', '36'),
('307', '10', '11', '2021-01-07', '2201', '', '0', '0', '0', NULL, NULL),
('308', '10', '12', '2021-01-04', '4100', '', '-25227238.4', '0', '0', NULL, NULL),
('309', '10', '12', '2021-01-04', '1200', '', '27749962.24', '0', '0', '2', '36'),
('310', '10', '12', '2021-01-04', '2201', '', '-2522723.84', '0', '0', NULL, NULL),
('311', '10', '13', '2021-01-04', '4101', '', '-23639616', '0', '0', NULL, NULL),
('312', '10', '13', '2021-01-04', '1200', '', '26003577.6', '0', '0', '2', '33'),
('313', '10', '13', '2021-01-04', '2201', '', '-2363961.6', '0', '0', NULL, NULL),
('314', '10', '14', '2021-01-04', '4101', '', '-22975680', '0', '0', NULL, NULL),
('315', '10', '14', '2021-01-04', '1200', '', '25273248', '0', '0', '2', '33'),
('316', '10', '14', '2021-01-04', '2201', '', '-2297568', '0', '0', NULL, NULL);

### Structure of table `0_grn_batch` ###

DROP TABLE IF EXISTS `0_grn_batch`;

CREATE TABLE `0_grn_batch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL DEFAULT '0',
  `purch_order_no` int(11) DEFAULT NULL,
  `reference` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `delivery_date` date NOT NULL DEFAULT '0000-00-00',
  `loc_code` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rate` double DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `delivery_date` (`delivery_date`),
  KEY `purch_order_no` (`purch_order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_grn_batch` ###

INSERT INTO `0_grn_batch` VALUES
('1', '2', '1', '0218/SJ/12/2020', '2020-12-28', 'DEF', '1'),
('2', '2', '3', '0218/SJ/12/2020-01', '2021-01-04', 'DEF', '1'),
('3', '14', '29', '3150047138', '2021-01-04', 'DEF', '1'),
('4', '14', '29', '3150047217', '2021-01-05', 'DEF', '1'),
('5', '15', '28', '042/SJ/XII/2020', '2021-01-05', 'DEF', '1'),
('6', '4', '31', '30/SJ/WMI/XII/2020', '2021-01-05', 'DEF', '1'),
('7', '4', '17', '31/SJ/WMI/XII/2020', '2021-01-05', 'DEF', '1'),
('8', '4', '22', '32/SJ/WMI/XII/2020', '2021-01-05', 'DEF', '1'),
('9', '4', '23', '33/SJ/WMI/XII/2020', '2021-01-05', 'DEF', '1'),
('10', '4', '25', '34/SJ/WMI/XII/2020', '2021-01-05', 'DEF', '1'),
('11', '4', '7', '35/SJ/WMI/XII/2020', '2021-01-05', 'DEF', '1'),
('12', '4', '8', '36/AJ/WMI/XII/2020', '2021-01-05', 'DEF', '1'),
('13', '4', '9', '37/SJ/WMI/XII/2020', '2021-01-05', 'DEF', '1'),
('14', '4', '14', '40/SJ/WMI/XII/2020', '2021-01-05', 'DEF', '1'),
('15', '4', '22', '42/SJ/WMI/XII/2020', '2021-01-05', 'DEF', '1'),
('16', '4', '23', '43/SJ/WMI/XII/2020', '2021-01-05', 'DEF', '1'),
('17', '4', '9', '44/SJ/WMI/XII/2020', '2021-01-06', 'DEF', '1'),
('18', '4', '32', '46/SJ/WMI/XII/2020', '2021-01-06', 'DEF', '1'),
('19', '4', '10', '38/SJ/WMI/XII/2020', '2021-01-06', 'DEF', '1'),
('20', '4', '12', '39/XII/2020', '2021-01-06', 'DEF', '1'),
('21', '4', '17', '41/XII/2020', '2021-01-06', 'DEF', '1'),
('22', '4', '10', '45/XII/2020', '2021-01-06', 'DEF', '1');

### Structure of table `0_grn_items` ###

DROP TABLE IF EXISTS `0_grn_items`;

CREATE TABLE `0_grn_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `grn_batch_id` int(11) DEFAULT NULL,
  `po_detail_item` int(11) NOT NULL DEFAULT '0',
  `item_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` tinytext COLLATE utf8_unicode_ci,
  `qty_recd` double NOT NULL DEFAULT '0',
  `quantity_inv` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `grn_batch_id` (`grn_batch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_grn_items` ###

INSERT INTO `0_grn_items` VALUES
('1', '1', '1', 'CPP', 'ALUMINIUM WIRE SIZE DIA 2.0 mm', '0', '0'),
('2', '2', '4', 'BP-RMP-002', 'ALUMINIUM WIRE SIZE DIA 2.0 mm', '1000', '1000'),
('3', '3', '121', 'RA27', 'ASIBLOCK 0085-1 MTE', '275', '275'),
('4', '4', '121', 'RA27', 'ASIBLOCK 0085-1 MTE', '225', '225'),
('5', '5', '120', 'RA24', 'VISTAMAXX 3588FL', '1000', '1000'),
('6', '6', '124', 'BANTALAN', 'BANTALAN KAYU', '2000', '2000'),
('7', '7', '83', 'PL106', 'PALANG KAYU 106,0 CM', '100', '100'),
('8', '8', '105', 'PK1100X1100', 'PALLET UTUH 1100 MM X 1100 MM', '15', '15'),
('9', '9', '106', 'PK1000X1100', 'PALLET UTUH 1000 MM X 1100 MM', '32', '32'),
('10', '10', '111', 'PL87', 'PALANG KAYU 87.0 CM', '60', '60'),
('11', '10', '112', 'PL90', 'PALANG KAYU 90.0 CM', '60', '60'),
('12', '10', '113', 'PL930', 'PALANG KAYU 93,0 CM', '60', '60'),
('13', '10', '115', 'PL99', 'PALANG KAYU 99,0 CM', '60', '60'),
('14', '10', '117', 'PL117', 'PALANG KAYU 117,0 CM', '60', '60'),
('15', '11', '31', 'PL126', 'PALANG KAYU 126,0 CM', '100', '100'),
('16', '12', '33', 'PL921', 'PALANG KAYU 92,1 CM', '300', '300'),
('17', '12', '35', 'PL87', 'PALANG KAYU 87.0 CM', '100', '100'),
('18', '12', '36', 'PL90', 'PALANG KAYU 90.0 CM', '80', '80'),
('19', '12', '38', 'PL120', 'PALANG KAYU 120 CM', '100', '100'),
('20', '12', '40', 'PL180', 'PALANG KAYU 180,0 CM', '300', '300'),
('21', '13', '41', 'PK1200X1100', 'PALLET UTUH 1200 MM X 1100 MM', '190', '190'),
('22', '13', '42', 'PK1100X550', 'PALLET SETENGAH 1100 MM X 550 MM', '16', '16'),
('23', '13', '43', 'PK1200X980', 'PALLET KHUSUS 1200 MM X 980 MM', '11', '11'),
('24', '14', '75', 'PK1200X720', 'PALLET KHUSUS 1200 MM X 720 MM', '10', '10'),
('25', '15', '105', 'PK1100X1100', 'PALLET UTUH 1100 MM X 1100 MM', '90', '90'),
('26', '16', '106', 'PK1000X1100', 'PALLET UTUH 1000 MM X 1100 MM', '50', '50'),
('27', '17', '41', 'PK1200X1100', 'PALLET UTUH 1200 MM X 1100 MM', '51', '51'),
('28', '17', '42', 'PK1100X550', 'PALLET SETENGAH 1100 MM X 550 MM', '6', '6'),
('29', '18', '125', 'PLY50X50', 'PLYWOOD 50 X 50 CM', '305', '305'),
('30', '18', '126', 'PLY55X55', 'PLYWOOD 55 X 55 CM', '28', '28'),
('31', '18', '127', 'PROFILH', 'PROFIL H ALUMINIUM', '26', '26'),
('32', '19', '45', 'PK730X1010', 'PALLET KHUSUS 730 MM X 1010 MM', '1', '1'),
('33', '19', '48', 'PK1460X1060', 'PALLET KHUSUS 1460 MM X 1060 MM', '2', '2'),
('34', '19', '50', 'PK1460X1100', 'PALLET KHUSUS 1460 MM X 1100 MM', '1', '1'),
('35', '19', '51', 'PK1460X1120', 'PALLET KHUSUS 1460 MM X 1120 MM', '3', '3'),
('36', '19', '54', 'PK1460X1200', 'PALLET KHUSUS 1460 MM X 1200 MM', '4', '4'),
('37', '19', '55', 'PK730X1200', 'PALLET KHUSUS 730 MM X 1200 MM', '1', '1'),
('38', '19', '56', 'PK1460X1210', 'PALLET KHUSUS 1460 MM X 1210 MM', '2', '2'),
('39', '20', '63', 'PL930', 'PALANG KAYU 93,0 CM', '30', '30'),
('40', '20', '64', 'PL945', 'PALANG KAYU 94,5 CM', '12', '12'),
('41', '20', '65', 'PL99', 'PALANG KAYU 99,0 CM', '4', '4'),
('42', '20', '66', 'PL97', 'PALANG KAYU 97,0 CM', '1', '1'),
('43', '20', '68', 'PL1031', 'PALANG KAYU 103,1 CM', '1', '1'),
('44', '20', '69', 'PL1066', 'PALANG KAYU 106,6 CM', '1', '1'),
('45', '20', '70', 'PL1116', 'PALANG KAYU 111,6 CM', '1', '1'),
('46', '21', '82', 'PL111', 'PALANG KAYU 111,0 CM', '340', '340'),
('47', '21', '84', 'PL110', 'PALANG KAYU 110,0 CM', '10', '10'),
('48', '22', '44', 'PK1460X1010', 'PALLET KHUSUS 1460 MM X 1010 MM', '1', '1'),
('49', '22', '46', 'PK1460X1020', 'PALLET KHUSUS 1460 MM X 1020 MM', '5', '5'),
('50', '22', '47', 'PK1460X1040', 'PALLET KHUSUS 1460 MM X 1040 MM', '2', '2'),
('51', '22', '49', 'PK1460X1080', 'PALLET KHUSUS 1460 MM X 1080 MM', '2', '2'),
('52', '22', '52', 'PK1460X1150', 'PALLET KHUSUS 1460 MM X 1150 MM', '2', '2'),
('53', '22', '53', 'PK1460X1170', 'PALLET KHUSUS 1460 MM X 1170 MM', '1', '1'),
('54', '22', '57', 'PK1340X1230', 'PALLET KHUSUS 1340 MM X 1230 MM', '1', '1'),
('55', '22', '58', 'PK730X1250', 'PALLET KHUSUS 730 MM X 1250 MM', '1', '1'),
('56', '22', '59', 'PK1460X1260', 'PALLET KHUSUS 1460 MM X 1260 MM', '1', '1'),
('57', '22', '60', 'PK1460X1270', 'PALLET KHUSUS 1460 MM X 1270 MM', '2', '2');

### Structure of table `0_groups` ###

DROP TABLE IF EXISTS `0_groups`;

CREATE TABLE `0_groups` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `description` (`description`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_groups` ###

INSERT INTO `0_groups` VALUES
('1', 'Kecil', '0'),
('2', 'Sedang', '0'),
('3', 'Besar', '0');

### Structure of table `0_item_codes` ###

DROP TABLE IF EXISTS `0_item_codes`;

CREATE TABLE `0_item_codes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `item_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `stock_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `category_id` smallint(6) unsigned NOT NULL,
  `quantity` double NOT NULL DEFAULT '1',
  `is_foreign` tinyint(1) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_id` (`stock_id`,`item_code`),
  KEY `item_code` (`item_code`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_item_codes` ###

INSERT INTO `0_item_codes` VALUES
('1', 'CPP', 'CPP', 'CPP', '6', '1', '0', '0'),
('2', 'VMCPP', 'VMCPP', 'VMCPP', '7', '1', '0', '0'),
('3', 'RES-001', 'RES-001', 'Bahan baku HF 8.0 CM', '5', '1', '0', '0'),
('4', 'RES-003', 'RES-003', 'Bahan Baku SFC 650 BT', '5', '1', '0', '0'),
('5', 'RES-005', 'RES-005', 'Bahan Baku SFC 750 M', '5', '1', '0', '0'),
('6', 'RES-006', 'RES-006', 'Bahan Baku P 607 F', '5', '1', '0', '0'),
('7', 'RES-007', 'RES-007', 'Bahan Baku FL 7540 L', '5', '1', '0', '0'),
('8', 'RES-011', 'RES-011', 'Bahan Baku HF 7.0 CP', '5', '1', '0', '0'),
('9', 'RES-012', 'RES-012', 'Bahan Baku FL 7632 L', '5', '1', '0', '0'),
('10', 'RES-013', 'RES-013', 'Bahan Baku SFC 750 R', '5', '1', '0', '0'),
('11', 'RES-020', 'RES-020', 'Bahan Baku FL 7642', '5', '1', '0', '0'),
('12', 'RES-026', 'RES-026', 'TF 451', '5', '1', '0', '0'),
('13', 'RES-037', 'RES-037', 'HD601 CF POLYPROPYLENE', '5', '1', '0', '0'),
('14', 'RA01', 'RA01', 'Bahan Baku ASPA 2446', '5', '1', '0', '0'),
('15', 'RA02', 'RA02', 'Bahan Baku SPEER 6', '5', '1', '0', '0'),
('16', 'RA03', 'RA03', 'Bahan Baku ABVT 19 NSC', '5', '1', '0', '0'),
('17', 'RA15', 'RA15', 'EXCEED 3518 CB	', '5', '1', '0', '0'),
('18', 'RA16', 'RA16', 'TAFMER A 1085 S', '5', '1', '0', '0'),
('19', 'RA21', 'RA21', 'TAFMER A 4085 S', '5', '1', '0', '0'),
('20', 'RA22', 'RA22', 'POLYWHITE P 8377 SCF AP', '5', '1', '0', '0'),
('21', 'BP-RMP-001', 'BP-RMP-001', 'ALUMINIUM WIRE SIZE DIA 1.8 mm', '9', '1', '0', '0'),
('22', 'BP-RMP-002', 'BP-RMP-002', 'ALUMINIUM WIRE SIZE DIA 2.0 mm', '9', '1', '0', '0'),
('23', 'BP0002', 'BP0002', 'EVAPORATOR BOAT SIZE 130 X 38 X 9 MM', '9', '1', '0', '0'),
('24', 'JR-CPP', 'JR-CPP', 'JUMBO ROLL PP', '10', '1', '0', '0'),
('25', 'JR-VMCPP', 'JR-VMCPP', 'JUMBO ROLL VMCPP', '11', '1', '0', '0'),
('26', 'PC31001', 'PC31001', 'PAPER CORE 3 in X 8 MM X 1001 MM', '8', '1', '0', '0'),
('27', 'PC31006', 'PC31006', 'PAPER CORE 3 in X 8 MM X 1006 MM', '8', '1', '0', '0'),
('28', 'PC31011', 'PC31011', 'PAPER CORE 3 in X 8 MM X 1011 MM', '8', '1', '0', '0'),
('29', 'PC31015', 'PC31015', 'PAPER CORE 3 in X 8 MM X 1015 MM', '8', '1', '0', '0'),
('30', 'PC31016', 'PC31016', 'PAPER CORE 3 in X 8 MM X 1016 MM', '8', '1', '0', '0'),
('31', 'PC31018', 'PC31018', 'PAPER CORE 3 in X 8 MM X 1018 MM', '8', '1', '0', '0'),
('32', 'PC31021', 'PC31021', 'PAPER CORE 3 in X 8 MM X 1021 MM', '8', '1', '0', '0'),
('33', 'PC31026', 'PC31026', 'PAPER CORE 3 in X 8 MM X 1026 MM', '8', '1', '0', '0'),
('34', 'PC31036', 'PC31036', 'PAPER CORE 3 in X 8 MM X 1036 MM', '8', '1', '0', '0'),
('35', 'PL1340X1210', 'PL1340X1210', 'PALET KAYU 1340 MM X 1210 MM', '8', '1', '0', '0'),
('36', 'PL1340X970', 'PL1340X970', 'PALET KAYU 1340 MM X 970 MM', '8', '1', '0', '0'),
('37', 'PL1340X1020', 'PL1340X1020', 'PALET KAYU 1340 MM X 1020 MM', '8', '1', '0', '0'),
('38', 'PL1460X1120', 'PL1460X1120', 'PALET KAYU 1460 MM X 1120 MM', '8', '1', '0', '0'),
('39', 'PL1460X1130', 'PL1460X1130', 'PALET KAYU 1460 MM X 1130 MM', '8', '1', '0', '0'),
('40', 'PL1460X1150', 'PL1460X1150', 'PALET KAYU 1460 MM X 1150 MM', '8', '1', '0', '0'),
('41', 'PL1460X1210', 'PL1460X1210', 'PALET KAYU 1460 MM X 1210 MM', '8', '1', '0', '0'),
('42', 'PL1460X1260', 'PL1460X1260', 'PALET KAYU 1460 MM X 1260 MM', '8', '1', '0', '0'),
('43', 'PL1460X1020', 'PL1460X1020', 'PALET KAYU 1460 MM X 1020 MM', '8', '1', '0', '0'),
('44', 'PL1460X1030', 'PL1460X1030', 'PALET KAYU 1460 MM X 1030 MM', '8', '1', '0', '0'),
('45', 'PL1460X1090', 'PL1460X1090', 'PALET KAYU 1460 MM X 1090 MM', '8', '1', '0', '0'),
('46', 'PL730X1120', 'PL730X1120', 'PALET KAYU 730 MM X 1120 MM', '8', '1', '0', '0'),
('47', 'PL730X1020', 'PL730X1020', 'PALET KAYU 730 MM X 1020 MM', '8', '1', '0', '0'),
('48', 'PL730X1030', 'PL730X1030', 'PALET KAYU 730 MM X 1030 MM', '8', '1', '0', '0'),
('49', 'PL730X1090', 'PL730X1090', 'PALET KAYU 730 MM X 1090 MM', '8', '1', '0', '0'),
('51', 'PK930', 'PK930', 'PALANG KAYU 930 MM', '8', '1', '0', '0'),
('52', 'PL1005', 'PL1005', 'PALANG KAYU 100,5 CM', '8', '1', '0', '0'),
('54', 'PL115', 'PL115', 'PALANG KAYU 115,0 CM', '8', '1', '0', '0'),
('55', 'PL106', 'PL106', 'PALANG KAYU 106,0 CM', '8', '1', '0', '0'),
('56', 'PL111', 'PL111', 'PALANG KAYU 111,0 CM', '8', '1', '0', '0'),
('57', 'PL1020', 'PL1020', 'PALANG KAYU 102,0 CM', '8', '1', '0', '0'),
('58', 'PL1050', 'PL1050', 'PALANG KAYU 105,0 CM', '8', '1', '0', '0'),
('59', 'PL1080', 'PL1080', 'PALANG KAYU 108,0 CM', '8', '1', '0', '0'),
('60', 'PL123', 'PL123', 'PALANG KAYU 123,0 CM', '8', '1', '0', '0'),
('61', 'PL126', 'PL126', 'PALANG KAYU 126,0 CM', '8', '1', '0', '0'),
('62', 'PL1290', 'PL1290', 'PALANG KAYU 129,0 CM', '8', '1', '0', '0'),
('63', 'PL921', 'PL921', 'PALANG KAYU 92,1 CM', '8', '1', '0', '0'),
('64', 'PL87', 'PL87', 'PALANG KAYU 87.0 CM', '8', '1', '0', '0'),
('65', 'PL90', 'PL90', 'PALANG KAYU 90.0 CM', '8', '1', '0', '0'),
('66', 'PL120', 'PL120', 'PALANG KAYU 120 CM', '8', '1', '0', '0'),
('67', 'PL117', 'PL117', 'PALANG KAYU 117,0 CM', '8', '1', '0', '0'),
('68', 'PL180', 'PL180', 'PALANG KAYU 180,0 CM', '8', '1', '0', '0'),
('70', 'PK1200X1100', 'PK1200X1100', 'PALLET UTUH 1200 MM X 1100 MM', '8', '1', '0', '0'),
('71', 'PK1100X550', 'PK1100X550', 'PALLET SETENGAH 1100 MM X 550 MM', '8', '1', '0', '0'),
('72', 'PK1200X980', 'PK1200X980', 'PALLET KHUSUS 1200 MM X 980 MM', '8', '1', '0', '0'),
('73', 'PK1460X1010', 'PK1460X1010', 'PALLET KHUSUS 1460 MM X 1010 MM', '8', '1', '0', '0'),
('74', 'PK730X1010', 'PK730X1010', 'PALLET KHUSUS 730 MM X 1010 MM', '8', '1', '0', '0'),
('75', 'PK1460X1020', 'PK1460X1020', 'PALLET KHUSUS 1460 MM X 1020 MM', '8', '1', '0', '0'),
('76', 'PK1460X1040', 'PK1460X1040', 'PALLET KHUSUS 1460 MM X 1040 MM', '8', '1', '0', '0'),
('77', 'PK1460X1060', 'PK1460X1060', 'PALLET KHUSUS 1460 MM X 1060 MM', '8', '1', '0', '0'),
('78', 'PK1460X1080', 'PK1460X1080', 'PALLET KHUSUS 1460 MM X 1080 MM', '8', '1', '0', '0'),
('79', 'PK1460X1100', 'PK1460X1100', 'PALLET KHUSUS 1460 MM X 1100 MM', '8', '1', '0', '0'),
('80', 'PK1460X1120', 'PK1460X1120', 'PALLET KHUSUS 1460 MM X 1120 MM', '8', '1', '0', '0'),
('81', 'PK1460X1150', 'PK1460X1150', 'PALLET KHUSUS 1460 MM X 1150 MM', '8', '1', '0', '0'),
('82', 'PK1460X1170', 'PK1460X1170', 'PALLET KHUSUS 1460 MM X 1170 MM', '8', '1', '0', '0'),
('83', 'PK1460X1200', 'PK1460X1200', 'PALLET KHUSUS 1460 MM X 1200 MM', '8', '1', '0', '0'),
('84', 'PK730X1200', 'PK730X1200', 'PALLET KHUSUS 730 MM X 1200 MM', '8', '1', '0', '0'),
('85', 'PK1460X1210', 'PK1460X1210', 'PALLET KHUSUS 1460 MM X 1210 MM', '8', '1', '0', '0'),
('86', 'PK1340X1230', 'PK1340X1230', 'PALLET KHUSUS 1340 MM X 1230 MM', '8', '1', '0', '0'),
('87', 'PK730X1250', 'PK730X1250', 'PALLET KHUSUS 730 MM X 1250 MM', '8', '1', '0', '0'),
('88', 'PK1460X1260', 'PK1460X1260', 'PALLET KHUSUS 1460 MM X 1260 MM', '8', '1', '0', '0'),
('89', 'PK1460X1270', 'PK1460X1270', 'PALLET KHUSUS 1460 MM X 1270 MM', '8', '1', '0', '0'),
('90', 'RA28', 'RA28', 'ANTIBLOCK F15', '5', '1', '0', '0'),
('91', 'RA29', 'RA29', 'ANTIBLOCK AB5', '5', '1', '0', '0'),
('92', 'RA30', 'RA30', 'ANTIOXIDANE AO 25', '5', '1', '0', '0'),
('93', 'PL930', 'PL930', 'PALANG KAYU 93,0 CM', '8', '1', '0', '0'),
('94', 'PL945', 'PL945', 'PALANG KAYU 94,5 CM', '8', '1', '0', '0'),
('95', 'PL99', 'PL99', 'PALANG KAYU 99,0 CM', '8', '1', '0', '0'),
('96', 'PL97', 'PL97', 'PALANG KAYU 97,0 CM', '8', '1', '0', '0'),
('97', 'PL1026', 'PL1026', 'PALANG KAYU 102,6 CM', '8', '1', '0', '0'),
('98', 'PL1031', 'PL1031', 'PALANG KAYU 103,1 CM', '8', '1', '0', '0'),
('99', 'PL1066', 'PL1066', 'PALANG KAYU 106,6 CM', '8', '1', '0', '0'),
('100', 'PL1116', 'PL1116', 'PALANG KAYU 111,6 CM', '8', '1', '0', '0'),
('101', 'PK1200X720', 'PK1200X720', 'PALLET KHUSUS 1200 MM X 720 MM', '8', '1', '0', '0'),
('102', 'MTC-PWC-001', 'MTC-PWC-001', 'RECOVER CORONA ROLL SIZE: L.3800MM X ID350MM X 356MM', '2', '1', '0', '0'),
('103', 'MTC-PWC-002', 'MTC-PWC-002', 'RECOVER NIP ROLL SIZE: L 3800MM X ID170MM X OD210 MM', '2', '1', '0', '0'),
('104', 'PK900X1100', 'PK900X1100', 'PALLET UTUH 900 MM X 1100 MM', '8', '1', '0', '0'),
('105', 'PK1000X1100', 'PK1000X1100', 'PALLET UTUH 1000 MM X 1100 MM', '8', '1', '0', '0'),
('106', 'PK700X550', 'PK700X550', 'PALLET SETENGAH 700 MM X 550 MM', '8', '1', '0', '0'),
('107', 'STOPER', 'STOPER', 'STOPER', '8', '1', '0', '0'),
('108', 'PL110', 'PL110', 'PALANG KAYU 110,0 CM', '8', '1', '0', '0'),
('109', 'PK1000X1060', 'PK1000X1060', 'PALLET KHUSUS 1000 MM X 1060 MM', '8', '1', '0', '0'),
('110', 'PK980X1060', 'PK980X1060', 'PALLET KHUSUS 980 MM X 1060 MM', '8', '1', '0', '0'),
('111', 'PK1100X1100', 'PK1100X1100', 'PALLET UTUH 1100 MM X 1100 MM', '8', '1', '0', '0'),
('113', 'PL965', 'PL965', 'PALANG KAYU 96,5 CM', '8', '1', '0', '0'),
('114', 'PL1025', 'PL1025', 'PALANG KAYU 102,5 CM', '8', '1', '0', '0'),
('115', 'PL1030', 'PL1030', 'PALANG KAYU 103,0 CM', '8', '1', '0', '0'),
('116', 'PL1115', 'PL1115', 'PALANG KAYU 111,5 CM', '8', '1', '0', '0'),
('117', 'PL1175', 'PL1175', 'PALANG KAYU 117,5 CM', '8', '1', '0', '0'),
('118', 'RA14', 'RA14', 'SKIBLOCK 5A', '5', '1', '0', '0'),
('119', 'PCH-CPD-005', 'PCH-CPD-005', 'LABEL TANDA PANAH MERAH', '8', '1', '0', '0'),
('120', 'PCH-SPD-005', 'PCH-SPD-005', 'LABEL STICKER TANDA PANAH MERAH', '8', '1', '0', '0'),
('121', 'MTC-ACA-001', 'MTC-ACA-001', 'SCOTCH BRITE 3M 7447 MAROON', '2', '1', '0', '0'),
('122', 'BANTALAN', 'BANTALAN', 'BANTALAN KAYU', '8', '1', '0', '0'),
('123', 'PK96', 'PK96', 'PALANG KAYU 96,0 CM', '8', '1', '0', '0'),
('124', 'PK114', 'PK114', 'PALANG KAYU 114,0 CM', '8', '1', '0', '0'),
('125', 'OFC-ATK-001', 'OFC-ATK-001', 'CONTINUOUS FORM 3 PLY UK A4', '2', '1', '0', '0'),
('126', 'RA24', 'RA24', 'VISTAMAXX 3588FL', '5', '1', '0', '0'),
('127', 'RA27', 'RA27', 'ASIBLOCK 0085-1 MTE', '5', '1', '0', '0'),
('128', 'SB-09', 'SB-09', 'BLOCK TAPE BIRU 1&quot;', '8', '1', '0', '0'),
('129', 'SB-07', 'SB-07', 'BLOCK TAPE MERAH 2&quot;', '8', '1', '0', '0'),
('130', 'PLY50X50', 'PLY50X50', 'PLYWOOD 50 X 50 CM', '8', '1', '0', '0'),
('131', 'PLY55X55', 'PLY55X55', 'PLYWOOD 55 X 55 CM', '8', '1', '0', '0'),
('132', 'PROFILH', 'PROFILH', 'PROFIL H ALUMINIUM', '8', '1', '0', '0'),
('133', 'MTC-LMP-001', 'MTC-LMP-001', 'TIMBANGAN ELEKTRONIK ACIS 3000 KG ', '2', '1', '0', '0'),
('134', 'FIX-01/2021', 'FIX-01/2021', 'DINDAN COOLING PANEL/ PENDINGIN SERVO 70ACU.005', '14', '1', '0', '0'),
('135', 'MTC-YMS-001', 'MTC-YMS-001', 'DINDAN COOLING PANEL/PENDINGIN SERVO 70ACU.005', '2', '1', '0', '0'),
('136', 'PCH-WFP-001', 'PCH-WFP-001', 'STRECTH FILM 50 CM X 300 M X 12 MIC', '8', '1', '0', '0'),
('137', 'MTC-MTS-001', 'MTC-MTS-001', 'REPAIR CONTTROLLER TEMPERATURE TYPE: CAL 9400', '2', '1', '0', '0'),
('138', 'MTC-MTS-002', 'MTC-MTS-002', 'REPAIR TRANSMISSION DENSITOMETER MODEL: TBX-MC V2', '2', '1', '0', '0'),
('139', 'MTC-GTI-001', 'MTC-GTI-001', 'REPAIR AS CHUCK UNWINDER SLITTING SCONDARY1', '2', '1', '0', '0'),
('140', 'PCH-SPN-001', 'PCH-SPN-001', 'PET 12 MIC X 820 MM X 2.500 M', '2', '1', '0', '0');

### Structure of table `0_item_tax_type_exemptions` ###

DROP TABLE IF EXISTS `0_item_tax_type_exemptions`;

CREATE TABLE `0_item_tax_type_exemptions` (
  `item_tax_type_id` int(11) NOT NULL DEFAULT '0',
  `tax_type_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_tax_type_id`,`tax_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_item_tax_type_exemptions` ###

INSERT INTO `0_item_tax_type_exemptions` VALUES
('3', '2');

### Structure of table `0_item_tax_types` ###

DROP TABLE IF EXISTS `0_item_tax_types`;

CREATE TABLE `0_item_tax_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `exempt` tinyint(1) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_item_tax_types` ###

INSERT INTO `0_item_tax_types` VALUES
('1', 'Penjualan Regular', '0', '0'),
('2', 'Penjualan non PPN', '1', '0'),
('3', 'NON PPN PPH 23', '0', '0'),
('4', 'PPN+PPH23', '0', '0');

### Structure of table `0_item_units` ###

DROP TABLE IF EXISTS `0_item_units`;

CREATE TABLE `0_item_units` (
  `abbr` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `decimals` tinyint(2) NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`abbr`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_item_units` ###

INSERT INTO `0_item_units` VALUES
('Batang', 'Batang', '-1', '0'),
('Box', 'Box', '-1', '0'),
('Buku', 'Buku', '-1', '0'),
('each', 'Each', '-1', '0'),
('Kg.', 'Kilogram', '2', '0'),
('Pc.', 'Pieces', '-1', '0'),
('Set', 'Set', '-1', '0');

### Structure of table `0_journal` ###

DROP TABLE IF EXISTS `0_journal`;

CREATE TABLE `0_journal` (
  `type` smallint(6) NOT NULL DEFAULT '0',
  `trans_no` int(11) NOT NULL DEFAULT '0',
  `tran_date` date DEFAULT '0000-00-00',
  `reference` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `source_ref` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `event_date` date DEFAULT '0000-00-00',
  `doc_date` date NOT NULL DEFAULT '0000-00-00',
  `currency` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `amount` double NOT NULL DEFAULT '0',
  `rate` double NOT NULL DEFAULT '1',
  PRIMARY KEY (`type`,`trans_no`),
  KEY `tran_date` (`tran_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_journal` ###


### Structure of table `0_loc_stock` ###

DROP TABLE IF EXISTS `0_loc_stock`;

CREATE TABLE `0_loc_stock` (
  `loc_code` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `stock_id` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `reorder_level` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`loc_code`,`stock_id`),
  KEY `stock_id` (`stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_loc_stock` ###

INSERT INTO `0_loc_stock` VALUES
('DEF', 'BANTALAN', '0'),
('DEF', 'BP-RMP-001', '0'),
('DEF', 'BP-RMP-002', '0'),
('DEF', 'BP0002', '0'),
('DEF', 'CPP', '0'),
('DEF', 'FIX-01/2021', '0'),
('DEF', 'JR-CPP', '0'),
('DEF', 'JR-VMCPP', '0'),
('DEF', 'MTC-ACA-001', '0'),
('DEF', 'MTC-GTI-001', '0'),
('DEF', 'MTC-LMP-001', '0'),
('DEF', 'MTC-MTS-001', '0'),
('DEF', 'MTC-MTS-002', '0'),
('DEF', 'MTC-PWC-001', '0'),
('DEF', 'MTC-PWC-002', '0'),
('DEF', 'MTC-YMS-001', '0'),
('DEF', 'OFC-ATK-001', '0'),
('DEF', 'PC31001', '0'),
('DEF', 'PC31006', '0'),
('DEF', 'PC31011', '0'),
('DEF', 'PC31015', '0'),
('DEF', 'PC31016', '0'),
('DEF', 'PC31018', '0'),
('DEF', 'PC31021', '0'),
('DEF', 'PC31026', '0'),
('DEF', 'PC31036', '0'),
('DEF', 'PCH-CPD-005', '0'),
('DEF', 'PCH-SPD-005', '0'),
('DEF', 'PCH-SPN-001', '0'),
('DEF', 'PCH-WFP-001', '0'),
('DEF', 'PK1000X1060', '0'),
('DEF', 'PK1000X1100', '0'),
('DEF', 'PK1100X1100', '0'),
('DEF', 'PK1100X550', '0'),
('DEF', 'PK114', '0'),
('DEF', 'PK1200X1100', '0'),
('DEF', 'PK1200X720', '0'),
('DEF', 'PK1200X980', '0'),
('DEF', 'PK1340X1230', '0'),
('DEF', 'PK1460X1010', '0'),
('DEF', 'PK1460X1020', '0'),
('DEF', 'PK1460X1040', '0'),
('DEF', 'PK1460X1060', '0'),
('DEF', 'PK1460X1080', '0'),
('DEF', 'PK1460X1100', '0'),
('DEF', 'PK1460X1120', '0'),
('DEF', 'PK1460X1150', '0'),
('DEF', 'PK1460X1170', '0'),
('DEF', 'PK1460X1200', '0'),
('DEF', 'PK1460X1210', '0'),
('DEF', 'PK1460X1260', '0'),
('DEF', 'PK1460X1270', '0'),
('DEF', 'PK700X550', '0'),
('DEF', 'PK730X1010', '0'),
('DEF', 'PK730X1200', '0'),
('DEF', 'PK730X1250', '0'),
('DEF', 'PK900X1100', '0'),
('DEF', 'PK930', '0'),
('DEF', 'PK96', '0'),
('DEF', 'PK980X1060', '0'),
('DEF', 'PL1005', '0'),
('DEF', 'PL1020', '0'),
('DEF', 'PL1025', '0'),
('DEF', 'PL1026', '0'),
('DEF', 'PL1030', '0'),
('DEF', 'PL1031', '0'),
('DEF', 'PL1050', '0'),
('DEF', 'PL106', '0'),
('DEF', 'PL1066', '0'),
('DEF', 'PL1080', '0'),
('DEF', 'PL110', '0'),
('DEF', 'PL111', '0'),
('DEF', 'PL1115', '0'),
('DEF', 'PL1116', '0'),
('DEF', 'PL115', '0'),
('DEF', 'PL117', '0'),
('DEF', 'PL1175', '0'),
('DEF', 'PL120', '0'),
('DEF', 'PL123', '0'),
('DEF', 'PL126', '0'),
('DEF', 'PL1290', '0'),
('DEF', 'PL1340X1020', '0'),
('DEF', 'PL1340X1210', '0'),
('DEF', 'PL1340X970', '0'),
('DEF', 'PL1460X1020', '0'),
('DEF', 'PL1460X1030', '0'),
('DEF', 'PL1460X1090', '0'),
('DEF', 'PL1460X1120', '0'),
('DEF', 'PL1460X1130', '0'),
('DEF', 'PL1460X1150', '0'),
('DEF', 'PL1460X1210', '0'),
('DEF', 'PL1460X1260', '0'),
('DEF', 'PL180', '0'),
('DEF', 'PL730X1020', '0'),
('DEF', 'PL730X1030', '0'),
('DEF', 'PL730X1090', '0'),
('DEF', 'PL730X1120', '0'),
('DEF', 'PL87', '0'),
('DEF', 'PL90', '0'),
('DEF', 'PL921', '0'),
('DEF', 'PL930', '0'),
('DEF', 'PL945', '0'),
('DEF', 'PL965', '0'),
('DEF', 'PL97', '0'),
('DEF', 'PL99', '0'),
('DEF', 'PLY50X50', '0'),
('DEF', 'PLY55X55', '0'),
('DEF', 'PROFILH', '0'),
('DEF', 'RA01', '0'),
('DEF', 'RA02', '0'),
('DEF', 'RA03', '0'),
('DEF', 'RA14', '0'),
('DEF', 'RA15', '0'),
('DEF', 'RA16', '0'),
('DEF', 'RA21', '0'),
('DEF', 'RA22', '0'),
('DEF', 'RA24', '0'),
('DEF', 'RA27', '0'),
('DEF', 'RA28', '0'),
('DEF', 'RA29', '0'),
('DEF', 'RA30', '0'),
('DEF', 'RES-001', '0'),
('DEF', 'RES-003', '0'),
('DEF', 'RES-005', '0'),
('DEF', 'RES-006', '0'),
('DEF', 'RES-007', '0'),
('DEF', 'RES-011', '0'),
('DEF', 'RES-012', '0'),
('DEF', 'RES-013', '0'),
('DEF', 'RES-020', '0'),
('DEF', 'RES-026', '0'),
('DEF', 'RES-037', '0'),
('DEF', 'SB-07', '0'),
('DEF', 'SB-09', '0'),
('DEF', 'STOPER', '0'),
('DEF', 'VMCPP', '0'),
('PROD', 'BANTALAN', '0'),
('PROD', 'BP-RMP-001', '0'),
('PROD', 'BP-RMP-002', '0'),
('PROD', 'BP0002', '0'),
('PROD', 'CPP', '0'),
('PROD', 'FIX-01/2021', '0'),
('PROD', 'JR-CPP', '0'),
('PROD', 'JR-VMCPP', '0'),
('PROD', 'MTC-ACA-001', '0'),
('PROD', 'MTC-GTI-001', '0'),
('PROD', 'MTC-LMP-001', '0'),
('PROD', 'MTC-MTS-001', '0'),
('PROD', 'MTC-MTS-002', '0'),
('PROD', 'MTC-PWC-001', '0'),
('PROD', 'MTC-PWC-002', '0'),
('PROD', 'MTC-YMS-001', '0'),
('PROD', 'OFC-ATK-001', '0'),
('PROD', 'PC31001', '0'),
('PROD', 'PC31006', '0'),
('PROD', 'PC31011', '0'),
('PROD', 'PC31015', '0'),
('PROD', 'PC31016', '0'),
('PROD', 'PC31018', '0'),
('PROD', 'PC31021', '0'),
('PROD', 'PC31026', '0'),
('PROD', 'PC31036', '0'),
('PROD', 'PCH-CPD-005', '0'),
('PROD', 'PCH-SPD-005', '0'),
('PROD', 'PCH-SPN-001', '0'),
('PROD', 'PCH-WFP-001', '0'),
('PROD', 'PK1000X1060', '0'),
('PROD', 'PK1000X1100', '0'),
('PROD', 'PK1100X1100', '0'),
('PROD', 'PK1100X550', '0'),
('PROD', 'PK114', '0'),
('PROD', 'PK1200X1100', '0'),
('PROD', 'PK1200X720', '0'),
('PROD', 'PK1200X980', '0'),
('PROD', 'PK1340X1230', '0'),
('PROD', 'PK1460X1010', '0'),
('PROD', 'PK1460X1020', '0'),
('PROD', 'PK1460X1040', '0'),
('PROD', 'PK1460X1060', '0'),
('PROD', 'PK1460X1080', '0'),
('PROD', 'PK1460X1100', '0'),
('PROD', 'PK1460X1120', '0'),
('PROD', 'PK1460X1150', '0'),
('PROD', 'PK1460X1170', '0'),
('PROD', 'PK1460X1200', '0'),
('PROD', 'PK1460X1210', '0'),
('PROD', 'PK1460X1260', '0'),
('PROD', 'PK1460X1270', '0'),
('PROD', 'PK700X550', '0'),
('PROD', 'PK730X1010', '0'),
('PROD', 'PK730X1200', '0'),
('PROD', 'PK730X1250', '0'),
('PROD', 'PK900X1100', '0'),
('PROD', 'PK930', '0'),
('PROD', 'PK96', '0'),
('PROD', 'PK980X1060', '0'),
('PROD', 'PL1005', '0'),
('PROD', 'PL1020', '0'),
('PROD', 'PL1025', '0'),
('PROD', 'PL1026', '0'),
('PROD', 'PL1030', '0'),
('PROD', 'PL1031', '0'),
('PROD', 'PL1050', '0'),
('PROD', 'PL106', '0'),
('PROD', 'PL1066', '0'),
('PROD', 'PL1080', '0'),
('PROD', 'PL110', '0'),
('PROD', 'PL111', '0'),
('PROD', 'PL1115', '0'),
('PROD', 'PL1116', '0'),
('PROD', 'PL115', '0'),
('PROD', 'PL117', '0'),
('PROD', 'PL1175', '0'),
('PROD', 'PL120', '0'),
('PROD', 'PL123', '0'),
('PROD', 'PL126', '0'),
('PROD', 'PL1290', '0'),
('PROD', 'PL1340X1020', '0'),
('PROD', 'PL1340X1210', '0'),
('PROD', 'PL1340X970', '0'),
('PROD', 'PL1460X1020', '0'),
('PROD', 'PL1460X1030', '0'),
('PROD', 'PL1460X1090', '0'),
('PROD', 'PL1460X1120', '0'),
('PROD', 'PL1460X1130', '0'),
('PROD', 'PL1460X1150', '0'),
('PROD', 'PL1460X1210', '0'),
('PROD', 'PL1460X1260', '0'),
('PROD', 'PL180', '0'),
('PROD', 'PL730X1020', '0'),
('PROD', 'PL730X1030', '0'),
('PROD', 'PL730X1090', '0'),
('PROD', 'PL730X1120', '0'),
('PROD', 'PL87', '0'),
('PROD', 'PL90', '0'),
('PROD', 'PL921', '0'),
('PROD', 'PL930', '0'),
('PROD', 'PL945', '0'),
('PROD', 'PL965', '0'),
('PROD', 'PL97', '0'),
('PROD', 'PL99', '0'),
('PROD', 'PLY50X50', '0'),
('PROD', 'PLY55X55', '0'),
('PROD', 'PROFILH', '0'),
('PROD', 'RA01', '0'),
('PROD', 'RA02', '0'),
('PROD', 'RA03', '0'),
('PROD', 'RA14', '0'),
('PROD', 'RA15', '0'),
('PROD', 'RA16', '0'),
('PROD', 'RA21', '0'),
('PROD', 'RA22', '0'),
('PROD', 'RA24', '0'),
('PROD', 'RA27', '0'),
('PROD', 'RA28', '0'),
('PROD', 'RA29', '0'),
('PROD', 'RA30', '0'),
('PROD', 'RES-001', '0'),
('PROD', 'RES-003', '0'),
('PROD', 'RES-005', '0'),
('PROD', 'RES-006', '0'),
('PROD', 'RES-007', '0'),
('PROD', 'RES-011', '0'),
('PROD', 'RES-012', '0'),
('PROD', 'RES-013', '0'),
('PROD', 'RES-020', '0'),
('PROD', 'RES-026', '0'),
('PROD', 'RES-037', '0'),
('PROD', 'SB-07', '0'),
('PROD', 'SB-09', '0'),
('PROD', 'STOPER', '0'),
('PROD', 'VMCPP', '0');

### Structure of table `0_locations` ###

DROP TABLE IF EXISTS `0_locations`;

CREATE TABLE `0_locations` (
  `loc_code` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `location_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `delivery_address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone2` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fax` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `contact` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fixed_asset` tinyint(1) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`loc_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_locations` ###

INSERT INTO `0_locations` VALUES
('DEF', 'Default', 'N/A', '', '', '', '', '', '0', '0'),
('PROD', 'Produksi', '', '', '', '', '', '', '1', '0');

### Structure of table `0_payment_terms` ###

DROP TABLE IF EXISTS `0_payment_terms`;

CREATE TABLE `0_payment_terms` (
  `terms_indicator` int(11) NOT NULL AUTO_INCREMENT,
  `terms` char(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `days_before_due` smallint(6) NOT NULL DEFAULT '0',
  `day_in_following_month` smallint(6) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`terms_indicator`),
  UNIQUE KEY `terms` (`terms`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_payment_terms` ###

INSERT INTO `0_payment_terms` VALUES
('1', 'Tanggal 15 bulan berikutnya', '0', '17', '0'),
('2', 'Akhir bulan berikutnya', '0', '30', '0'),
('3', 'Pembayaran dalam 10 hari', '10', '0', '0'),
('4', 'Cash Only', '0', '0', '0'),
('5', '60 Hari', '0', '60', '0'),
('6', '45 Hari', '0', '45', '0'),
('7', '30 Hari', '0', '30', '0'),
('8', '14 Hari', '0', '14', '0'),
('9', 'Cash Before Delivery', '-1', '0', '0'),
('10', '07 Hari', '0', '7', '0');

### Structure of table `0_prices` ###

DROP TABLE IF EXISTS `0_prices`;

CREATE TABLE `0_prices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sales_type_id` int(11) NOT NULL DEFAULT '0',
  `curr_abrev` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `price` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `price` (`stock_id`,`sales_type_id`,`curr_abrev`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_prices` ###


### Structure of table `0_print_profiles` ###

DROP TABLE IF EXISTS `0_print_profiles`;

CREATE TABLE `0_print_profiles` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `profile` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `report` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `printer` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `profile` (`profile`,`report`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_print_profiles` ###

INSERT INTO `0_print_profiles` VALUES
('1', 'Out of office', NULL, '0'),
('2', 'Sales Department', NULL, '0'),
('3', 'Central', NULL, '2'),
('4', 'Sales Department', '104', '2'),
('5', 'Sales Department', '105', '2'),
('6', 'Sales Department', '107', '2'),
('7', 'Sales Department', '109', '2'),
('8', 'Sales Department', '110', '2'),
('9', 'Sales Department', '201', '2');

### Structure of table `0_printers` ###

DROP TABLE IF EXISTS `0_printers`;

CREATE TABLE `0_printers` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `queue` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `host` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `port` smallint(11) unsigned NOT NULL,
  `timeout` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_printers` ###


### Structure of table `0_purch_data` ###

DROP TABLE IF EXISTS `0_purch_data`;

CREATE TABLE `0_purch_data` (
  `supplier_id` int(11) NOT NULL DEFAULT '0',
  `stock_id` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `price` double NOT NULL DEFAULT '0',
  `suppliers_uom` char(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `conversion_factor` double NOT NULL DEFAULT '1',
  `supplier_description` char(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`supplier_id`,`stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_purch_data` ###

INSERT INTO `0_purch_data` VALUES
('2', 'BP-RMP-002', '46800', '', '1', 'ALUMINIUM WIRE SIZE DIA 2.0 mm'),
('2', 'CPP', '46800', '', '1', 'ALUMINIUM WIRE SIZE DIA 2.0 mm'),
('4', 'BANTALAN', '100', '', '1', 'BANTALAN KAYU'),
('4', 'PK1000X1100', '45000', '', '1', 'PALLET UTUH 1000 MM X 1100 MM'),
('4', 'PK1100X1100', '45000', '', '1', 'PALLET UTUH 1100 MM X 1100 MM'),
('4', 'PK1100X550', '25000', '', '1', 'PALLET SETENGAH 1100 MM X 550 MM'),
('4', 'PK1200X1100', '45000', '', '1', 'PALLET UTUH 1200 MM X 1100 MM'),
('4', 'PK1200X720', '45000', '', '1', 'PALLET KHUSUS 1200 MM X 720 MM'),
('4', 'PK1200X980', '45000', '', '1', 'PALLET KHUSUS 1200 MM X 980 MM'),
('4', 'PK1340X1230', '100000', '', '1', 'PALLET KHUSUS 1340 MM X 1230 MM'),
('4', 'PK1460X1010', '100000', '', '1', 'PALLET KHUSUS 1460 MM X 1010 MM'),
('4', 'PK1460X1020', '100000', '', '1', 'PALLET KHUSUS 1460 MM X 1020 MM'),
('4', 'PK1460X1040', '100000', '', '1', 'PALLET KHUSUS 1460 MM X 1040 MM'),
('4', 'PK1460X1060', '100000', '', '1', 'PALLET KHUSUS 1460 MM X 1060 MM'),
('4', 'PK1460X1080', '100000', '', '1', 'PALLET KHUSUS 1460 MM X 1080 MM'),
('4', 'PK1460X1100', '100000', '', '1', 'PALLET KHUSUS 1460 MM X 1100 MM'),
('4', 'PK1460X1120', '100000', '', '1', 'PALLET KHUSUS 1460 MM X 1120 MM'),
('4', 'PK1460X1150', '100000', '', '1', 'PALLET KHUSUS 1460 MM X 1150 MM'),
('4', 'PK1460X1170', '100000', '', '1', 'PALLET KHUSUS 1460 MM X 1170 MM'),
('4', 'PK1460X1200', '100000', '', '1', 'PALLET KHUSUS 1460 MM X 1200 MM'),
('4', 'PK1460X1210', '100000', '', '1', 'PALLET KHUSUS 1460 MM X 1210 MM'),
('4', 'PK1460X1260', '100000', '', '1', 'PALLET KHUSUS 1460 MM X 1260 MM'),
('4', 'PK1460X1270', '100000', '', '1', 'PALLET KHUSUS 1460 MM X 1270 MM'),
('4', 'PK730X1010', '45000', '', '1', 'PALLET KHUSUS 730 MM X 1010 MM'),
('4', 'PK730X1200', '45000', '', '1', 'PALLET KHUSUS 730 MM X 1200 MM'),
('4', 'PK730X1250', '45000', '', '1', 'PALLET KHUSUS 730 MM X 1250 MM'),
('4', 'PL1031', '4000', '', '1', 'PALANG KAYU 103,1 CM'),
('4', 'PL106', '4000', '', '1', 'PALANG KAYU 106,0 CM'),
('4', 'PL1066', '4000', '', '1', 'PALANG KAYU 106,6 CM'),
('4', 'PL110', '4000', '', '1', 'PALANG KAYU 110,0 CM'),
('4', 'PL111', '4000', '', '1', 'PALANG KAYU 111,0 CM'),
('4', 'PL1116', '4000', '', '1', 'PALANG KAYU 111,6 CM'),
('4', 'PL117', '4000', '', '1', 'PALANG KAYU 117,0 CM'),
('4', 'PL120', '4000', '', '1', 'PALANG KAYU 120 CM'),
('4', 'PL126', '4000', '', '1', 'PALANG KAYU 126,0 CM'),
('4', 'PL180', '2500', '', '1', 'PALANG KAYU 180,0 CM'),
('4', 'PL87', '4000', '', '1', 'PALANG KAYU 87.0 CM'),
('4', 'PL90', '4000', '', '1', 'PALANG KAYU 90.0 CM'),
('4', 'PL921', '4000', '', '1', 'PALANG KAYU 92,1 CM'),
('4', 'PL930', '4000', '', '1', 'PALANG KAYU 93,0 CM'),
('4', 'PL945', '4000', '', '1', 'PALANG KAYU 94,5 CM'),
('4', 'PL97', '4000', '', '1', 'PALANG KAYU 97,0 CM'),
('4', 'PL99', '4000', '', '1', 'PALANG KAYU 99,0 CM'),
('4', 'PLY50X50', '7000', '', '1', 'PLYWOOD 50 X 50 CM'),
('4', 'PLY55X55', '7000', '', '1', 'PLYWOOD 55 X 55 CM'),
('4', 'PROFILH', '25000', '', '1', 'PROFIL H ALUMINIUM'),
('12', 'OFC-ATK-001', '445000', '', '1', ''),
('14', 'RA27', '41500', '', '1', 'ASIBLOCK 0085-1 MTE'),
('15', 'RA24', '33000', '', '1', 'VISTAMAXX 3588FL');

### Structure of table `0_purch_order_details` ###

DROP TABLE IF EXISTS `0_purch_order_details`;

CREATE TABLE `0_purch_order_details` (
  `po_detail_item` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` int(11) NOT NULL DEFAULT '0',
  `item_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` tinytext COLLATE utf8_unicode_ci,
  `delivery_date` date NOT NULL DEFAULT '0000-00-00',
  `qty_invoiced` double NOT NULL DEFAULT '0',
  `unit_price` double NOT NULL DEFAULT '0',
  `act_price` double NOT NULL DEFAULT '0',
  `std_cost_unit` double NOT NULL DEFAULT '0',
  `quantity_ordered` double NOT NULL DEFAULT '0',
  `quantity_received` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`po_detail_item`),
  KEY `order` (`order_no`,`po_detail_item`),
  KEY `itemcode` (`item_code`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_purch_order_details` ###

INSERT INTO `0_purch_order_details` VALUES
('1', '1', 'CPP', 'ALUMINIUM WIRE SIZE DIA 2.0 mm', '2021-01-14', '0', '46800', '46800', '46800', '0', '0'),
('2', '2', 'RES-001', 'Bahan baku HF 8.0 CM', '2021-11-01', '0', '20281.12', '0', '0', '54000', '0'),
('3', '2', 'RES-011', 'Bahan Baku HF 7.0 CP', '2021-11-01', '0', '20281.12', '0', '0', '90000', '0'),
('4', '3', 'BP-RMP-002', 'ALUMINIUM WIRE SIZE DIA 2.0 mm', '2021-01-14', '1000', '46800', '46800', '46800', '1000', '1000'),
('5', '4', 'PL1340X1210', 'PALET KAYU 1340 MM X 1210 MM', '2021-01-08', '0', '100000', '0', '0', '4', '0'),
('6', '4', 'PL1340X970', 'PALET KAYU 1340 MM X 970 MM', '2021-01-08', '0', '100000', '0', '0', '1', '0'),
('7', '4', 'PL1340X1020', 'PALET KAYU 1340 MM X 1020 MM', '2021-01-08', '0', '100000', '0', '0', '6', '0'),
('8', '4', 'PL1460X1120', 'PALET KAYU 1460 MM X 1120 MM', '2021-01-08', '0', '100000', '0', '0', '8', '0'),
('9', '4', 'PL1460X1130', 'PALET KAYU 1460 MM X 1130 MM', '2021-01-08', '0', '100000', '0', '0', '1', '0'),
('10', '4', 'PL1460X1150', 'PALET KAYU 1460 MM X 1150 MM', '2021-01-08', '0', '100000', '0', '0', '1', '0'),
('11', '4', 'PL1460X1210', 'PALET KAYU 1460 MM X 1210 MM', '2021-01-08', '0', '100000', '0', '0', '8', '0'),
('12', '4', 'PL1460X1260', 'PALET KAYU 1460 MM X 1260 MM', '2021-01-08', '0', '100000', '0', '0', '4', '0'),
('13', '4', 'PL1460X1020', 'PALET KAYU 1460 MM X 1020 MM', '2021-01-08', '0', '100000', '0', '0', '20', '0'),
('14', '4', 'PL1460X1030', 'PALET KAYU 1460 MM X 1030 MM', '2021-01-08', '0', '100000', '0', '0', '10', '0'),
('15', '4', 'PL1460X1090', 'PALET KAYU 1460 MM X 1090 MM', '2021-01-08', '0', '100000', '0', '0', '2', '0'),
('16', '4', 'PL730X1120', 'PALET KAYU 730 MM X 1120 MM', '2021-01-08', '0', '45000', '0', '0', '1', '0'),
('17', '4', 'PL730X1020', 'PALET KAYU 730 MM X 1020 MM', '2021-01-08', '0', '45000', '0', '0', '1', '0'),
('18', '4', 'PL730X1030', 'PALET KAYU 730 MM X 1030 MM', '2021-01-08', '0', '45000', '0', '0', '1', '0'),
('19', '4', 'PL730X1090', 'PALET KAYU 730 MM X 1090 MM', '2021-01-08', '0', '45000', '0', '0', '1', '0'),
('20', '4', 'PK930', 'PALANG KAYU 930 MM', '2021-01-08', '0', '4000', '0', '0', '60', '0'),
('25', '6', 'PL111', 'PALANG KAYU 111,0 CM', '2021-01-14', '0', '4000', '0', '0', '200', '0'),
('26', '7', 'PL1020', 'PALANG KAYU 102,0 CM', '2021-01-14', '0', '4000', '0', '0', '100', '0'),
('27', '7', 'PL1050', 'PALANG KAYU 105,0 CM', '2021-01-14', '0', '4000', '0', '0', '100', '0'),
('28', '7', 'PL1080', 'PALANG KAYU 108,0 CM', '2021-01-14', '0', '4000', '0', '0', '100', '0'),
('29', '7', 'PL111', 'PALANG KAYU 111,0 CM', '2021-01-14', '0', '4000', '0', '0', '100', '0'),
('30', '7', 'PL123', 'PALANG KAYU 123,0 CM', '2021-01-14', '0', '4000', '0', '0', '60', '0'),
('31', '7', 'PL126', 'PALANG KAYU 126,0 CM', '2021-01-14', '100', '4000', '4000', '4000', '100', '100'),
('32', '7', 'PL1290', 'PALANG KAYU 129,0 CM', '2021-01-14', '0', '4000', '0', '0', '100', '0'),
('33', '8', 'PL921', 'PALANG KAYU 92,1 CM', '2021-01-14', '300', '4000', '4000', '4000', '300', '300'),
('34', '8', 'PL111', 'PALANG KAYU 111,0 CM', '2021-01-14', '0', '4000', '0', '0', '300', '0'),
('35', '8', 'PL87', 'PALANG KAYU 87.0 CM', '2021-01-14', '100', '4000', '4000', '4000', '100', '100'),
('36', '8', 'PL90', 'PALANG KAYU 90.0 CM', '2021-01-14', '80', '4000', '4000', '4000', '80', '80'),
('37', '8', 'PL1080', 'PALANG KAYU 108,0 CM', '2021-01-14', '0', '4000', '0', '0', '100', '0'),
('38', '8', 'PL120', 'PALANG KAYU 120 CM', '2021-01-14', '100', '4000', '4000', '4000', '100', '100'),
('39', '8', 'PL117', 'PALANG KAYU 117,0 CM', '2021-01-14', '0', '4000', '0', '0', '100', '0'),
('40', '8', 'PL180', 'PALANG KAYU 180,0 CM', '2021-01-14', '300', '2500', '2500', '2500', '300', '300'),
('41', '9', 'PK1200X1100', 'PALLET UTUH 1200 MM X 1100 MM', '2021-01-14', '241', '45000', '45000', '0', '300', '241'),
('42', '9', 'PK1100X550', 'PALLET SETENGAH 1100 MM X 550 MM', '2021-01-14', '22', '25000', '25000', '0', '100', '22'),
('43', '9', 'PK1200X980', 'PALLET KHUSUS 1200 MM X 980 MM', '2021-01-14', '11', '45000', '45000', '45000', '11', '11'),
('44', '10', 'PK1460X1010', 'PALLET KHUSUS 1460 MM X 1010 MM', '2021-01-14', '1', '100000', '100000', '100000', '1', '1'),
('45', '10', 'PK730X1010', 'PALLET KHUSUS 730 MM X 1010 MM', '2021-01-14', '1', '45000', '45000', '45000', '1', '1'),
('46', '10', 'PK1460X1020', 'PALLET KHUSUS 1460 MM X 1020 MM', '2021-01-14', '5', '100000', '100000', '100000', '5', '5'),
('47', '10', 'PK1460X1040', 'PALLET KHUSUS 1460 MM X 1040 MM', '2021-01-14', '2', '100000', '100000', '100000', '2', '2'),
('48', '10', 'PK1460X1060', 'PALLET KHUSUS 1460 MM X 1060 MM', '2021-01-14', '2', '100000', '100000', '100000', '2', '2'),
('49', '10', 'PK1460X1080', 'PALLET KHUSUS 1460 MM X 1080 MM', '2021-01-14', '2', '100000', '100000', '100000', '2', '2'),
('50', '10', 'PK1460X1100', 'PALLET KHUSUS 1460 MM X 1100 MM', '2021-01-14', '1', '100000', '100000', '100000', '1', '1'),
('51', '10', 'PK1460X1120', 'PALLET KHUSUS 1460 MM X 1120 MM', '2021-01-14', '3', '100000', '100000', '100000', '10', '3'),
('52', '10', 'PK1460X1150', 'PALLET KHUSUS 1460 MM X 1150 MM', '2021-01-14', '2', '100000', '100000', '100000', '2', '2'),
('53', '10', 'PK1460X1170', 'PALLET KHUSUS 1460 MM X 1170 MM', '2021-01-14', '1', '100000', '100000', '100000', '1', '1'),
('54', '10', 'PK1460X1200', 'PALLET KHUSUS 1460 MM X 1200 MM', '2021-01-14', '4', '100000', '100000', '100000', '4', '4'),
('55', '10', 'PK730X1200', 'PALLET KHUSUS 730 MM X 1200 MM', '2021-01-14', '1', '100000', '45000', '100000', '1', '1'),
('56', '10', 'PK1460X1210', 'PALLET KHUSUS 1460 MM X 1210 MM', '2021-01-14', '2', '100000', '100000', '100000', '2', '2'),
('57', '10', 'PK1340X1230', 'PALLET KHUSUS 1340 MM X 1230 MM', '2021-01-14', '1', '100000', '100000', '100000', '1', '1'),
('58', '10', 'PK730X1250', 'PALLET KHUSUS 730 MM X 1250 MM', '2021-01-14', '1', '100000', '45000', '100000', '1', '1'),
('59', '10', 'PK1460X1260', 'PALLET KHUSUS 1460 MM X 1260 MM', '2021-01-14', '1', '100000', '100000', '100000', '1', '1'),
('60', '10', 'PK1460X1270', 'PALLET KHUSUS 1460 MM X 1270 MM', '2021-01-14', '2', '100000', '100000', '100000', '2', '2'),
('61', '11', 'RA02', 'Bahan Baku SPEER 6', '2021-01-06', '0', '50051', '0', '0', '1000', '0'),
('62', '12', 'PL111', 'PALANG KAYU 111,0 CM', '2021-01-14', '0', '4000', '0', '0', '200', '0'),
('63', '12', 'PL930', 'PALANG KAYU 93,0 CM', '2021-01-14', '30', '4000', '4000', '4000', '30', '30'),
('64', '12', 'PL945', 'PALANG KAYU 94,5 CM', '2021-01-14', '12', '4000', '4000', '4000', '12', '12'),
('65', '12', 'PL99', 'PALANG KAYU 99,0 CM', '2021-01-14', '4', '4000', '4000', '4000', '4', '4'),
('66', '12', 'PL97', 'PALANG KAYU 97,0 CM', '2021-01-14', '1', '4000', '4000', '4000', '1', '1'),
('67', '12', 'PL1026', 'PALANG KAYU 102,6 CM', '2021-01-14', '0', '4000', '0', '0', '2', '0'),
('68', '12', 'PL1031', 'PALANG KAYU 103,1 CM', '2021-01-14', '1', '4000', '4000', '4000', '1', '1'),
('69', '12', 'PL1066', 'PALANG KAYU 106,6 CM', '2021-01-14', '1', '4000', '4000', '4000', '1', '1'),
('70', '12', 'PL1116', 'PALANG KAYU 111,6 CM', '2021-01-14', '1', '4000', '4000', '4000', '1', '1'),
('71', '12', 'PL117', 'PALANG KAYU 117,0 CM', '2021-01-14', '0', '4000', '0', '0', '2', '0'),
('72', '13', 'RA28', 'ANTIBLOCK F15', '2021-01-05', '0', '43099', '0', '0', '100', '0'),
('73', '13', 'RA29', 'ANTIBLOCK AB5', '2021-01-05', '0', '43099', '0', '0', '50', '0'),
('74', '13', 'RA30', 'ANTIOXIDANE AO 25', '2021-01-05', '0', '45880', '0', '0', '50', '0'),
('75', '14', 'PK1200X720', 'PALLET KHUSUS 1200 MM X 720 MM', '2021-01-14', '10', '45000', '45000', '45000', '10', '10'),
('78', '16', 'PK900X1100', 'PALLET UTUH 900 MM X 1100 MM', '2021-01-14', '0', '45000', '0', '0', '60', '0'),
('79', '16', 'PK1000X1100', 'PALLET UTUH 1000 MM X 1100 MM', '2021-01-14', '0', '45000', '0', '0', '60', '0'),
('80', '16', 'PK700X550', 'PALLET SETENGAH 700 MM X 550 MM', '2021-01-14', '0', '25000', '0', '0', '30', '0'),
('81', '16', 'STOPER', 'STOPER', '2021-01-14', '0', '100', '0', '0', '10000', '0'),
('82', '17', 'PL111', 'PALANG KAYU 111,0 CM', '2021-01-14', '340', '4000', '4000', '4000', '340', '340'),
('83', '17', 'PL106', 'PALANG KAYU 106,0 CM', '2021-01-14', '100', '4000', '4000', '4000', '100', '100'),
('84', '17', 'PL110', 'PALANG KAYU 110,0 CM', '2021-01-14', '10', '4000', '4000', '4000', '10', '10'),
('85', '18', 'MTC-PWC-001', 'RECOVER CORONA ROLL SIZE: L.3800MM X ID350MM X 356MM', '2021-01-19', '0', '36000000', '0', '0', '1', '0'),
('86', '18', 'MTC-PWC-002', 'RECOVER NIP ROLL SIZE: L 3800MM X ID170MM X OD210 MM', '2021-01-19', '0', '30200000', '0', '0', '1', '0'),
('87', '19', 'PL921', 'PALANG KAYU 92,1 CM', '2021-01-08', '0', '4000', '0', '0', '6', '0'),
('88', '19', 'PL930', 'PALANG KAYU 93,0 CM', '2021-01-08', '0', '4000', '0', '0', '30', '0'),
('89', '19', 'PL945', 'PALANG KAYU 94,5 CM', '2021-01-08', '0', '4000', '0', '0', '12', '0'),
('90', '19', 'PL965', 'PALANG KAYU 96,5 CM', '2021-01-08', '0', '4000', '0', '0', '12', '0'),
('91', '19', 'PL99', 'PALANG KAYU 99,0 CM', '2021-01-08', '0', '4000', '0', '0', '12', '0'),
('92', '19', 'PL1005', 'PALANG KAYU 100,5 CM', '2021-01-08', '0', '4000', '0', '0', '10', '0'),
('93', '19', 'PL1025', 'PALANG KAYU 102,5 CM', '2021-01-08', '0', '4000', '0', '0', '48', '0'),
('94', '19', 'PL1030', 'PALANG KAYU 103,0 CM', '2021-01-08', '0', '4000', '0', '0', '6', '0'),
('95', '19', 'PL1066', 'PALANG KAYU 106,6 CM', '2021-01-08', '0', '4000', '0', '0', '12', '0'),
('96', '19', 'PL111', 'PALANG KAYU 111,0 CM', '2021-01-08', '0', '4000', '0', '0', '300', '0'),
('97', '19', 'PL1115', 'PALANG KAYU 111,5 CM', '2021-01-08', '0', '4000', '0', '0', '30', '0'),
('98', '19', 'PL126', 'PALANG KAYU 126,0 CM', '2021-01-08', '0', '4000', '0', '0', '20', '0'),
('99', '19', 'PL1175', 'PALANG KAYU 117,5 CM', '2021-01-08', '0', '4000', '0', '0', '12', '0'),
('100', '19', 'PK730X1250', 'PALLET KHUSUS 730 MM X 1250 MM', '2021-01-08', '0', '4000', '0', '0', '1', '0'),
('101', '20', 'RA14', 'SKIBLOCK 5A', '2021-01-06', '0', '51082.5', '0', '0', '1000', '0'),
('102', '21', 'PCH-SPD-005', 'LABEL STICKER TANDA PANAH MERAH', '2021-01-08', '0', '13', '0', '0', '25000', '0'),
('103', '22', 'PK1000X1060', 'PALLET KHUSUS 1000 MM X 1060 MM', '2021-01-15', '0', '45000', '0', '0', '9', '0'),
('104', '22', 'PK980X1060', 'PALLET KHUSUS 980 MM X 1060 MM', '2021-01-15', '0', '45000', '0', '0', '2', '0'),
('105', '22', 'PK1100X1100', 'PALLET UTUH 1100 MM X 1100 MM', '2021-01-15', '105', '45000', '45000', '0', '286', '105'),
('106', '23', 'PK1000X1100', 'PALLET UTUH 1000 MM X 1100 MM', '2021-01-15', '82', '45000', '45000', '0', '82', '82'),
('107', '23', 'PL111', 'PALANG KAYU 111,0 CM', '2021-01-15', '0', '4000', '0', '0', '300', '0'),
('108', '23', 'PL106', 'PALANG KAYU 106,0 CM', '2021-01-15', '0', '4000', '0', '0', '300', '0'),
('109', '24', 'MTC-ACA-001', 'SCOTCH BRITE 3M 7447 MAROON', '2021-01-08', '0', '1100000', '0', '0', '6', '0'),
('110', '25', 'BANTALAN', 'BANTALAN KAYU', '2021-01-15', '0', '100', '0', '0', '10000', '0'),
('111', '25', 'PL87', 'PALANG KAYU 87.0 CM', '2021-01-15', '60', '4000', '4000', '4000', '60', '60'),
('112', '25', 'PL90', 'PALANG KAYU 90.0 CM', '2021-01-15', '60', '4000', '4000', '4000', '60', '60'),
('113', '25', 'PL930', 'PALANG KAYU 93,0 CM', '2021-01-15', '60', '4000', '4000', '4000', '60', '60'),
('114', '25', 'PK96', 'PALANG KAYU 96,0 CM', '2021-01-15', '0', '4000', '0', '0', '60', '0'),
('115', '25', 'PL99', 'PALANG KAYU 99,0 CM', '2021-01-15', '60', '4000', '4000', '4000', '60', '60'),
('116', '25', 'PK114', 'PALANG KAYU 114,0 CM', '2021-01-15', '0', '4000', '0', '0', '60', '0'),
('117', '25', 'PL117', 'PALANG KAYU 117,0 CM', '2021-01-15', '60', '4000', '4000', '4000', '60', '60'),
('119', '27', 'OFC-ATK-001', 'CONTINUOUS FORM 3 PLY UK A4', '2021-01-08', '0', '445000', '0', '0', '2', '0'),
('120', '28', 'RA24', 'VISTAMAXX 3588FL', '2021-01-15', '1000', '33000', '33000', '33000', '1000', '1000'),
('121', '29', 'RA27', 'ASIBLOCK 0085-1 MTE', '2020-12-18', '500', '41500', '41500', '0', '500', '500'),
('122', '30', 'SB-07', 'BLOCK TAPE MERAH 2&quot;', '2021-01-08', '0', '7500', '0', '0', '504', '0'),
('123', '30', 'SB-09', 'BLOCK TAPE BIRU 1&quot;', '2021-01-08', '0', '6750', '0', '0', '288', '0'),
('124', '31', 'BANTALAN', 'BANTALAN KAYU', '2021-01-15', '2000', '100', '100', '100', '2000', '2000'),
('125', '32', 'PLY50X50', 'PLYWOOD 50 X 50 CM', '2021-01-06', '305', '7000', '7000', '7000', '305', '305'),
('126', '32', 'PLY55X55', 'PLYWOOD 55 X 55 CM', '2021-01-06', '28', '7000', '7000', '7000', '28', '28'),
('127', '32', 'PROFILH', 'PROFIL H ALUMINIUM', '2021-01-06', '26', '25000', '25000', '25000', '26', '26'),
('128', '33', 'RA27', 'ASIBLOCK 0085-1 MTE', '2021-01-07', '0', '42000', '0', '0', '1000', '0'),
('129', '34', 'MTC-LMP-001', 'TIMBANGAN ELEKTRONIK ACIS 3000 KG ', '2021-01-08', '0', '6400000', '0', '0', '1', '0'),
('130', '35', 'MTC-YMS-001', 'DINDAN COOLING PANEL/PENDINGIN SERVO 70ACU.005', '2021-01-08', '0', '35781300', '0', '0', '2', '0'),
('131', '36', 'MTC-MTS-001', 'REPAIR CONTTROLLER TEMPERATURE TYPE: CAL 9400', '2021-01-11', '0', '2090000', '0', '0', '2', '0'),
('132', '36', 'MTC-MTS-002', 'REPAIR TRANSMISSION DENSITOMETER MODEL: TBX-MC V2', '2021-01-11', '0', '4275000', '0', '0', '1', '0'),
('133', '37', 'PCH-SPN-001', 'PET 12 MIC X 820 MM X 2.500 M', '2021-01-08', '0', '28000', '0', '0', '34.44', '0'),
('134', '38', 'RA28', 'ANTIBLOCK F15', '2021-01-08', '0', '43208', '0', '0', '1000', '0');

### Structure of table `0_purch_orders` ###

DROP TABLE IF EXISTS `0_purch_orders`;

CREATE TABLE `0_purch_orders` (
  `order_no` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL DEFAULT '0',
  `comments` tinytext COLLATE utf8_unicode_ci,
  `ord_date` date NOT NULL DEFAULT '0000-00-00',
  `reference` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `requisition_no` tinytext COLLATE utf8_unicode_ci,
  `into_stock_location` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `delivery_address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `total` double NOT NULL DEFAULT '0',
  `prep_amount` double NOT NULL DEFAULT '0',
  `alloc` double NOT NULL DEFAULT '0',
  `tax_included` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_no`),
  KEY `ord_date` (`ord_date`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_purch_orders` ###

INSERT INTO `0_purch_orders` VALUES
('1', '2', NULL, '2020-12-22', 'PO/XII/20-M128', 'PO/XII/20-M128', 'DEF', 'N/A', '51480000', '0', '0', '0'),
('2', '3', NULL, '2021-01-04', 'PO/I/21-M001', 'PO/I/21-M001', 'DEF', 'JL. KP. JARAKOSTA RT OO3 RW 002\nDESA SUKADANAU\nCIBITUNG (CIKARANG BARAT)\nBEKASI 17520', '3212529408', '0', '0', '0'),
('3', '2', NULL, '2020-12-22', 'PO/XII/20-M128.', 'PO/XII/20-M128.', 'DEF', 'N/A', '51480000', '0', '0', '0'),
('4', '4', NULL, '2020-12-24', 'PO/I/21-S001', 'PO/I/21-S001', 'DEF', 'JL. KP. JARAKOSTA RT OO3 RW 002\nDESA SUKADANAU\nCIBITUNG (CIKARANG BARAT)\nBEKASI 17520', '6920000', '0', '0', '0'),
('6', '4', NULL, '2020-03-12', 'PO/XII/20-S315', 'PO/XII/20-S315', 'DEF', 'N/A', '800000', '0', '0', '0'),
('7', '4', NULL, '2021-01-01', 'PO/XII/12-S322', 'PO/XII/12-S322', 'DEF', 'N/A', '2640000', '0', '0', '0'),
('8', '4', NULL, '2021-01-01', 'PO/XII/12-S323', 'PO/XII/12-S323', 'DEF', 'N/A', '5070000', '0', '0', '0'),
('9', '4', NULL, '2021-01-01', 'PO/XII/20-S326', 'PO/XII/20-S326', 'DEF', 'N/A', '16495000', '0', '0', '0'),
('10', '4', NULL, '2020-12-24', 'PO/XII/20-S327', 'PO/XII/20-S327', 'DEF', 'N/A', '3845000', '0', '0', '0'),
('11', '7', NULL, '2021-01-04', 'PO/I/21-M002', 'PO/I/21-M002', 'DEF', 'JL. KP. JARAKOSTA RT OO3 RW 002\nDESA SUKADANAU\nCIBITUNG (CIKARANG BARAT)\nBEKASI 17520', '55056100', '0', '0', '0'),
('12', '4', NULL, '2020-12-24', 'PO/XII/20-S328', 'PO/XII/20-S328', 'DEF', 'N/A', '1016000', '0', '0', '0'),
('13', '7', NULL, '2021-01-04', 'PO/I/21-M003', 'PO/I/21-M003', 'DEF', 'N/A', '9634735', '0', '0', '0'),
('14', '4', NULL, '2020-12-24', 'PO/XII/20-S329', 'PO/XII/20-S329', 'DEF', 'N/A', '450000', '0', '0', '0'),
('16', '4', NULL, '2020-12-24', 'PO/XII/20-S332', 'PO/XII/20-S332', 'DEF', 'N/A', '7150000', '0', '0', '0'),
('17', '4', NULL, '2020-09-11', 'PO/XI/20-S287', 'PO/XI/20-S287', 'DEF', 'N/A', '1800000', '0', '0', '0'),
('18', '8', NULL, '2021-01-05', 'PO/I/21-S002', 'PO/I/21-S002', 'DEF', 'JL. KP. JARAKOSTA RT OO3 RW 002\nDESA SUKADANAU\nCIBITUNG (CIKARANG BARAT)\nBEKASI 17520', '72820000', '0', '0', '0'),
('19', '4', NULL, '2021-01-05', 'PO/I/21-S003', 'PO/I/21-S003', 'DEF', 'JL. KP. JARAKOSTA RT OO3 RW 002\nDESA SUKADANAU\nCIBITUNG (CIKARANG BARAT)\nBEKASI 17520', '2044000', '0', '0', '0'),
('20', '9', NULL, '2021-01-05', 'PO/I/21-M004', 'PO/I/21-M004', 'DEF', 'N/A', '56190750', '0', '0', '0'),
('21', '10', NULL, '2021-01-05', 'PO/I/21-S004', 'PO/I/21-S004', 'DEF', 'JL. KP. JARAKOSTA RT OO3 RW 002\nDESA SUKADANAU\nCIBITUNG (CIKARANG BARAT)\nBEKASI 17520', '357500', '0', '0', '0'),
('22', '4', NULL, '2020-11-18', 'PO/XI/20-S294', 'PO/XI/20-S294', 'DEF', 'N/A', '13365000', '0', '0', '0'),
('23', '4', NULL, '2020-11-18', 'PO/IX/20-S296', 'PO/IX/20-S296', 'DEF', 'N/A', '6090000', '0', '0', '0'),
('24', '11', NULL, '2021-01-05', 'PO/I/21-S005', 'PO/I/21-S005', 'DEF', 'JL. KP. JARAKOSTA RT OO3 RW 002\nDESA SUKADANAU\nCIBITUNG (CIKARANG BARAT)\nBEKASI 17520', '7260000', '0', '0', '0'),
('25', '4', NULL, '2020-11-30', 'PO/11/20-S313', 'PO/11/20-S313', 'DEF', 'N/A', '2680000', '0', '0', '0'),
('27', '12', NULL, '2021-01-05', 'PO/I/21-S006', 'PO/I/21-S006', 'DEF', 'JL. KP. JARAKOSTA RT OO3 RW 002\nDESA SUKADANAU\nCIBITUNG (CIKARANG BARAT)\nBEKASI 17520', '890000', '0', '0', '0'),
('28', '15', NULL, '2020-12-23', 'PO/XII/20-M127', 'PO/XII/20-M127', 'DEF', 'N/A', '36300000', '0', '0', '0'),
('29', '14', NULL, '2020-12-16', 'PO/XII/20-M125', 'PO/XII/20-M125', 'DEF', 'N/A', '22825000', '0', '0', '0'),
('30', '12', NULL, '2021-01-05', 'PO/I/21-S007', 'PO/I/21-S007', 'DEF', 'JL. KP. JARAKOSTA RT OO3 RW 002\nDESA SUKADANAU\nCIBITUNG (CIKARANG BARAT)\nBEKASI 17520', '5724000', '0', '0', '0'),
('31', '4', NULL, '2020-10-28', 'PO/X/20-S280', 'PO/X/20-S280', 'DEF', 'N/A', '200000', '0', '0', '0'),
('32', '4', NULL, '2021-01-06', 'auto', '46/SJ/WMI/XII/2020', 'DEF', 'N/A', '2981000', '0', '0', '0'),
('33', '14', NULL, '2021-01-06', 'PO/I/21-M005', 'PO/I/21-M005', 'DEF', 'JL. KP. JARAKOSTA RT OO3 RW 002\nDESA SUKADANAU\nCIBITUNG (CIKARANG BARAT)\nBEKASI 17520', '46200000', '0', '0', '0'),
('34', '16', NULL, '2021-01-06', 'PO/I/21-S008', 'PO/I/21-S008', 'DEF', 'JL. KP. JARAKOSTA RT OO3 RW 002\nDESA SUKADANAU\nCIBITUNG (CIKARANG BARAT)\nBEKASI 17520', '7040000', '0', '0', '0'),
('35', '31', NULL, '2021-01-06', 'PO/I/21-S009', 'PO/I/21-S009', 'DEF', 'JL. KP. JARAKOSTA RT OO3 RW 002\nDESA SUKADANAU\nCIBITUNG (CIKARANG BARAT)\nBEKASI 17520', '78718860', '0', '0', '0'),
('36', '34', NULL, '2021-01-06', 'PO/I/21-S010', 'PO/I/21-S010', 'DEF', 'JL. KP. JARAKOSTA RT OO3 RW 002\nDESA SUKADANAU\nCIBITUNG (CIKARANG BARAT)\nBEKASI 17520', '9300500', '0', '0', '0'),
('37', '38', NULL, '2021-01-07', 'PO/I/21-S011', 'PO/I/21-S011', 'DEF', 'JL. KP. JARAKOSTA RT OO3 RW 002\nDESA SUKADANAU\nCIBITUNG (CIKARANG BARAT)\nBEKASI 17520', '1060752', '0', '0', '0'),
('38', '7', NULL, '2021-01-07', 'PO/I/21-M006', 'PO/I/21-M006', 'DEF', 'JL. KP. JARAKOSTA RT 003 RW 002\nDESA SUKADANAU\nCIBITUNG (CIKARANG BARAT)\nBEKASI 17520', '47528800', '0', '0', '0');

### Structure of table `0_quick_entries` ###

DROP TABLE IF EXISTS `0_quick_entries`;

CREATE TABLE `0_quick_entries` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `usage` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `base_amount` double NOT NULL DEFAULT '0',
  `base_desc` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bal_type` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `description` (`description`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_quick_entries` ###

INSERT INTO `0_quick_entries` VALUES
('1', '1', 'Maintenance', NULL, '0', 'Amount', '0'),
('2', '4', 'Telp', NULL, '0', 'Amount', '0'),
('3', '2', 'Penjualan Cash', NULL, '0', 'Amount', '0');

### Structure of table `0_quick_entry_lines` ###

DROP TABLE IF EXISTS `0_quick_entry_lines`;

CREATE TABLE `0_quick_entry_lines` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `qid` smallint(6) unsigned NOT NULL,
  `amount` double DEFAULT '0',
  `memo` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `action` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `dest_id` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dimension_id` smallint(6) unsigned DEFAULT NULL,
  `dimension2_id` smallint(6) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `qid` (`qid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_quick_entry_lines` ###


### Structure of table `0_recurrent_invoices` ###

DROP TABLE IF EXISTS `0_recurrent_invoices`;

CREATE TABLE `0_recurrent_invoices` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `order_no` int(11) unsigned NOT NULL,
  `debtor_no` int(11) unsigned DEFAULT NULL,
  `group_no` smallint(6) unsigned DEFAULT NULL,
  `days` int(11) NOT NULL DEFAULT '0',
  `monthly` int(11) NOT NULL DEFAULT '0',
  `begin` date NOT NULL DEFAULT '0000-00-00',
  `end` date NOT NULL DEFAULT '0000-00-00',
  `last_sent` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `description` (`description`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_recurrent_invoices` ###


### Structure of table `0_reflines` ###

DROP TABLE IF EXISTS `0_reflines`;

CREATE TABLE `0_reflines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_type` int(11) NOT NULL,
  `prefix` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `pattern` varchar(35) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `prefix` (`trans_type`,`prefix`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_reflines` ###

INSERT INTO `0_reflines` VALUES
('1', '0', '', '1', '', '1', '0'),
('2', '1', '', '1', '', '1', '0'),
('3', '2', '', '1', '', '1', '0'),
('4', '4', '', '1', '', '1', '0'),
('5', '10', '', '1', '', '1', '0'),
('6', '11', '', '1', '', '1', '0'),
('7', '12', '', '1', '', '1', '0'),
('8', '13', '', '1', '', '1', '0'),
('9', '16', '', '1', '', '1', '0'),
('10', '17', '', '1', '', '1', '0'),
('11', '18', '', '1', '', '1', '0'),
('12', '20', '', '1', '', '1', '0'),
('13', '21', '', '1', '', '1', '0'),
('14', '22', '', '1', '', '1', '0'),
('15', '25', '', '1', '', '1', '0'),
('16', '26', '', '1', '', '1', '0'),
('17', '28', '', '1', '', '1', '0'),
('18', '29', '', '1', '', '1', '0'),
('19', '30', '', '1', '', '1', '0'),
('20', '32', '', '1', '', '1', '0'),
('21', '35', '', '1', '', '1', '0'),
('22', '40', '', '2', '', '1', '0');

### Structure of table `0_refs` ###

DROP TABLE IF EXISTS `0_refs`;

CREATE TABLE `0_refs` (
  `id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `reference` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`,`type`),
  KEY `Type_and_Reference` (`type`,`reference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_refs` ###

INSERT INTO `0_refs` VALUES
('1', '10', '46596652/I/FA-WMI/2021'),
('2', '10', '46596652/I/FA-WMI/2021'),
('3', '10', '46596654/I/FA-WMI/2021'),
('4', '10', '46596654/I/FA-WMI/2021'),
('5', '10', '46596655/I/FA-WMI/2021'),
('6', '10', '46596656/I/FA-WMI/2021'),
('8', '10', '46596656/I/FA-WMI/2021'),
('7', '10', '46596657/I/FA-WMI/2021'),
('9', '10', '46596657/I/FA-WMI/2021'),
('10', '10', '46596658/I/FA-WMI/2021'),
('11', '10', '46596659/I/FA-WMI/2021'),
('12', '10', '46596659/I/FA-WMI/2021'),
('13', '10', '46596660/I/FA-WMI/2020'),
('14', '10', '46596661/I/FA-WMI/2021'),
('7', '13', 'sj19173'),
('5', '13', 'sj19174'),
('6', '13', 'SJ19175'),
('3', '13', 'sj19176'),
('4', '13', 'SJ19177'),
('9', '13', 'sj19178'),
('8', '13', 'sj19179'),
('2', '13', 'SJ19181'),
('1', '13', 'SJ19182'),
('25', '18', 'PO/11/20-S313'),
('2', '18', 'PO/I/21-M001'),
('11', '18', 'PO/I/21-M002'),
('13', '18', 'PO/I/21-M003'),
('20', '18', 'PO/I/21-M004'),
('33', '18', 'PO/I/21-M005'),
('38', '18', 'PO/I/21-M006'),
('4', '18', 'PO/I/21-S001'),
('15', '18', 'PO/I/21-S002'),
('18', '18', 'PO/I/21-S002'),
('19', '18', 'PO/I/21-S003'),
('21', '18', 'PO/I/21-S004'),
('24', '18', 'PO/I/21-S005'),
('27', '18', 'PO/I/21-S006'),
('30', '18', 'PO/I/21-S007'),
('34', '18', 'PO/I/21-S008'),
('35', '18', 'PO/I/21-S009'),
('36', '18', 'PO/I/21-S010'),
('37', '18', 'PO/I/21-S011'),
('23', '18', 'PO/IX/20-S296'),
('31', '18', 'PO/X/20-S280'),
('17', '18', 'PO/XI/20-S287'),
('22', '18', 'PO/XI/20-S294'),
('7', '18', 'PO/XII/12-S322'),
('8', '18', 'PO/XII/12-S323'),
('29', '18', 'PO/XII/20-M125'),
('26', '18', 'PO/XII/20-M127'),
('28', '18', 'PO/XII/20-M127'),
('1', '18', 'PO/XII/20-M128'),
('3', '18', 'PO/XII/20-M128.'),
('5', '18', 'PO/XII/20-S314'),
('6', '18', 'PO/XII/20-S315'),
('9', '18', 'PO/XII/20-S326'),
('10', '18', 'PO/XII/20-S327'),
('12', '18', 'PO/XII/20-S328'),
('14', '18', 'PO/XII/20-S329'),
('16', '18', 'PO/XII/20-S332'),
('51', '20', '00000609/20'),
('50', '20', '004/FJE-F/X/2020'),
('49', '20', '005/FJE-F/XII/2020	'),
('43', '20', '0075/SGI/12/20'),
('59', '20', '041220/VIP/014'),
('60', '20', '10220/PT.MIT/XII/20/RIERY'),
('40', '20', '10706'),
('27', '20', '116/X/2020'),
('28', '20', '116/X/2020.'),
('69', '20', '118-1839/SJ-APK/XI/20'),
('46', '20', '12/000000151F'),
('29', '20', '140/XII/2020	'),
('30', '20', '141/XII/2020'),
('33', '20', '179/CTL/2020'),
('35', '20', '180/CTL/2020'),
('34', '20', '181/CTL/2020'),
('4', '20', '182/CTL/2020'),
('36', '20', '20P00944'),
('37', '20', '20P00960'),
('38', '20', '20P00974'),
('39', '20', '20P00982'),
('7', '20', '221220/VIP/034'),
('8', '20', '30/XII/2020'),
('9', '20', '31/XII/2020'),
('10', '20', '32/XII/2020'),
('11', '20', '33/XII/2020'),
('12', '20', '34/XII/2020'),
('13', '20', '35/XII/2020'),
('14', '20', '36/XII/2020'),
('15', '20', '37/XII/2020'),
('62', '20', '38/XII/2020'),
('63', '20', '39/XII/2020'),
('23', '20', '3943/INV/PTYI/XI/20'),
('16', '20', '40/XII/2020'),
('24', '20', '4006/INV/PTYI/XII/20'),
('25', '20', '4012/INV/PTYI/XII/20	'),
('64', '20', '41/XII/2020'),
('41', '20', '415/AP/2020'),
('17', '20', '42/XII/2020'),
('18', '20', '43/XII/2020'),
('19', '20', '44/XII/2020'),
('65', '20', '45/XII/2020'),
('20', '20', '46/XII/2020'),
('45', '20', '7150047619	'),
('44', '20', '7150047979'),
('6', '20', '7150048171'),
('54', '20', '92233699/10/CAJ/20'),
('52', '20', '92233700/10/CAJ/20'),
('53', '20', '92233701/10/CAJ/20	'),
('55', '20', '92233715/11/CAJ/20'),
('56', '20', '92233739/11/CAJ/20'),
('57', '20', '92233745/11/CAJ/20'),
('58', '20', '92233746/11/CAJ/20'),
('21', '20', 'FJJPL/2020000667'),
('3', '20', 'I/CDI/I/2021'),
('5', '20', 'I/CDI/I/2021'),
('26', '20', 'INL201100188'),
('2', '20', 'INV-202012/0218.'),
('31', '20', 'INV/202011/0194'),
('32', '20', 'INV/202012/0201	'),
('1', '20', 'INV/202012/0218'),
('42', '20', 'O330-200452204'),
('22', '20', 'SIJKT201200021'),
('66', '20', 'SX2091120	'),
('68', '20', 'SX2091120	.'),
('67', '20', 'SX2101120'),
('47', '20', 'WFP1438/XII/20'),
('48', '20', 'WFP6868/XI/20'),
('61', '20', 'XXIV/CDI/XII/2020'),
('1', '25', '0218/SJ/12/2020'),
('2', '25', '0218/SJ/12/2020-01'),
('5', '25', '042/SJ/XII/2020'),
('6', '25', '30/SJ/WMI/XII/2020'),
('7', '25', '31/SJ/WMI/XII/2020'),
('3', '25', '3150047138'),
('4', '25', '3150047217'),
('8', '25', '32/SJ/WMI/XII/2020'),
('9', '25', '33/SJ/WMI/XII/2020'),
('10', '25', '34/SJ/WMI/XII/2020'),
('11', '25', '35/SJ/WMI/XII/2020'),
('12', '25', '36/AJ/WMI/XII/2020'),
('13', '25', '37/SJ/WMI/XII/2020'),
('19', '25', '38/SJ/WMI/XII/2020'),
('20', '25', '39/XII/2020'),
('14', '25', '40/SJ/WMI/XII/2020'),
('21', '25', '41/XII/2020'),
('15', '25', '42/SJ/WMI/XII/2020'),
('16', '25', '43/SJ/WMI/XII/2020'),
('17', '25', '44/SJ/WMI/XII/2020'),
('22', '25', '45/XII/2020'),
('18', '25', '46/SJ/WMI/XII/2020'),
('6', '30', '0242/SIP/SC/XII/20'),
('17', '30', '0320/AJS/034'),
('18', '30', '0620/AJS/026'),
('12', '30', '0857/MMP/X/2020'),
('11', '30', '0934/MMP/X/2020'),
('28', '30', '1009/PO/TAC/VII/20'),
('19', '30', '1020/AJS/034'),
('2', '30', '1135/MMP/XII/2020'),
('30', '30', '1654/PO/TAC/X/20'),
('29', '30', '1731/PO/TAC/XI/20'),
('26', '30', '1849/PO/TA/XI/20'),
('27', '30', '1907/PO/TAC/XII/20'),
('1', '30', '1993/PO/TAC/XII/20'),
('10', '30', 'CKP-47549982'),
('7', '30', 'CKP-47551933'),
('8', '30', 'CKP-47551934'),
('9', '30', 'CKP-49904143'),
('25', '30', 'GM20100002'),
('15', '30', 'GM20100006'),
('16', '30', 'GM20110044'),
('22', '30', 'OP20020129'),
('21', '30', 'OP20030102'),
('23', '30', 'OP20030103'),
('20', '30', 'OP20110024	'),
('24', '30', 'OP20110033'),
('4', '30', 'P976/20/SPK/PO'),
('32', '30', 'POP2002077'),
('34', '30', 'POP2004013'),
('33', '30', 'POP2006014'),
('31', '30', 'POP2010026'),
('14', '30', 'PORM.2010.0019'),
('3', '30', 'PORM.2011.0118'),
('13', '30', 'PORM.2011.0188'),
('5', '30', 'PORM.2011.0244'),
('1', '40', '1');

### Structure of table `0_sales_order_details` ###

DROP TABLE IF EXISTS `0_sales_order_details`;

CREATE TABLE `0_sales_order_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` int(11) NOT NULL DEFAULT '0',
  `trans_type` smallint(6) NOT NULL DEFAULT '30',
  `stk_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` tinytext COLLATE utf8_unicode_ci,
  `qty_sent` double NOT NULL DEFAULT '0',
  `unit_price` double NOT NULL DEFAULT '0',
  `quantity` double NOT NULL DEFAULT '0',
  `invoiced` double NOT NULL DEFAULT '0',
  `discount_percent` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sorder` (`trans_type`,`order_no`),
  KEY `stkcode` (`stk_code`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_sales_order_details` ###

INSERT INTO `0_sales_order_details` VALUES
('1', '1', '30', 'VMCPP', 'VMCPP 25 mic x 1065 mm x 8000 m', '0', '31400', '6210', '0', '0'),
('2', '1', '30', 'VMCPP', 'VMCPP 25 mic x 855 mm x 8000 m', '0', '31400', '55.12', '0', '0'),
('3', '2', '30', 'CPP', 'CPP 25 mic x 1055 mm x 8000 m', '0', '27500', '2880.15', '0', '0'),
('4', '2', '30', 'CPP', 'CPP 25 mic x 980 mm x 8000 m', '0', '27500', '3388.84', '0', '0'),
('5', '3', '30', 'CPP', 'CPP 20 mic x 110 mm x 8000 m', '0', '22100', '1212.13', '0', '0'),
('6', '4', '30', 'CPP', 'CPP 35 mic x 830 mm x 4000 m', '0', '26300', '100', '0', '0'),
('7', '5', '30', 'VMCPP', 'VMCPP 35 mic x 940 mm x 6000 m', '0', '26500', '1185.65', '0', '0'),
('8', '6', '30', 'CPP', 'CPP 25 mic x 970 mm x 6000 m', '0', '26000', '529.78', '0', '0'),
('9', '6', '30', 'CPP', 'CPP 25 mic x 1030 mm x 6000 m', '0', '26000', '562.48', '0', '0'),
('10', '7', '30', 'CPP', 'CPP 35 mic x 1145 mm x 10000 m', '0', '21760', '500', '0', '0'),
('11', '7', '30', 'CPP', 'CPP 35 mic x 1015 mm x 10000 m', '646.56', '21760', '748.23', '0', '0'),
('12', '7', '30', 'CPP', 'CPP 35 mic x 955 mm x 10000 m', '0', '21760', '2200', '0', '0'),
('13', '7', '30', 'CPP', 'CPP 35 mic x 885 mm x 5000 m', '0', '21760', '500', '0', '0'),
('14', '7', '30', 'CPP', 'CPP 30 mic x 1125 mm x 10000 m', '0', '21760', '600', '0', '0'),
('15', '7', '30', 'CPP', 'CPP 35 mic x 1045 mm x 10000 m', '0', '21760', '500', '0', '0'),
('16', '7', '30', 'CPP', 'CPP 35 mic x 1020 mm x 10000 m', '0', '21760', '1400', '0', '0'),
('17', '7', '30', 'CPP', 'CPP 30 mic x 1165 mm x 10000 m', '0', '21760', '2000', '0', '0'),
('18', '7', '30', 'CPP', 'CPP 35 mic x 935 mm x 10000 m', '0', '21760', '2500', '0', '0'),
('19', '8', '30', 'CPP', 'CPP 35 mic x 1100 mm x 10000 m', '0', '21760', '294.4', '0', '0'),
('20', '8', '30', 'CPP', 'CPP 35 mic x 910 mm x 10000 m', '0', '21760', '1600', '0', '0'),
('21', '8', '30', 'CPP', 'CPP 35 mic x 1010 mm x 10000 m', '0', '21760', '500', '0', '0'),
('22', '8', '30', 'CPP', 'CPP 35 mic x 1065 mm x 10000 m', '0', '21760', '500', '0', '0'),
('23', '8', '30', 'CPP', 'CPP 35 mic x 995 mm x 10000 m', '0', '21760', '600', '0', '0'),
('24', '8', '30', 'CPP', 'CPP 35 mic x 1160 mm x 10000 m', '0', '21760', '1300', '0', '0'),
('25', '8', '30', 'CPP', 'CPP 35 mic x 920 mm x 10000 m', '0', '21760', '5500', '0', '0'),
('26', '8', '30', 'CPP', 'CPP 35 mic x 980 mm x 10000 m', '0', '21760', '2300', '0', '0'),
('27', '8', '30', 'CPP', 'CPP 35 mic x 1055 mm x 10000 m', '0', '21760', '1000', '0', '0'),
('28', '9', '30', 'CPP', 'CPP 35 mic x 910 mm x 10000 m', '1159.34', '21760', '1989.04', '0', '0'),
('29', '10', '30', 'CPP', 'CPP 35 mic x 1045 mm x 10000 m', '665.67', '21760', '665.68', '0', '0'),
('30', '11', '30', 'VMCPP', 'VMCPP 25 mic x 1005 mm x 8000 m', '0', '26500', '731.64', '0', '0'),
('31', '11', '30', 'VMCPP', 'VMCPP 25 mic x 1020 mm x 8000 m', '2227.68', '26500', '9282', '0', '0'),
('32', '11', '30', 'VMCPP', 'VMCPP 30 mic x 1020 mm x 6000 m', '0', '26500', '2673.21', '0', '0'),
('33', '11', '30', 'VMCPP', 'VMCPP 25 mic x 1040 mm x 8000 m', '0', '26500', '1135.68', '0', '0'),
('34', '12', '30', 'VMCPP', 'VMCPP 30 mic x 1020 mm x 6000 m', '835.38', '26800', '1336.6', '0', '0'),
('35', '13', '30', 'VMCPP', 'VMCPP 20 mic x 1000 m x 8000 m', '873.6', '26300', '6700.8', '0', '0'),
('36', '14', '30', 'VMCPP', 'VMCPP 40 mic x 1100 mm x 4000 m', '960.96', '24600', '3533.44', '0', '0'),
('37', '14', '30', 'VMCPP', 'VMCPP 30 mic x 1150 mm x 6000 m', '0', '24600', '479.12', '0', '0'),
('38', '15', '30', 'VMCPP', 'VMCPP 20 mic x 880 mm x 8000 m', '3843.84', '24600', '31775.76', '0', '0'),
('39', '16', '30', 'CPP', 'CPP 25 mic x 920 mm x 8000 m', '4018.56', '22650', '4018.56', '0', '0'),
('40', '17', '30', 'VMCPP', 'VMCPP 25 mic x 1040 mm x 8000 m', '0', '26000', '12871.04', '0', '0'),
('41', '17', '30', 'VMCPP', 'VMCPP 25 mic x 1060 mm x 8000 m', '0', '26000', '6173.44', '0', '0'),
('42', '17', '30', 'VMCPP', 'VMCPP 25 mic x 1100 mm x 8000 m', '0', '26000', '12412.4', '0', '0'),
('43', '17', '30', 'VMCPP', 'VMCPP 25 mic x 1120 mm x 8000 m', '0', '26000', '6522.88', '0', '0'),
('44', '17', '30', 'VMCPP', 'VMCPP 25 mic x 1140 mm x 8000 m', '0', '26000', '7261.8', '0', '0'),
('45', '17', '30', 'VMCPP', 'VMCPP 25 mic x 1160 mm x 8000 m', '0', '26000', '5066.88', '0', '0'),
('46', '17', '30', 'VMCPP', 'VMCPP 25 mic x 1220 mm x 8000 m', '0', '26000', '9325.68', '0', '0'),
('47', '17', '30', 'VMCPP', 'VMCPP 30 mic x 1040 mm x 6000 m', '0', '26000', '10561.83', '0', '0'),
('48', '18', '30', 'VMCPP', 'VMCPP 25 mic x 900 mm x 8000 m', '0', '25700', '327.6', '0', '0'),
('49', '18', '30', 'VMCPP', 'VMCPP 30 mic x 1100 mm x 6000 m', '0', '25700', '1261.26', '0', '0'),
('50', '19', '30', 'CPP', 'CPP 25 mic x 890 mm x 8000 m', '0', '21100', '161.98', '0', '0'),
('51', '19', '30', 'CPP', 'CPP 20 mic x 820 mm x 8000 m', '0', '21100', '119.41', '0', '0'),
('52', '20', '30', 'CPP', 'CPP 25 mic x 730 mm x 8000 m', '0', '22300', '531.44', '0', '0'),
('53', '21', '30', 'VMCPP', 'VMCPP 25 mic x 900 mm x 8000 m', '0', '26000', '655.2', '0', '0'),
('54', '22', '30', 'VMCPP', 'VMCPP 25 mic x 1020 mm x 8000 m', '0', '25000', '185.64', '0', '0'),
('55', '22', '30', 'VMCPP', 'VMCPP 25 mic x 1060 mm x 8000 m', '0', '25000', '2315.04', '0', '0'),
('56', '22', '30', 'VMCPP', 'VMCPP 25 mic x 1120 mm x 8000 m', '0', '25000', '4892.16', '0', '0'),
('57', '22', '30', 'VMCPP', 'VMCPP 25 mic x 1140 mm x 8000 m', '0', '25000', '4149.6', '0', '0'),
('58', '23', '30', 'VMCPP', 'VMCPP 25 mic x 1020 mm x 8000 m', '0', '26000', '8910.72', '0', '0'),
('59', '23', '30', 'VMCPP', 'VMCPP 25 mic x 1060 mm x 8000 m', '0', '26000', '4630.08', '0', '0'),
('60', '23', '30', 'VMCPP', 'VMCPP 25 mic x 1140 mm x 8000 m', '0', '26000', '8299.2', '0', '0'),
('61', '23', '30', 'VMCPP', 'VMCPP 25 mic x 1220 mm x 8000 m', '0', '26000', '9103.64', '0', '0'),
('62', '24', '30', 'CPP', 'CPP 30 mic x 820 mm x 6000 m', '0', '22300', '134.31', '0', '0'),
('63', '25', '30', 'CPP', 'CPP 25 mic x 1030 mm x 8000 m', '0', '20000', '14059.5', '0', '0'),
('64', '26', '30', 'VMCPP', 'VMCPP 35 mic x 855 mm x 6000 m', '0', '26900', '96.57', '0', '0'),
('65', '26', '30', 'VMCPP', 'VMCPP 35 mic x 1035 mm x 6000 m', '0', '26900', '1670.78', '0', '0'),
('66', '26', '30', 'VMCPP', 'VMCPP 35 mic x 915 mm x 6000 m', '0', '26900', '2104.02', '0', '0'),
('67', '26', '30', 'VMCPP', 'VMCPP 35 mic x 1015 mm x 6000 m', '0', '26900', '46332.71', '0', '0'),
('68', '26', '30', 'VMCPP', 'VMCPP 40 mic x 815 mm x 4000 m', '0', '26900', '5300', '0', '0'),
('69', '26', '30', 'VMCPP', 'VMCPP 25 mic x 1015 mm x 8000 m', '0', '26900', '10400', '0', '0'),
('70', '27', '30', 'VMCPP', 'VMCPP 30 mic x 915 mm x 6000 m', '0', '29500', '2100.58', '0', '0'),
('71', '27', '30', 'VMCPP', 'VMCPP 25 mic x 975 mm x 8000 m', '0', '29500', '790.2', '0', '0'),
('72', '27', '30', 'VMCPP', 'VMCPP 25 mic x 1015 mm x 8000 m', '0', '29500', '6700', '0', '0'),
('73', '27', '30', 'VMCPP', 'VMCPP 25 mic x 995 mm x 8000 m', '0', '29500', '775.64', '0', '0'),
('74', '28', '30', 'VMCPP', 'VMCPP 25 mic x 1050 mm x 8000 m', '0', '25200', '417.8', '0', '0'),
('75', '29', '30', 'VMCPP', 'VMCPP 25 mic x 1050 mm x 8000 m', '0', '26300', '1600', '0', '0'),
('76', '29', '30', 'VMCPP', 'VMCPP 30 mic x 915 mm x 6000 m', '0', '26300', '1.48', '0', '0'),
('77', '29', '30', 'VMCPP', 'VMCPP 25 mic x 995 mm x 8000 m', '0', '26300', '3.84', '0', '0'),
('78', '29', '30', 'CPP', 'CPP 35 mic x 1065 mm x 6000 m', '0', '22300', '10600', '0', '0'),
('79', '29', '30', 'VMCPP', 'VMCPP 25 mic x 995 mm x 8000 m', '0', '26300', '3.84', '0', '0'),
('80', '29', '30', 'VMCPP', 'VMCPP 25 mic x 1065 mm x 8000 m', '0', '26300', '74.04', '0', '0'),
('81', '29', '30', 'VMCPP', 'VMCPP 25 mic x 975 mm x 800 m', '0', '26300', '70.6', '0', '0'),
('82', '30', '30', 'VMCPP', 'VMCPP 40 mic x 855 mm x 4000 m', '0', '25300', '810.89', '0', '0'),
('83', '31', '30', 'VMCPP', 'VMCPP 25 mic x 1100 mm x 8000 m', '0', '25800', '39439.4', '0', '0'),
('84', '32', '30', 'VMCPP', 'VMCPP 25 mic x 1040 mm x 8000 m', '0', '25000', '3785.6', '0', '0'),
('85', '32', '30', 'VMCPP', 'VMCPP 25 mic x 1120 mm x 8000 m', '0', '25000', '4076.8', '0', '0'),
('86', '32', '30', 'VMCPP', 'VMCPP 25 mic x 1220 mm x 8000 m', '0', '25000', '2442.44', '0', '0'),
('87', '32', '30', 'VMCPP', 'VMCPP 30 mic x 1100 mm x 6000 m', '0', '25000', '4144.14', '0', '0'),
('88', '33', '30', 'VMCPP', 'VMCPP 30 mic x 1100 mm x 6000 m', '0', '26000', '5585.58', '0', '0'),
('89', '34', '30', 'CPP', 'CPP 40 mic x 1060 mm x 4000 m', '0', '24000', '617.34', '0', '0');

### Structure of table `0_sales_orders` ###

DROP TABLE IF EXISTS `0_sales_orders`;

CREATE TABLE `0_sales_orders` (
  `order_no` int(11) NOT NULL,
  `trans_type` smallint(6) NOT NULL DEFAULT '30',
  `version` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `debtor_no` int(11) NOT NULL DEFAULT '0',
  `branch_code` int(11) NOT NULL DEFAULT '0',
  `reference` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `customer_ref` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comments` tinytext COLLATE utf8_unicode_ci,
  `ord_date` date NOT NULL DEFAULT '0000-00-00',
  `order_type` int(11) NOT NULL DEFAULT '0',
  `ship_via` int(11) NOT NULL DEFAULT '0',
  `delivery_address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `contact_phone` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deliver_to` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `freight_cost` double NOT NULL DEFAULT '0',
  `from_stk_loc` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `delivery_date` date NOT NULL DEFAULT '0000-00-00',
  `payment_terms` int(11) DEFAULT NULL,
  `total` double NOT NULL DEFAULT '0',
  `prep_amount` double NOT NULL DEFAULT '0',
  `alloc` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`trans_type`,`order_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_sales_orders` ###

INSERT INTO `0_sales_orders` VALUES
('1', '30', '0', '0', '31', '30', '1993/PO/TAC/XII/20', '', NULL, '2020-12-22', '2', '1', 'Jl. H. Agus Salim No.9\nPoris Plawad - Cipondoh, Tangerang', NULL, NULL, 'TUNAS ALFIN TBK, PT', '0', 'DEF', '2021-01-06', '5', '216397244.8', '0', '0'),
('2', '30', '0', '0', '32', '31', '1135/MMP/XII/2020', '', NULL, '2020-12-19', '2', '1', 'Jl. Raya Serang Km.24 Kp.Hauan Tobat Balaraja Kab.Tangerang Banten', NULL, NULL, 'MITRA MULTI PACKAGING, PT', '0', 'DEF', '2021-01-06', '7', '189636947.5', '0', '0'),
('3', '30', '0', '0', '33', '32', 'PORM.2011.0118', '', NULL, '2020-12-18', '2', '1', 'Jl.Industri Raya Blok C NO.1\nKel.Pasirjaya , Kec.Jatiuwung\nTangerang - 15135', NULL, NULL, 'PT SAPTA WARNA CEMERLANG', '0', 'DEF', '2020-12-19', '5', '29466880.3', '0', '0'),
('4', '30', '0', '0', '34', '33', 'P976/20/SPK/PO', '', NULL, '2020-12-18', '2', '1', 'Jl. Tanjung Pura no. 8  RT. 005/05, Pegadungan \nKalideres, Jakarta Barat', NULL, NULL, 'SINAR PELANGI KEMASINDO, PT', '0', 'DEF', '2021-01-06', '5', '2893000', '0', '0'),
('5', '30', '0', '0', '33', '32', 'PORM.2011.0244', '', NULL, '2020-12-16', '2', '1', 'Jl.Industri Raya Blok C NO.1\nKel.Pasirjaya , Kec.Jatiuwung\nTangerang - 15135', NULL, NULL, 'PT SAPTA WARNA CEMERLANG', '0', 'DEF', '2020-12-17', '5', '34561697.5', '0', '0'),
('6', '30', '0', '0', '35', '34', '0242/SIP/SC/XII/20', '', NULL, '2020-12-16', '2', '1', 'Jl.Sei Belumai Hilir No.103 A, Tanjung Morawa A\nTanjung Morawa, Deli Serdang - 20362', NULL, NULL, 'SINDOMAS INTI PERKASA, PT', '0', 'DEF', '2020-12-17', '5', '31238636', '0', '0'),
('7', '30', '1', '0', '36', '35', 'CKP-47551933', '', NULL, '2020-12-15', '2', '1', 'Jl.Raya Serang KM.12, RT.005/001\nSuka Damai - Cikupta Tangerang', NULL, NULL, 'PT.THE UNIVENUS', '0', 'DEF', '2020-12-16', '5', '262056833.28', '0', '0'),
('8', '30', '0', '0', '36', '35', 'CKP-47551934', '', NULL, '2020-12-15', '2', '1', 'Jl.Raya Serang KM.12, RT.005/001\nSuka Damai - Cikupta Tangerang', NULL, NULL, 'PT.THE UNIVENUS', '0', 'DEF', '2020-12-16', '5', '325395558.4', '0', '0'),
('9', '30', '1', '0', '36', '35', 'CKP-49904143', '', NULL, '2020-11-20', '2', '1', 'Jl.Raya Serang KM.12, RT.005/001\nSuka Damai - Cikupta Tangerang', NULL, NULL, 'PT.THE UNIVENUS', '0', 'DEF', '2020-11-21', '5', '47609661.44', '0', '0'),
('10', '30', '2', '0', '36', '35', 'CKP-47549982', '', NULL, '2020-11-25', '2', '1', 'Jl.Raya Serang KM.12, RT.005/001\nSuka Damai - Cikupta Tangerang', NULL, NULL, 'PT.THE UNIVENUS', '0', 'DEF', '2020-11-26', '5', '15933716.48', '0', '0'),
('11', '30', '1', '0', '32', '31', '0934/MMP/X/2020', '', NULL, '2020-10-23', '2', '1', 'Jl. Raya Serang Km.24 Kp.Hauan Tobat Balaraja Kab.Tangerang Banten', NULL, NULL, 'MITRA MULTI PACKAGING, PT', '0', 'DEF', '2020-10-24', '7', '402926749.5', '0', '0'),
('12', '30', '1', '0', '32', '31', '0857/MMP/X/2020', '', NULL, '2020-10-07', '2', '1', 'Jl. Raya Serang Km.24 Kp.Hauan Tobat Balaraja Kab.Tangerang Banten', NULL, NULL, 'MITRA MULTI PACKAGING, PT', '0', 'DEF', '2020-10-08', '7', '39402968', '0', '0'),
('13', '30', '1', '0', '33', '32', 'PORM.2011.0188', '', NULL, '2020-11-20', '2', '1', 'Jl.Industri Raya Blok C NO.1\nKel.Pasirjaya , Kec.Jatiuwung\nTangerang - 15135', NULL, NULL, 'PT SAPTA WARNA CEMERLANG', '0', 'DEF', '2020-11-21', '5', '193854144', '0', '0'),
('14', '30', '1', '0', '33', '32', 'PORM.2010.0019', '', NULL, '2020-10-02', '2', '1', 'Jl.Industri Raya Blok C NO.1\nKel.Pasirjaya , Kec.Jatiuwung\nTangerang - 15135', NULL, NULL, 'PT SAPTA WARNA CEMERLANG', '0', 'DEF', '2020-10-03', '5', '108579873.6', '0', '0'),
('15', '30', '1', '0', '37', '36', 'GM20100006', '', NULL, '2020-10-01', '2', '1', 'Kp. Cikedokan  RT/RW : 005/012, Sukadanau \nCikarang Barat Bekasi - Jawa Barat', NULL, NULL, 'SARANA PRIMA NUSANTARA ABADI, PT', '0', 'DEF', '2020-10-02', '5', '859852065.6', '0', '0'),
('16', '30', '3', '0', '37', '36', 'GM20110044', '', NULL, '2021-01-04', '2', '1', 'Kp. Cikedokan  RT/RW : 005/012, Sukadanau \nCikarang Barat Bekasi - Jawa Barat', NULL, NULL, 'SARANA PRIMA NUSANTARA ABADI, PT', '0', 'DEF', '2021-01-05', '5', '100122422.4', '0', '0'),
('17', '30', '0', '0', '5', '4', '0320/AJS/034', '', NULL, '2020-03-19', '2', '1', 'Jl. Raya Mauk km.7 Kawasan Industri Mekar Jaya IV\nMekar Jaya - Sepatan, Tangerang - Banten', NULL, NULL, 'ANEKA JASUMA SEJAHTERA, PT', '0', 'DEF', '2020-03-20', '5', '2007604170', '0', '0'),
('18', '30', '0', '0', '5', '4', '0620/AJS/026', '', NULL, '2020-06-12', '2', '1', 'Jl. Raya Mauk km.7 Kawasan Industri Mekar Jaya IV\nMekar Jaya - Sepatan, Tangerang - Banten', NULL, NULL, 'ANEKA JASUMA SEJAHTERA, PT', '0', 'DEF', '2020-06-13', '5', '44917072.2', '0', '0'),
('19', '30', '0', '0', '5', '4', '1020/AJS/034', '', NULL, '2020-10-22', '2', '1', 'Jl. Raya Mauk km.7 Kawasan Industri Mekar Jaya IV\nMekar Jaya - Sepatan, Tangerang - Banten', NULL, NULL, 'ANEKA JASUMA SEJAHTERA, PT', '0', 'DEF', '2020-10-23', '5', '6531061.9', '0', '0'),
('20', '30', '0', '0', '38', '37', 'OP20110024	', '', NULL, '2020-11-04', '2', '1', 'Kawasan Industi Mekarjaya Km 7 Jl.Karet 2 /10\nMekar Jaya - Sepatan, Tangerang', NULL, NULL, 'PUTRA NAGA INDOTAMA, PT', '0', 'DEF', '2020-11-05', '5', '13036223.2', '0', '0'),
('21', '30', '0', '0', '38', '37', 'OP20030102', '', NULL, '2020-03-19', '2', '1', 'Kawasan Industi Mekarjaya Km 7 Jl.Karet 2 /10\nMekar Jaya - Sepatan, Tangerang', NULL, NULL, 'PUTRA NAGA INDOTAMA, PT', '0', 'DEF', '2020-03-20', '5', '18738720', '0', '0'),
('22', '30', '0', '0', '38', '37', 'OP20020129', '', NULL, '2020-02-29', '2', '1', 'Kawasan Industi Mekarjaya Km 7 Jl.Karet 2 /10\nMekar Jaya - Sepatan, Tangerang', NULL, NULL, 'PUTRA NAGA INDOTAMA, PT', '0', 'DEF', '2020-03-01', '5', '317417100', '0', '0'),
('23', '30', '0', '0', '38', '37', 'OP20030103', '', NULL, '2020-03-19', '2', '1', 'Kawasan Industi Mekarjaya Km 7 Jl.Karet 2 /10\nMekar Jaya - Sepatan, Tangerang', NULL, NULL, 'PUTRA NAGA INDOTAMA, PT', '0', 'DEF', '2020-03-20', '5', '884988104', '0', '0'),
('24', '30', '0', '0', '38', '37', 'OP20110033', '', NULL, '2020-11-05', '2', '1', 'Kawasan Industi Mekarjaya Km 7 Jl.Karet 2 /10\nMekar Jaya - Sepatan, Tangerang', NULL, NULL, 'PUTRA NAGA INDOTAMA, PT', '0', 'DEF', '2020-11-06', '5', '3294624.3', '0', '0'),
('25', '30', '0', '0', '37', '36', 'GM20100002', '', NULL, '2020-10-01', '2', '1', 'Kp. Cikedokan  RT/RW : 005/012, Sukadanau \nCikarang Barat Bekasi - Jawa Barat', NULL, NULL, 'SARANA PRIMA NUSANTARA ABADI, PT', '0', 'DEF', '2021-01-07', '5', '309309000', '0', '0'),
('26', '30', '0', '0', '31', '30', '1849/PO/TA/XI/20', '', NULL, '2020-11-27', '2', '1', 'Jl. H. Agus Salim No.9\nPoris Plawad - Cipondoh, Tangerang', NULL, NULL, 'TUNAS ALFIN TBK, PT', '0', 'DEF', '2020-11-28', '5', '1950101727.2', '0', '0'),
('27', '30', '0', '0', '31', '30', '1907/PO/TAC/XII/20', '', NULL, '2020-12-09', '2', '1', 'Jl. H. Agus Salim No.9\nPoris Plawad - Cipondoh, Tangerang', NULL, NULL, 'TUNAS ALFIN TBK, PT', '0', 'DEF', '2020-12-10', '5', '336390329', '0', '0'),
('28', '30', '0', '0', '31', '30', '1009/PO/TAC/VII/20', '', NULL, '2020-07-13', '2', '1', 'Jl. H. Agus Salim No.9\nPoris Plawad - Cipondoh, Tangerang', NULL, NULL, 'TUNAS ALFIN TBK, PT', '0', 'DEF', '2020-07-14', '5', '11581416', '0', '0'),
('29', '30', '0', '0', '31', '30', '1731/PO/TAC/XI/20', '', NULL, '2020-11-05', '2', '1', 'Jl. H. Agus Salim No.9\nPoris Plawad - Cipondoh, Tangerang', NULL, NULL, 'TUNAS ALFIN TBK, PT', '0', 'DEF', '2020-11-06', '5', '310755434', '0', '0'),
('30', '30', '0', '0', '31', '30', '1654/PO/TAC/X/20', '', NULL, '2020-10-21', '2', '1', 'Jl. H. Agus Salim No.9\nPoris Plawad - Cipondoh, Tangerang', NULL, NULL, 'TUNAS ALFIN TBK, PT', '0', 'DEF', '2020-10-22', '5', '22567068.7', '0', '0'),
('31', '30', '0', '0', '38', '37', 'POP2010026', '', NULL, '2020-10-23', '2', '1', 'Kawasan Industi Mekarjaya Km 7 Jl.Karet 2 /10\nMekar Jaya - Sepatan, Tangerang', NULL, NULL, 'PUTRA NAGA INDOTAMA, PT', '0', 'DEF', '2020-10-24', '5', '1119290172', '0', '0'),
('32', '30', '0', '0', '38', '37', 'POP2002077', '', NULL, '2020-02-29', '2', '1', 'Kawasan Industi Mekarjaya Km 7 Jl.Karet 2 /10\nMekar Jaya - Sepatan, Tangerang', NULL, NULL, 'PUTRA NAGA INDOTAMA, PT', '0', 'DEF', '2020-03-01', '5', '397346950', '0', '0'),
('33', '30', '0', '0', '38', '37', 'POP2006014', '', NULL, '2020-06-18', '2', '1', 'Kawasan Industi Mekarjaya Km 7 Jl.Karet 2 /10\nMekar Jaya - Sepatan, Tangerang', NULL, NULL, 'PUTRA NAGA INDOTAMA, PT', '0', 'DEF', '2020-06-19', '5', '159747588', '0', '0'),
('34', '30', '0', '0', '38', '37', 'POP2004013', '', NULL, '2020-04-07', '2', '1', 'Kawasan Industi Mekarjaya Km 7 Jl.Karet 2 /10\nMekar Jaya - Sepatan, Tangerang', NULL, NULL, 'PUTRA NAGA INDOTAMA, PT', '0', 'DEF', '2020-04-08', '5', '16297776', '0', '0');

### Structure of table `0_sales_pos` ###

DROP TABLE IF EXISTS `0_sales_pos`;

CREATE TABLE `0_sales_pos` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `pos_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `cash_sale` tinyint(1) NOT NULL,
  `credit_sale` tinyint(1) NOT NULL,
  `pos_location` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `pos_account` smallint(6) unsigned NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `pos_name` (`pos_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_sales_pos` ###

INSERT INTO `0_sales_pos` VALUES
('1', 'Default', '1', '1', 'DEF', '2', '0');

### Structure of table `0_sales_types` ###

DROP TABLE IF EXISTS `0_sales_types`;

CREATE TABLE `0_sales_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sales_type` char(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tax_included` int(1) NOT NULL DEFAULT '0',
  `factor` double NOT NULL DEFAULT '1',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sales_type` (`sales_type`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_sales_types` ###

INSERT INTO `0_sales_types` VALUES
('1', 'Ritel', '1', '1', '0'),
('2', 'Grosir', '0', '0.7', '0');

### Structure of table `0_salesman` ###

DROP TABLE IF EXISTS `0_salesman`;

CREATE TABLE `0_salesman` (
  `salesman_code` int(11) NOT NULL AUTO_INCREMENT,
  `salesman_name` char(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `salesman_phone` char(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `salesman_fax` char(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `salesman_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `provision` double NOT NULL DEFAULT '0',
  `break_pt` double NOT NULL DEFAULT '0',
  `provision2` double NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`salesman_code`),
  UNIQUE KEY `salesman_name` (`salesman_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_salesman` ###

INSERT INTO `0_salesman` VALUES
('1', 'Sales Person', '', '', '', '5', '20000', '4', '0');

### Structure of table `0_security_roles` ###

DROP TABLE IF EXISTS `0_security_roles`;

CREATE TABLE `0_security_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sections` text COLLATE utf8_unicode_ci,
  `areas` text COLLATE utf8_unicode_ci,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_security_roles` ###

INSERT INTO `0_security_roles` VALUES
('1', 'Pencarian', 'Pencarian', '768;2816;3072;3328;5632;5888;8192;8448;10752;11008;13312;15872;16128', '257;258;259;260;513;514;515;516;517;518;519;520;521;522;523;524;525;773;774;2822;3073;3075;3076;3077;3329;3330;3331;3332;3333;3334;3335;5377;5633;5640;5889;5890;5891;7937;7938;7939;7940;8193;8194;8450;8451;10497;10753;11009;11010;11012;13313;13315;15617;15618;15619;15620;15621;15622;15623;15624;15625;15626;15873;15882;16129;16130;16131;16132;775', '0'),
('2', 'Admin Sistem', 'Admin Sistem', '256;512;768;2816;3072;3328;5376;5632;5888;7936;8192;8448;9216;9472;9728;10496;10752;11008;13056;13312;15616;15872;16128', '257;258;259;260;513;514;515;516;517;518;519;520;521;522;523;524;525;526;769;770;771;772;773;774;775;2817;2818;2819;2820;2821;2822;2823;3073;3074;3082;3075;3076;3077;3078;3079;3080;3081;3329;3330;3331;3332;3333;3334;3335;5377;5633;5634;5635;5636;5637;5641;5638;5639;5640;5889;5890;5891;7937;7938;7939;7940;8193;8194;8195;8196;8197;8449;8450;8451;9217;9218;9220;9473;9474;9475;9476;9729;10497;10753;10754;10755;10756;10757;11009;11010;11011;11012;13057;13313;13314;13315;15617;15618;15619;15620;15621;15622;15623;15624;15628;15625;15626;15627;15630;15629;15873;15874;15875;15876;15877;15878;15879;15880;15883;15881;15882;15884;16129;16130;16131;16132', '0'),
('3', 'Mgr Sales', 'Mgr Sales', '768;3072;5632;8192;15872', '773;774;3073;3075;3081;5633;8194;15873;775', '0'),
('4', 'Mgr Gudang', 'Mgr Gudang', '2816;3072;3328;5632;5888;8192;8448;10752;11008;13312;15872;16128;768', '775', '0'),
('5', 'Mgr Produksi', 'Mgr Produksi', '512;2816;3072;3328;5632;5888;8192;8448;10752;11008;13312;15616;15872;16128;768', '775', '0'),
('6', 'Pembelian', 'Pembelian', '512;768;2816;3072;3328;5376;5632;5888;7936;8192;8448;10752;11008;13312;15616;15872;16128', '517;518;769;775;5633;5634;5635;7937;7938;7939;7940', '0'),
('7', 'Penagihan', 'Penagihan', '512;768;2816;3072;3328;5632;5888;8192;8448;10752;11008;13312;15616;15872;16128', '521;523;524;771;773;774;2818;2819;2820;2821;2822;2823;3073;3073;3074;3075;3076;3077;3078;3079;3080;3081;3081;3329;3330;3330;3330;3331;3331;3332;3333;3334;3335;5633;5633;5634;5637;5638;5639;5640;5640;5889;5890;5891;8193;8194;8194;8196;8197;8450;8451;10753;10755;11009;11010;11012;13313;13315;15617;15619;15620;15621;15624;15624;15873;15876;15877;15878;15880;15882;16129;16130;16131;16132;775', '0'),
('8', 'Pembayaran', 'Pembayaran', '512;2816;3072;3328;5376;5632;5888;8192;8448;10752;11008;13312;15616;15872;16128;768', '775', '0'),
('9', 'Akuntan', 'Akuntan Baru', '512;768;2816;3072;3328;5376;5632;5888;8192;8448;10752;11008;13312;15616;15872;16128', '257;258;259;260;521;523;524;771;772;773;774;2818;2819;2820;2821;2822;2823;3073;3074;3075;3076;3077;3078;3079;3080;3081;3329;3330;3331;3332;3333;3334;3335;5377;5633;5634;5635;5637;5638;5639;5640;5889;5890;5891;7937;7938;7939;7940;8193;8194;8196;8197;8449;8450;8451;10497;10753;10755;11009;11010;11012;13313;13315;15617;15618;15619;15620;15621;15624;15873;15876;15877;15878;15880;15882;16129;16130;16131;16132;775', '0'),
('10', 'Sub Admin', 'Sub Admin', '512;768;2816;3072;3328;5376;5632;5888;8192;8448;10752;11008;13312;15616;15872;16128', '257;258;259;260;521;523;524;771;772;773;774;2818;2819;2820;2821;2822;2823;3073;3074;3082;3075;3076;3077;3078;3079;3080;3081;3329;3330;3331;3332;3333;3334;3335;5377;5633;5634;5635;5637;5638;5639;5640;5889;5890;5891;7937;7938;7939;7940;8193;8194;8196;8197;8449;8450;8451;10497;10753;10755;11009;11010;11012;13057;13313;13315;15617;15619;15620;15621;15624;15873;15874;15876;15877;15878;15879;15880;15882;16129;16130;16131;16132;775', '0'),
('11', 'Finance And Accounting', 'Finance And Accounting', '256;512;768;2816;3072;5376;5632;5888;7936;8192;8448;9216;9472;9728;15616;15872;16128', '769;3080;5377;5633;5634;5636;5637;5641;5638;5639;5640;5889;5890;5891;7937;7938;7939;7940;8193;8194;8195;8196;8197;8449;8450;8451;9217;9218;9220;9473;9474;9475;9476;9729;15617;15618;15619;15620;15621;15622;15623;15624;15628;15627;15630;15873;15874;15875;15876;15877;15878;15879;15880;15883;15881;15884;16129;16130;16131;16132', '0'),
('12', 'Penjualan', 'Penjualan', '2816;3072;3328;15616;15872;16128', '2817;2818;2819;2820;2821;2822;2823;3073;3074;3082;3075;3076;3077;3078;3079;3080;3081;3329;3330;3331;3332;3333;3334;3335;15617;15618;15619;15620;15621;15622;15623;15624;15628;15625;15626;15627;15630;15629;15873;15874;15875;15876;15877;15878;15879;15880;15883;15881;15882;15884;16129;16130;16131;16132', '0');

### Structure of table `0_shippers` ###

DROP TABLE IF EXISTS `0_shippers`;

CREATE TABLE `0_shippers` (
  `shipper_id` int(11) NOT NULL AUTO_INCREMENT,
  `shipper_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone2` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `contact` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`shipper_id`),
  UNIQUE KEY `name` (`shipper_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_shippers` ###

INSERT INTO `0_shippers` VALUES
('1', 'Default', '', '', '', '', '0');

### Structure of table `0_sql_trail` ###

DROP TABLE IF EXISTS `0_sql_trail`;

CREATE TABLE `0_sql_trail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sql` text COLLATE utf8_unicode_ci NOT NULL,
  `result` tinyint(1) NOT NULL,
  `msg` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_sql_trail` ###


### Structure of table `0_stock_category` ###

DROP TABLE IF EXISTS `0_stock_category`;

CREATE TABLE `0_stock_category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_tax_type` int(11) NOT NULL DEFAULT '1',
  `dflt_units` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'each',
  `dflt_mb_flag` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'B',
  `dflt_sales_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_cogs_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_inventory_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_adjustment_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_wip_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_dim1` int(11) DEFAULT NULL,
  `dflt_dim2` int(11) DEFAULT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  `dflt_no_sale` tinyint(1) NOT NULL DEFAULT '0',
  `dflt_no_purchase` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `description` (`description`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_stock_category` ###

INSERT INTO `0_stock_category` VALUES
('1', 'Komponen', '1', 'each', 'B', '4100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0'),
('2', 'Jasa', '1', 'each', 'D', '4100', '5101', '1420', '5104', '1415', '0', '0', '0', '0', '0'),
('3', 'Barang Dagang', '1', 'each', 'B', '4100', '5101', '1420', '5104', '1415', '0', '0', '0', '0', '0'),
('4', 'Barang Jadi', '1', 'each', 'M', '4100', '5101', '1420', '5104', '1415', '0', '0', '0', '0', '0'),
('5', 'Resin', '1', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0'),
('6', 'FG CPP', '1', 'Kg.', 'M', '4100', '5101', '1420', '5104', '1420', '0', '0', '0', '0', '0'),
('7', 'FG VMCPP', '1', 'Kg.', 'M', '4101', '5101', '1420', '5104', '1420', '0', '0', '0', '0', '0'),
('8', 'Persediaan Packing', '1', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0'),
('9', 'Persediaan Bahan Pendukung', '1', 'each', 'B', '7100', '5101', '1422', '5104', '1415', '0', '0', '0', '0', '0'),
('10', 'WIP PP', '1', 'Kg.', 'M', '4100', '5101', '1415', '5104', '1415', '0', '0', '0', '0', '0'),
('11', 'WIP PM', '1', 'Kg.', 'M', '4101', '5101', '1415', '5104', '1415', '0', '0', '0', '0', '0'),
('12', 'Bangunan Pabrik', '1', 'each', 'F', '7100', '5210', '1300', '1340', '1415', '0', '0', '0', '0', '0'),
('13', 'Kendaraan', '1', 'each', 'F', '7100', '5213', '1301', '1340', '1415', '0', '0', '0', '0', '0'),
('14', 'Peralatan &amp; Perlengkapan', '1', 'Batang', 'F', '7100', '5212', '1303', '1340', '1415', '0', '0', '0', '0', '0'),
('15', 'Mesin', '1', 'Set', 'F', '7100', '5211', '1304', '1340', '1415', '0', '0', '0', '0', '0');

### Structure of table `0_stock_fa_class` ###

DROP TABLE IF EXISTS `0_stock_fa_class`;

CREATE TABLE `0_stock_fa_class` (
  `fa_class_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `parent_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `long_description` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `depreciation_rate` double NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fa_class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_stock_fa_class` ###

INSERT INTO `0_stock_fa_class` VALUES
('01', '01', 'Gol. 1', '', '25', '0'),
('02', '02', 'Gol. II', '', '12.5', '0'),
('03', '03', 'Gol. III', '', '6.3', '0'),
('04', '04', 'Tanah', '', '0', '0'),
('05', '05', 'Bangunan', '', '5', '0');

### Structure of table `0_stock_master` ###

DROP TABLE IF EXISTS `0_stock_master`;

CREATE TABLE `0_stock_master` (
  `stock_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `category_id` int(11) NOT NULL DEFAULT '0',
  `tax_type_id` int(11) NOT NULL DEFAULT '0',
  `description` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `long_description` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `units` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'each',
  `mb_flag` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'B',
  `sales_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `cogs_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `inventory_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `adjustment_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `wip_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dimension_id` int(11) DEFAULT NULL,
  `dimension2_id` int(11) DEFAULT NULL,
  `purchase_cost` double NOT NULL DEFAULT '0',
  `material_cost` double NOT NULL DEFAULT '0',
  `labour_cost` double NOT NULL DEFAULT '0',
  `overhead_cost` double NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  `no_sale` tinyint(1) NOT NULL DEFAULT '0',
  `no_purchase` tinyint(1) NOT NULL DEFAULT '0',
  `editable` tinyint(1) NOT NULL DEFAULT '0',
  `depreciation_method` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `depreciation_rate` double NOT NULL DEFAULT '0',
  `depreciation_factor` double NOT NULL DEFAULT '0',
  `depreciation_start` date NOT NULL DEFAULT '0000-00-00',
  `depreciation_date` date NOT NULL DEFAULT '0000-00-00',
  `fa_class_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_stock_master` ###

INSERT INTO `0_stock_master` VALUES
('BANTALAN', '8', '1', 'BANTALAN KAYU', 'BANTALAN KAYU', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '100', '100', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('BP-RMP-001', '9', '1', 'ALUMINIUM WIRE SIZE DIA 1.8 mm', 'ALUMINIUM WIRE SIZE DIA 1.8 mm', 'Kg.', 'B', '7100', '5101', '1422', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('BP-RMP-002', '9', '1', 'ALUMINIUM WIRE SIZE DIA 2.0 mm', 'ALUMINIUM WIRE SIZE DIA 2.0 mm', 'Kg.', 'B', '7100', '5101', '1422', '5104', '1415', '0', '0', '46800', '46800', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('BP0002', '9', '1', 'EVAPORATOR BOAT SIZE 130 X 38 X 9 MM', '', 'Pc.', 'B', '7100', '5101', '1422', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('CPP', '6', '1', 'CPP', '', 'Kg.', 'M', '4100', '5101', '1420', '5104', '1420', '0', '0', '46800', '46800', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('FIX-01/2021', '14', '1', 'DINDAN COOLING PANEL/ PENDINGIN SERVO 70ACU.005', 'DINDAN COOLING PANEL/ PENDINGIN SERVO 70ACU.005', 'Set', 'F', '7100', '5212', '1303', '1340', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'D', '25', '0', '2021-02-28', '2021-02-28', '01'),
('JR-CPP', '10', '1', 'JUMBO ROLL PP', '', 'Kg.', 'M', '4100', '5101', '1415', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('JR-VMCPP', '11', '1', 'JUMBO ROLL VMCPP', '', 'Kg.', 'M', '4101', '5101', '1415', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('MTC-ACA-001', '2', '1', 'SCOTCH BRITE 3M 7447 MAROON', 'SCOTCH BRITE 3M 7447 MAROON', 'Box', 'D', '4100', '5205', '1420', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('MTC-GTI-001', '2', '4', 'REPAIR AS CHUCK UNWINDER SLITTING SCONDARY1', 'REPAIR AS CHUCK UNWINDER SLITTING SCONDARY1', 'Set', 'D', '4100', '5205', '1420', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('MTC-LMP-001', '2', '1', 'TIMBANGAN ELEKTRONIK ACIS 3000 KG ', 'TIMBANGAN ELEKTRONIK ACIS 3000 KG', 'each', 'D', '4100', '5205', '1420', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('MTC-MTS-001', '2', '1', 'REPAIR CONTTROLLER TEMPERATURE TYPE: CAL 9400', 'REPAIR CONTTROLLER TEMPERATURE TYPE: CAL 9400', 'Set', 'D', '4100', '5205', '1420', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('MTC-MTS-002', '2', '1', 'REPAIR TRANSMISSION DENSITOMETER MODEL: TBX-MC V2', 'REPAIR TRANSMISSION DENSITOMETER MODEL: TBX-MC V2', 'Set', 'D', '4100', '5205', '1420', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('MTC-PWC-001', '2', '4', 'RECOVER CORONA ROLL SIZE: L.3800MM X ID350MM X 356MM', 'RECOVER CORONA ROLL SIZE: L.3800MM X ID350MM X 356MM', 'Pc.', 'D', '5205', '5101', '1420', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('MTC-PWC-002', '2', '4', 'RECOVER NIP ROLL SIZE: L 3800MM X ID170MM X OD210 MM', 'RECOVER NIP ROLL SIZE: L 3800MM X ID170MM X OD210 MM', 'Pc.', 'D', '5205', '5101', '1420', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('MTC-YMS-001', '2', '1', 'DINDAN COOLING PANEL/PENDINGIN SERVO 70ACU.005', 'DINDAN COOLING PANEL/PENDINGIN SERVO 70ACU.005', 'Set', 'D', '4100', '5205', '1420', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('OFC-ATK-001', '2', '1', 'CONTINUOUS FORM 3 PLY UK A4', 'CONTINUOUS FORM 3 PLY UK A4', 'Box', 'D', '4100', '6416', '1420', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PC31001', '8', '1', 'PAPER CORE 3 in X 8 MM X 1001 MM', '', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PC31006', '8', '1', 'PAPER CORE 3 in X 8 MM X 1006 MM', '', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PC31011', '8', '1', 'PAPER CORE 3 in X 8 MM X 1011 MM', '', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PC31015', '8', '1', 'PAPER CORE 3 in X 8 MM X 1015 MM', '', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PC31016', '8', '1', 'PAPER CORE 3 in X 8 MM X 1016 MM', '', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PC31018', '8', '1', 'PAPER CORE 3 in X 8 MM X 1018 MM', '', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PC31021', '8', '1', 'PAPER CORE 3 in X 8 MM X 1021 MM', '', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PC31026', '8', '1', 'PAPER CORE 3 in X 8 MM X 1026 MM', '', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PC31036', '8', '1', 'PAPER CORE 3 in X 8 MM X 1036 MM', '', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PCH-CPD-005', '8', '3', 'LABEL TANDA PANAH MERAH', 'LABEL TANDA PANAH MERAH', 'Pc.', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PCH-SPD-005', '8', '1', 'LABEL STICKER TANDA PANAH MERAH', 'LABEL STICKER TANDA PANAH MERAH', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PCH-SPN-001', '2', '1', 'PET 12 MIC X 820 MM X 2.500 M', 'PET 12 MIC X 820 MM X 2.500 M', 'Kg.', 'D', '4100', '5205', '1420', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PCH-WFP-001', '8', '1', 'STRECTH FILM 50 CM X 300 M X 12 MIC', 'STRECTH FILM 50 CM X 300 M X 12 MIC', 'Pc.', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1000X1060', '8', '1', 'PALLET KHUSUS 1000 MM X 1060 MM', 'PALLET KHUSUS 1000 MM X 1060 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1000X1100', '8', '1', 'PALLET UTUH 1000 MM X 1100 MM', 'PALLET UTUH 1000 MM X 1100 MM', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '45000', '45000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1100X1100', '8', '1', 'PALLET UTUH 1100 MM X 1100 MM', 'PALLET UTUH 1100 MM X 1100 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '45000', '45000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1100X550', '8', '1', 'PALLET SETENGAH 1100 MM X 550 MM', 'PALLET SETENGAH 1100 MM X 550 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '25000', '25000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK114', '8', '1', 'PALANG KAYU 114,0 CM', 'PALANG KAYU 114,0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1200X1100', '8', '1', 'PALLET UTUH 1200 MM X 1100 MM', 'PALLET UTUH 1200 MM X 1100 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '45000', '45000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1200X720', '8', '1', 'PALLET KHUSUS 1200 MM X 720 MM', 'PALLET KHUSUS 1200 MM X 720 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '45000', '45000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1200X980', '8', '1', 'PALLET KHUSUS 1200 MM X 980 MM', 'PALLET KHUSUS 1200 MM X 980 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '45000', '45000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1340X1230', '8', '1', 'PALLET KHUSUS 1340 MM X 1230 MM', 'PALLET KHUSUS 1340 MM X 1230 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '100000', '100000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1460X1010', '8', '1', 'PALLET KHUSUS 1460 MM X 1010 MM', 'PALLET KHUSUS 1460 MM X 1010 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '100000', '100000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1460X1020', '8', '1', 'PALLET KHUSUS 1460 MM X 1020 MM', 'PALLET KHUSUS 1460 MM X 1020 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '100000', '100000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1460X1040', '8', '1', 'PALLET KHUSUS 1460 MM X 1040 MM', 'PALLET KHUSUS 1460 MM X 1040 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '100000', '100000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1460X1060', '8', '1', 'PALLET KHUSUS 1460 MM X 1060 MM', 'PALLET KHUSUS 1460 MM X 1060 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '100000', '100000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1460X1080', '8', '1', 'PALLET KHUSUS 1460 MM X 1080 MM', 'PALLET KHUSUS 1460 MM X 1080 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '100000', '100000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1460X1100', '8', '1', 'PALLET KHUSUS 1460 MM X 1100 MM', 'PALLET KHUSUS 1460 MM X 1100 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '100000', '100000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1460X1120', '8', '1', 'PALLET KHUSUS 1460 MM X 1120 MM', 'PALLET KHUSUS 1460 MM X 1120 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '100000', '100000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1460X1150', '8', '1', 'PALLET KHUSUS 1460 MM X 1150 MM', 'PALLET KHUSUS 1460 MM X 1150 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '100000', '100000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1460X1170', '8', '1', 'PALLET KHUSUS 1460 MM X 1170 MM', 'PALLET KHUSUS 1460 MM X 1170 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '100000', '100000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1460X1200', '8', '1', 'PALLET KHUSUS 1460 MM X 1200 MM', 'PALLET KHUSUS 1460 MM X 1200 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '100000', '100000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1460X1210', '8', '1', 'PALLET KHUSUS 1460 MM X 1210 MM', 'PALLET KHUSUS 1460 MM X 1210 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '100000', '100000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1460X1260', '8', '1', 'PALLET KHUSUS 1460 MM X 1260 MM', 'PALLET KHUSUS 1460 MM X 1260 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '100000', '100000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK1460X1270', '8', '1', 'PALLET KHUSUS 1460 MM X 1270 MM', 'PALLET KHUSUS 1460 MM X 1270 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '100000', '100000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK700X550', '8', '1', 'PALLET SETENGAH 700 MM X 550 MM', 'PALLET SETENGAH 700 MM X 550 MM', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK730X1010', '8', '1', 'PALLET KHUSUS 730 MM X 1010 MM', 'PALLET KHUSUS 730 MM X 1010 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '45000', '45000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK730X1200', '8', '1', 'PALLET KHUSUS 730 MM X 1200 MM', 'PALLET KHUSUS 730 MM X 1200 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '45000', '45000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK730X1250', '8', '1', 'PALLET KHUSUS 730 MM X 1250 MM', 'PALLET KHUSUS 730 MM X 1250 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '45000', '45000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK900X1100', '8', '1', 'PALLET UTUH 900 MM X 1100 MM', 'PALLET UTUH 900 MM X 1100 MM', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK930', '8', '2', 'PALANG KAYU 930 MM', 'PALANG KAYU 930 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK96', '8', '1', 'PALANG KAYU 96,0 CM', 'PALANG KAYU 96,0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PK980X1060', '8', '1', 'PALLET KHUSUS 980 MM X 1060 MM', 'PALLET KHUSUS 980 MM X 1060 MM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1005', '8', '2', 'PALANG KAYU 100,5 CM', 'PALANG KAYU 100,5 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1020', '8', '2', 'PALANG KAYU 102,0 CM', 'PALANG KAYU 102,0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1025', '8', '1', 'PALANG KAYU 102,5 CM', 'PALANG KAYU 102,5 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1026', '8', '1', 'PALANG KAYU 102,6 CM', 'PALANG KAYU 102,6 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1030', '8', '2', 'PALANG KAYU 103,0 CM', 'PALANG KAYU 103,0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1031', '8', '1', 'PALANG KAYU 103,1 CM', 'PALANG KAYU 103,1 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '4000', '4000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1050', '8', '2', 'PALANG KAYU 105,0 CM', 'PALANG KAYU 105,0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL106', '8', '2', 'PALANG KAYU 106,0 CM', 'PALANG KAYU 106,0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '4000', '4000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1066', '8', '1', 'PALANG KAYU 106,6 CM', 'PALANG KAYU 106,6 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '4000', '4000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1080', '8', '2', 'PALANG KAYU 108,0 CM', 'PALANG KAYU 108,0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL110', '8', '1', 'PALANG KAYU 110,0 CM', 'PALANG KAYU 110,0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '4000', '4000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL111', '8', '2', 'PALANG KAYU 111,0 CM', 'PALANG KAYU 111,0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '4000', '4000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1115', '8', '2', 'PALANG KAYU 111,5 CM', 'PALANG KAYU 111,5 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1116', '8', '2', 'PALANG KAYU 111,6 CM', 'PALANG KAYU 111,6 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '4000', '4000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL115', '8', '2', 'PALANG KAYU 115,0 CM', 'PALANG KAYU 115,0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL117', '8', '2', 'PALANG KAYU 117,0 CM', 'PALANG KAYU 117,0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '4000', '4000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1175', '8', '2', 'PALANG KAYU 117,5 CM', 'PALANG KAYU 117,5 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL120', '8', '2', 'PALANG KAYU 120 CM', 'PALANG KAYU 120 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '4000', '4000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL123', '8', '2', 'PALANG KAYU 123,0 CM', 'PALANG KAYU 123,0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL126', '8', '2', 'PALANG KAYU 126,0 CM', 'PALANG KAYU 126,0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '4000', '4000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1290', '8', '2', 'PALANG KAYU 129,0 CM', 'PALANG KAYU 129,0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1340X1020', '8', '2', 'PALET KAYU 1340 MM X 1020 MM', 'PALET KAYU 1340 MM X 1020 MM', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1340X1210', '8', '2', 'PALET KAYU 1340 MM X 1210 MM', 'PALET KAYU 1340 MM X 1210 MM', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1340X970', '8', '1', 'PALET KAYU 1340 MM X 970 MM', 'PALET KAYU 1340 MM X 970 MM', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1460X1020', '8', '1', 'PALET KAYU 1460 MM X 1020 MM', 'PALET KAYU 1460 MM X 1020 MM', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1460X1030', '8', '1', 'PALET KAYU 1460 MM X 1030 MM', 'PALET KAYU 1460 MM X 1030 MM', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1460X1090', '8', '1', 'PALET KAYU 1460 MM X 1090 MM', 'PALET KAYU 1460 MM X 1090 MM', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1460X1120', '8', '1', 'PALET KAYU 1460 MM X 1120 MM', 'PALET KAYU 1460 MM X 1120 MM', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1460X1130', '8', '1', 'PALET KAYU 1460 MM X 1130 MM', 'PALET KAYU 1460 MM X 1130 MM', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1460X1150', '8', '1', 'PALET KAYU 1460 MM X 1150 MM', 'PALET KAYU 1460 MM X 1150 MM', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1460X1210', '8', '1', 'PALET KAYU 1460 MM X 1210 MM', 'PALET KAYU 1460 MM X 1210 MM', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL1460X1260', '8', '1', 'PALET KAYU 1460 MM X 1260 MM', 'PALET KAYU 1460 MM X 1260 MM', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL180', '8', '1', 'PALANG KAYU 180,0 CM', 'PALANG KAYU 180,0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '2500', '2500', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL730X1020', '8', '1', 'PALET KAYU 730 MM X 1020 MM', 'PALET KAYU 730 MM X 1020 MM', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL730X1030', '8', '1', 'PALET KAYU 730 MM X 1030 MM', 'PALET KAYU 730 MM X 1030 MM', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL730X1090', '8', '1', 'PALET KAYU 730 MM X 1090 MM', 'PALET KAYU 730 MM X 1090 MM', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL730X1120', '8', '1', 'PALET KAYU 730 MM X 1120 MM', 'PALET KAYU 730 MM X 1120 MM', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL87', '8', '1', 'PALANG KAYU 87.0 CM', 'PALANG KAYU 87.0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '4000', '4000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL90', '8', '1', 'PALANG KAYU 90.0 CM', 'PALANG KAYU 90.0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '4000', '4000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL921', '8', '1', 'PALANG KAYU 92,1 CM', 'PALANG KAYU 92,1 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '4000', '4000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL930', '8', '2', 'PALANG KAYU 93,0 CM', 'PALANG KAYU 93,0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '4000', '4000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL945', '8', '1', 'PALANG KAYU 94,5 CM', 'PALANG KAYU 94,5 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '4000', '4000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL965', '8', '1', 'PALANG KAYU 96,5 CM', 'PALANG KAYU 96,5 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL97', '8', '1', 'PALANG KAYU 97,0 CM', 'PALANG KAYU 97,0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '4000', '4000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PL99', '8', '1', 'PALANG KAYU 99,0 CM', 'PALANG KAYU 99,0 CM', 'Batang', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '4000', '4000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PLY50X50', '8', '1', 'PLYWOOD 50 X 50 CM', 'PLYWOOD 50 X 50 CM', 'Pc.', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '7000', '7000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PLY55X55', '8', '1', 'PLYWOOD 55 X 55 CM', 'PLYWOOD 55 X 55 CM', 'Pc.', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '7000', '7000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('PROFILH', '8', '1', 'PROFIL H ALUMINIUM', 'PROFIL H ALUMINIUM', 'Pc.', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '25000', '25000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RA01', '5', '1', 'Bahan Baku ASPA 2446', 'Bahan Baku ASPA 2446', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RA02', '5', '1', 'Bahan Baku SPEER 6', '', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RA03', '5', '1', 'Bahan Baku ABVT 19 NSC', '', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RA14', '5', '1', 'SKIBLOCK 5A', 'SKIBLOCK 5A', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RA15', '5', '1', 'EXCEED 3518 CB	', '', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RA16', '5', '1', 'TAFMER A 1085 S', '', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RA21', '5', '1', 'TAFMER A 4085 S', '', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RA22', '5', '1', 'POLYWHITE P 8377 SCF AP', '', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RA24', '5', '1', 'VISTAMAXX 3588FL', 'VISTAMAXX 3588FL', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '33000', '33000', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RA27', '5', '1', 'ASIBLOCK 0085-1 MTE', 'ASIBLOCK 0085-1 MTE', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '41500', '41500', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RA28', '5', '1', 'ANTIBLOCK F15', 'ANTIBLOCK F15', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RA29', '5', '1', 'ANTIBLOCK AB5', 'ANTIBLOCK AB5', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RA30', '5', '1', 'ANTIOXIDANE AO 25', 'ANTIOXIDANE AO 25', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RES-001', '5', '1', 'Bahan baku HF 8.0 CM', 'Bahan baku HF 8.0 CM', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RES-003', '5', '1', 'Bahan Baku SFC 650 BT', 'Bahan Baku SFC 650 BT', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RES-005', '5', '1', 'Bahan Baku SFC 750 M', 'Bahan Baku SFC 750 M', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RES-006', '5', '1', 'Bahan Baku P 607 F', 'Bahan Baku P 607 F', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RES-007', '5', '1', 'Bahan Baku FL 7540 L', 'Bahan Baku FL 7540 L', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RES-011', '5', '1', 'Bahan Baku HF 7.0 CP', 'Bahan Baku HF 7.0 CP', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RES-012', '5', '1', 'Bahan Baku FL 7632 L', 'Bahan Baku FL 7632 L', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RES-013', '5', '1', 'Bahan Baku SFC 750 R', 'Bahan Baku SFC 750 R', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RES-020', '5', '1', 'Bahan Baku FL 7642', 'Bahan Baku FL 7642', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RES-026', '5', '1', 'TF 451', 'TF 451', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('RES-037', '5', '1', 'HD601 CF POLYPROPYLENE', 'HD601 CF POLYPROPYLENE', 'Kg.', 'B', '7100', '5101', '1410', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('SB-07', '8', '2', 'BLOCK TAPE MERAH 2&quot;', 'BLOCK TAPE MERAH 2&quot;', 'Pc.', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('SB-09', '8', '2', 'BLOCK TAPE BIRU 1&quot;', 'BLOCK TAPE BIRU 1&quot;', 'Pc.', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('STOPER', '8', '1', 'STOPER', 'STOPER', 'each', 'B', '7100', '5101', '1421', '5104', '1415', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0000-00-00', '0000-00-00', ''),
('VMCPP', '7', '1', 'VMCPP', '', 'Kg.', 'M', '4101', '5101', '1420', '5104', '1420', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '', '0', '0', '0000-00-00', '0000-00-00', '');

### Structure of table `0_stock_moves` ###

DROP TABLE IF EXISTS `0_stock_moves`;

CREATE TABLE `0_stock_moves` (
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_no` int(11) NOT NULL DEFAULT '0',
  `stock_id` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type` smallint(6) NOT NULL DEFAULT '0',
  `loc_code` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tran_date` date NOT NULL DEFAULT '0000-00-00',
  `price` double NOT NULL DEFAULT '0',
  `reference` char(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `qty` double NOT NULL DEFAULT '1',
  `standard_cost` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`trans_id`),
  KEY `type` (`type`,`trans_no`),
  KEY `Move` (`stock_id`,`loc_code`,`tran_date`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_stock_moves` ###

INSERT INTO `0_stock_moves` VALUES
('1', '1', 'CPP', '25', 'DEF', '2020-12-28', '46800', '', '1000', '46800'),
('2', '1', 'CPP', '25', 'DEF', '2020-12-28', '46800', '', '-1000', '46800'),
('3', '2', 'BP-RMP-002', '25', 'DEF', '2021-01-04', '46800', '', '1000', '46800'),
('4', '3', 'RA27', '25', 'DEF', '2021-01-04', '41500', '', '275', '41500'),
('5', '4', 'RA27', '25', 'DEF', '2021-01-05', '41500', '', '225', '0'),
('6', '5', 'RA24', '25', 'DEF', '2021-01-05', '33000', '', '1000', '33000'),
('7', '6', 'BANTALAN', '25', 'DEF', '2021-01-05', '100', '', '2000', '100'),
('8', '7', 'PL106', '25', 'DEF', '2021-01-05', '4000', '', '100', '4000'),
('9', '8', 'PK1100X1100', '25', 'DEF', '2021-01-05', '45000', '', '15', '45000'),
('10', '9', 'PK1000X1100', '25', 'DEF', '2021-01-05', '45000', '', '32', '45000'),
('11', '10', 'PL87', '25', 'DEF', '2021-01-05', '4000', '', '60', '4000'),
('12', '10', 'PL90', '25', 'DEF', '2021-01-05', '4000', '', '60', '4000'),
('13', '10', 'PL930', '25', 'DEF', '2021-01-05', '4000', '', '60', '4000'),
('14', '10', 'PL99', '25', 'DEF', '2021-01-05', '4000', '', '60', '4000'),
('15', '10', 'PL117', '25', 'DEF', '2021-01-05', '4000', '', '60', '4000'),
('16', '11', 'PL126', '25', 'DEF', '2021-01-05', '4000', '', '100', '4000'),
('17', '12', 'PL921', '25', 'DEF', '2021-01-05', '4000', '', '300', '4000'),
('18', '12', 'PL87', '25', 'DEF', '2021-01-05', '4000', '', '100', '4000'),
('19', '12', 'PL90', '25', 'DEF', '2021-01-05', '4000', '', '80', '4000'),
('20', '12', 'PL120', '25', 'DEF', '2021-01-05', '4000', '', '100', '4000'),
('21', '12', 'PL180', '25', 'DEF', '2021-01-05', '2500', '', '300', '2500'),
('22', '13', 'PK1200X1100', '25', 'DEF', '2021-01-05', '45000', '', '190', '45000'),
('23', '13', 'PK1100X550', '25', 'DEF', '2021-01-05', '25000', '', '16', '25000'),
('24', '13', 'PK1200X980', '25', 'DEF', '2021-01-05', '45000', '', '11', '45000'),
('25', '14', 'PK1200X720', '25', 'DEF', '2021-01-05', '45000', '', '10', '45000'),
('26', '15', 'PK1100X1100', '25', 'DEF', '2021-01-05', '45000', '', '90', '0'),
('27', '16', 'PK1000X1100', '25', 'DEF', '2021-01-05', '45000', '', '50', '0'),
('28', '17', 'PK1200X1100', '25', 'DEF', '2021-01-06', '45000', '', '51', '0'),
('29', '17', 'PK1100X550', '25', 'DEF', '2021-01-06', '25000', '', '6', '0'),
('30', '18', 'PLY50X50', '25', 'DEF', '2021-01-06', '7000', '', '305', '7000'),
('31', '18', 'PLY55X55', '25', 'DEF', '2021-01-06', '7000', '', '28', '7000'),
('32', '18', 'PROFILH', '25', 'DEF', '2021-01-06', '25000', '', '26', '25000'),
('33', '19', 'PK730X1010', '25', 'DEF', '2021-01-06', '45000', '', '1', '45000'),
('34', '19', 'PK1460X1060', '25', 'DEF', '2021-01-06', '100000', '', '2', '100000'),
('35', '19', 'PK1460X1100', '25', 'DEF', '2021-01-06', '100000', '', '1', '100000'),
('36', '19', 'PK1460X1120', '25', 'DEF', '2021-01-06', '100000', '', '3', '100000'),
('37', '19', 'PK1460X1200', '25', 'DEF', '2021-01-06', '100000', '', '4', '100000'),
('38', '19', 'PK730X1200', '25', 'DEF', '2021-01-06', '100000', '', '1', '100000'),
('39', '19', 'PK1460X1210', '25', 'DEF', '2021-01-06', '100000', '', '2', '100000'),
('40', '20', 'PL930', '25', 'DEF', '2021-01-06', '4000', '', '30', '4000'),
('41', '20', 'PL945', '25', 'DEF', '2021-01-06', '4000', '', '12', '4000'),
('42', '20', 'PL99', '25', 'DEF', '2021-01-06', '4000', '', '4', '4000'),
('43', '20', 'PL97', '25', 'DEF', '2021-01-06', '4000', '', '1', '4000'),
('44', '20', 'PL1031', '25', 'DEF', '2021-01-06', '4000', '', '1', '4000'),
('45', '20', 'PL1066', '25', 'DEF', '2021-01-06', '4000', '', '1', '4000'),
('46', '20', 'PL1116', '25', 'DEF', '2021-01-06', '4000', '', '1', '4000'),
('47', '21', 'PL111', '25', 'DEF', '2021-01-06', '4000', '', '340', '4000'),
('48', '21', 'PL110', '25', 'DEF', '2021-01-06', '4000', '', '10', '4000'),
('49', '22', 'PK1460X1010', '25', 'DEF', '2021-01-06', '100000', '', '1', '100000'),
('50', '22', 'PK1460X1020', '25', 'DEF', '2021-01-06', '100000', '', '5', '100000'),
('51', '22', 'PK1460X1040', '25', 'DEF', '2021-01-06', '100000', '', '2', '100000'),
('52', '22', 'PK1460X1080', '25', 'DEF', '2021-01-06', '100000', '', '2', '100000'),
('53', '22', 'PK1460X1150', '25', 'DEF', '2021-01-06', '100000', '', '2', '100000'),
('54', '22', 'PK1460X1170', '25', 'DEF', '2021-01-06', '100000', '', '1', '100000'),
('55', '22', 'PK1340X1230', '25', 'DEF', '2021-01-06', '100000', '', '1', '100000'),
('56', '22', 'PK730X1250', '25', 'DEF', '2021-01-06', '100000', '', '1', '100000'),
('57', '22', 'PK1460X1260', '25', 'DEF', '2021-01-06', '100000', '', '1', '100000'),
('58', '22', 'PK1460X1270', '25', 'DEF', '2021-01-06', '100000', '', '2', '100000'),
('60', '1', 'CPP', '13', 'DEF', '2021-01-04', '22650', 'SJ19182', '-4018.56', '46800'),
('61', '2', 'VMCPP', '13', 'DEF', '2021-01-04', '24600', 'SJ19181', '-3843.84', '0'),
('62', '3', 'VMCPP', '13', 'DEF', '2021-01-04', '26500', 'sj19176', '-2227.68', '0'),
('63', '4', 'VMCPP', '13', 'DEF', '2021-01-04', '26800', 'SJ19177', '-835.38', '0'),
('64', '5', 'CPP', '13', 'DEF', '2021-01-04', '21760', 'sj19174', '-665.67', '46800'),
('65', '6', 'CPP', '13', 'DEF', '2021-01-04', '21760', 'SJ19175', '-646.56', '46800'),
('66', '7', 'CPP', '13', 'DEF', '2021-01-04', '21760', 'sj19173', '-1159.34', '46800'),
('67', '8', 'VMCPP', '13', 'DEF', '2021-01-04', '24600', 'sj19179', '-960.96', '0'),
('68', '9', 'VMCPP', '13', 'DEF', '2021-01-04', '26300', 'sj19178', '-873.6', '0');

### Structure of table `0_supp_allocations` ###

DROP TABLE IF EXISTS `0_supp_allocations`;

CREATE TABLE `0_supp_allocations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) DEFAULT NULL,
  `amt` double unsigned DEFAULT NULL,
  `date_alloc` date NOT NULL DEFAULT '0000-00-00',
  `trans_no_from` int(11) DEFAULT NULL,
  `trans_type_from` int(11) DEFAULT NULL,
  `trans_no_to` int(11) DEFAULT NULL,
  `trans_type_to` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `person_id` (`person_id`,`trans_type_from`,`trans_no_from`,`trans_type_to`,`trans_no_to`),
  KEY `From` (`trans_type_from`,`trans_no_from`),
  KEY `To` (`trans_type_to`,`trans_no_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_supp_allocations` ###


### Structure of table `0_supp_invoice_items` ###

DROP TABLE IF EXISTS `0_supp_invoice_items`;

CREATE TABLE `0_supp_invoice_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supp_trans_no` int(11) DEFAULT NULL,
  `supp_trans_type` int(11) DEFAULT NULL,
  `gl_code` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `grn_item_id` int(11) DEFAULT NULL,
  `po_detail_item_id` int(11) DEFAULT NULL,
  `stock_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` tinytext COLLATE utf8_unicode_ci,
  `quantity` double NOT NULL DEFAULT '0',
  `unit_price` double NOT NULL DEFAULT '0',
  `unit_tax` double NOT NULL DEFAULT '0',
  `memo_` tinytext COLLATE utf8_unicode_ci,
  `dimension_id` int(11) NOT NULL DEFAULT '0',
  `dimension2_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `Transaction` (`supp_trans_type`,`supp_trans_no`,`stock_id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_supp_invoice_items` ###

INSERT INTO `0_supp_invoice_items` VALUES
('1', '1', '20', '0', '1', '1', 'CPP', 'ALUMINIUM WIRE SIZE DIA 2.0 mm', '0', '0', '4680', NULL, '0', '0'),
('2', '2', '20', '0', '2', '4', 'BP-RMP-002', 'ALUMINIUM WIRE SIZE DIA 2.0 mm', '1000', '46800', '4680', NULL, '0', '0'),
('3', '3', '20', '2204', '-1', '0', '', NULL, '0', '0', '0', 'biaya makan 1855paket periode 16-29desember 2020', '0', '0'),
('4', '3', '20', '6419', '-1', '0', '', NULL, '0', '0', '0', 'biaya makan 1855paket periode 16-29desember 2020	', '0', '0'),
('5', '4', '20', '5214', '-1', '0', '', NULL, '0', '1800000', '0', 'fuso ke SPK tgl 23/12/2020', '0', '0'),
('6', '4', '20', '5214', '-1', '0', '', NULL, '0', '1800000', '0', 'fuso ke Sindomas tgl 23/12/2020', '0', '0'),
('7', '5', '20', '2204', '-1', '0', '', NULL, '0', '-371000', '0', 'biaya makan 1855paket periode 16-29desember 2020', '0', '0'),
('8', '5', '20', '6419', '-1', '0', '', NULL, '0', '18550000', '0', 'biaya makan 1855paket periode 16-29desember 2020	', '0', '0'),
('9', '6', '20', '0', '4', '121', 'RA27', 'ASIBLOCK 0085-1 MTE', '225', '41500', '4150', NULL, '0', '0'),
('10', '7', '20', '0', '5', '120', 'RA24', 'VISTAMAXX 3588FL', '1000', '33000', '3300', NULL, '0', '0'),
('11', '8', '20', '0', '6', '124', 'BANTALAN', 'BANTALAN KAYU', '2000', '100', '10', NULL, '0', '0'),
('12', '9', '20', '0', '7', '83', 'PL106', 'PALANG KAYU 106,0 CM', '100', '4000', '0', NULL, '0', '0'),
('13', '10', '20', '0', '8', '105', 'PK1100X1100', 'PALLET UTUH 1100 MM X 1100 MM', '15', '45000', '4500', NULL, '0', '0'),
('14', '11', '20', '0', '9', '106', 'PK1000X1100', 'PALLET UTUH 1000 MM X 1100 MM', '32', '45000', '4500', NULL, '0', '0'),
('15', '12', '20', '0', '10', '111', 'PL87', 'PALANG KAYU 87.0 CM', '60', '4000', '400', NULL, '0', '0'),
('16', '12', '20', '0', '11', '112', 'PL90', 'PALANG KAYU 90.0 CM', '60', '4000', '400', NULL, '0', '0'),
('17', '12', '20', '0', '12', '113', 'PL930', 'PALANG KAYU 93,0 CM', '60', '4000', '0', NULL, '0', '0'),
('18', '12', '20', '0', '13', '115', 'PL99', 'PALANG KAYU 99,0 CM', '60', '4000', '400', NULL, '0', '0'),
('19', '12', '20', '0', '14', '117', 'PL117', 'PALANG KAYU 117,0 CM', '60', '4000', '0', NULL, '0', '0'),
('20', '13', '20', '0', '15', '31', 'PL126', 'PALANG KAYU 126,0 CM', '100', '4000', '0', NULL, '0', '0'),
('21', '14', '20', '0', '16', '33', 'PL921', 'PALANG KAYU 92,1 CM', '300', '4000', '400', NULL, '0', '0'),
('22', '14', '20', '0', '17', '35', 'PL87', 'PALANG KAYU 87.0 CM', '100', '4000', '400', NULL, '0', '0'),
('23', '14', '20', '0', '18', '36', 'PL90', 'PALANG KAYU 90.0 CM', '80', '4000', '400', NULL, '0', '0'),
('24', '14', '20', '0', '19', '38', 'PL120', 'PALANG KAYU 120 CM', '100', '4000', '0', NULL, '0', '0'),
('25', '14', '20', '0', '20', '40', 'PL180', 'PALANG KAYU 180,0 CM', '300', '2500', '250', NULL, '0', '0'),
('26', '15', '20', '0', '21', '41', 'PK1200X1100', 'PALLET UTUH 1200 MM X 1100 MM', '190', '45000', '4500', NULL, '0', '0'),
('27', '15', '20', '0', '22', '42', 'PK1100X550', 'PALLET SETENGAH 1100 MM X 550 MM', '16', '25000', '2500', NULL, '0', '0'),
('28', '15', '20', '0', '23', '43', 'PK1200X980', 'PALLET KHUSUS 1200 MM X 980 MM', '11', '45000', '4500', NULL, '0', '0'),
('29', '16', '20', '0', '24', '75', 'PK1200X720', 'PALLET KHUSUS 1200 MM X 720 MM', '10', '45000', '4500', NULL, '0', '0'),
('30', '17', '20', '0', '25', '105', 'PK1100X1100', 'PALLET UTUH 1100 MM X 1100 MM', '90', '45000', '4500', NULL, '0', '0'),
('31', '18', '20', '0', '26', '106', 'PK1000X1100', 'PALLET UTUH 1000 MM X 1100 MM', '50', '45000', '4500', NULL, '0', '0'),
('32', '19', '20', '0', '27', '41', 'PK1200X1100', 'PALLET UTUH 1200 MM X 1100 MM', '51', '45000', '4500', NULL, '0', '0'),
('33', '19', '20', '0', '28', '42', 'PK1100X550', 'PALLET SETENGAH 1100 MM X 550 MM', '6', '25000', '2500', NULL, '0', '0'),
('34', '20', '20', '0', '29', '125', 'PLY50X50', 'PLYWOOD 50 X 50 CM', '305', '7000', '700', NULL, '0', '0'),
('35', '20', '20', '0', '30', '126', 'PLY55X55', 'PLYWOOD 55 X 55 CM', '28', '7000', '700', NULL, '0', '0'),
('36', '20', '20', '0', '31', '127', 'PROFILH', 'PROFIL H ALUMINIUM', '26', '25000', '2500', NULL, '0', '0'),
('37', '21', '20', '3500', '-1', '0', '', NULL, '0', '24462900', '0', NULL, '0', '0'),
('38', '22', '20', '3500', '-1', '0', '', NULL, '0', '47552535', '0', NULL, '0', '0'),
('39', '23', '20', '3500', '-1', '0', '', NULL, '0', '21671840.3', '0', NULL, '0', '0'),
('40', '24', '20', '3500', '-1', '0', '', NULL, '0', '49430865', '0', NULL, '0', '0'),
('41', '25', '20', '3500', '-1', '0', '', NULL, '0', '36515600', '0', NULL, '0', '0'),
('42', '26', '20', '3500', '-1', '0', '', NULL, '0', '100100000', '0', NULL, '0', '0'),
('43', '27', '20', '3500', '-1', '0', '', NULL, '0', '0', '0', NULL, '0', '0'),
('44', '28', '20', '3500', '-1', '0', '', NULL, '0', '5400000', '0', NULL, '0', '0'),
('45', '29', '20', '3500', '-1', '0', '', NULL, '0', '22110000', '0', NULL, '0', '0'),
('46', '30', '20', '3500', '-1', '0', '', NULL, '0', '45980000', '0', NULL, '0', '0'),
('47', '31', '20', '3500', '-1', '0', '', NULL, '0', '101200000', '0', NULL, '0', '0'),
('48', '32', '20', '3500', '-1', '0', '', NULL, '0', '51480000', '0', NULL, '0', '0'),
('49', '33', '20', '3500', '-1', '0', '', NULL, '0', '3800000', '0', NULL, '0', '0'),
('50', '34', '20', '3500', '-1', '0', '', NULL, '0', '10870000', '0', NULL, '0', '0'),
('51', '35', '20', '3500', '-1', '0', '', NULL, '0', '7200000', '0', NULL, '0', '0'),
('52', '36', '20', '3500', '-1', '0', '', NULL, '0', '55954800', '0', NULL, '0', '0'),
('53', '37', '20', '3500', '-1', '0', '', NULL, '0', '112281400', '0', NULL, '0', '0'),
('54', '38', '20', '3500', '-1', '0', '', NULL, '0', '58300000', '0', NULL, '0', '0'),
('55', '39', '20', '3500', '-1', '0', '', NULL, '0', '172870500', '0', NULL, '0', '0'),
('56', '40', '20', '3500', '-1', '0', '', NULL, '0', '5712000', '0', NULL, '0', '0'),
('57', '41', '20', '3500', '-1', '0', '', NULL, '0', '3570000', '0', NULL, '0', '0'),
('58', '42', '20', '3500', '-1', '0', '', NULL, '0', '3862700', '0', NULL, '0', '0'),
('59', '43', '20', '3500', '-1', '0', '', NULL, '0', '990000', '0', NULL, '0', '0'),
('60', '44', '20', '0', '3', '121', 'RA27', 'ASIBLOCK 0085-1 MTE', '275', '41500', '4150', NULL, '0', '0'),
('61', '45', '20', '3500', '-1', '0', '', NULL, '0', '23650000', '0', NULL, '0', '0'),
('62', '46', '20', '3500', '-1', '0', '', NULL, '0', '3996000', '0', NULL, '0', '0'),
('63', '47', '20', '3500', '-1', '0', '', NULL, '0', '7507500', '0', NULL, '0', '0'),
('64', '48', '20', '3500', '-1', '0', '', NULL, '0', '4504500', '0', NULL, '0', '0'),
('65', '49', '20', '3500', '-1', '0', '', NULL, '0', '2485000', '0', NULL, '0', '0'),
('66', '50', '20', '3500', '-1', '0', '', NULL, '0', '4927800', '0', NULL, '0', '0'),
('67', '51', '20', '3500', '-1', '0', '', NULL, '0', '25221625', '0', NULL, '0', '0'),
('68', '52', '20', '3500', '-1', '0', '', NULL, '0', '33000000', '0', NULL, '0', '0'),
('69', '53', '20', '3500', '-1', '0', '', NULL, '0', '19800000', '0', NULL, '0', '0'),
('70', '54', '20', '3500', '-1', '0', '', NULL, '0', '94050000', '0', NULL, '0', '0'),
('71', '55', '20', '3500', '-1', '0', '', NULL, '0', '3850000', '0', NULL, '0', '0'),
('72', '56', '20', '3500', '-1', '0', '', NULL, '0', '38885000', '0', NULL, '0', '0'),
('73', '57', '20', '3500', '-1', '0', '', NULL, '0', '121066000', '0', NULL, '0', '0'),
('74', '58', '20', '3500', '-1', '0', '', NULL, '0', '113685000', '0', NULL, '0', '0'),
('75', '59', '20', '3500', '-1', '0', '', NULL, '0', '18150000', '0', NULL, '0', '0'),
('76', '60', '20', '3500', '-1', '0', '', NULL, '0', '4345000', '0', NULL, '0', '0'),
('77', '61', '20', '3500', '-1', '0', '', NULL, '0', '20129200', '0', NULL, '0', '0'),
('78', '62', '20', '0', '35', '51', 'PK1460X1120', 'PALLET KHUSUS 1460 MM X 1120 MM', '3', '100000', '10000', NULL, '0', '0'),
('79', '62', '20', '0', '34', '50', 'PK1460X1100', 'PALLET KHUSUS 1460 MM X 1100 MM', '1', '100000', '10000', NULL, '0', '0'),
('80', '62', '20', '0', '38', '56', 'PK1460X1210', 'PALLET KHUSUS 1460 MM X 1210 MM', '2', '100000', '10000', NULL, '0', '0'),
('81', '62', '20', '0', '36', '54', 'PK1460X1200', 'PALLET KHUSUS 1460 MM X 1200 MM', '4', '100000', '10000', NULL, '0', '0'),
('82', '62', '20', '0', '33', '48', 'PK1460X1060', 'PALLET KHUSUS 1460 MM X 1060 MM', '2', '100000', '10000', NULL, '0', '0'),
('83', '62', '20', '0', '37', '55', 'PK730X1200', 'PALLET KHUSUS 730 MM X 1200 MM', '1', '45000', '4500', NULL, '0', '0'),
('84', '62', '20', '0', '32', '45', 'PK730X1010', 'PALLET KHUSUS 730 MM X 1010 MM', '1', '45000', '4500', NULL, '0', '0'),
('85', '63', '20', '0', '39', '63', 'PL930', 'PALANG KAYU 93,0 CM', '30', '4000', '0', NULL, '0', '0'),
('86', '63', '20', '0', '40', '64', 'PL945', 'PALANG KAYU 94,5 CM', '12', '4000', '400', NULL, '0', '0'),
('87', '63', '20', '0', '41', '65', 'PL99', 'PALANG KAYU 99,0 CM', '4', '4000', '400', NULL, '0', '0'),
('88', '63', '20', '0', '42', '66', 'PL97', 'PALANG KAYU 97,0 CM', '1', '4000', '400', NULL, '0', '0'),
('89', '63', '20', '0', '43', '68', 'PL1031', 'PALANG KAYU 103,1 CM', '1', '4000', '400', NULL, '0', '0'),
('90', '63', '20', '0', '44', '69', 'PL1066', 'PALANG KAYU 106,6 CM', '1', '4000', '400', NULL, '0', '0'),
('91', '63', '20', '0', '45', '70', 'PL1116', 'PALANG KAYU 111,6 CM', '1', '4000', '0', NULL, '0', '0'),
('92', '64', '20', '0', '46', '82', 'PL111', 'PALANG KAYU 111,0 CM', '340', '4000', '0', NULL, '0', '0'),
('93', '64', '20', '0', '47', '84', 'PL110', 'PALANG KAYU 110,0 CM', '10', '4000', '400', NULL, '0', '0'),
('94', '65', '20', '0', '48', '44', 'PK1460X1010', 'PALLET KHUSUS 1460 MM X 1010 MM', '1', '100000', '10000', NULL, '0', '0'),
('95', '65', '20', '0', '49', '46', 'PK1460X1020', 'PALLET KHUSUS 1460 MM X 1020 MM', '5', '100000', '10000', NULL, '0', '0'),
('96', '65', '20', '0', '50', '47', 'PK1460X1040', 'PALLET KHUSUS 1460 MM X 1040 MM', '2', '100000', '10000', NULL, '0', '0'),
('97', '65', '20', '0', '51', '49', 'PK1460X1080', 'PALLET KHUSUS 1460 MM X 1080 MM', '2', '100000', '10000', NULL, '0', '0'),
('98', '65', '20', '0', '52', '52', 'PK1460X1150', 'PALLET KHUSUS 1460 MM X 1150 MM', '2', '100000', '10000', NULL, '0', '0'),
('99', '65', '20', '0', '53', '53', 'PK1460X1170', 'PALLET KHUSUS 1460 MM X 1170 MM', '1', '100000', '10000', NULL, '0', '0'),
('100', '65', '20', '0', '54', '57', 'PK1340X1230', 'PALLET KHUSUS 1340 MM X 1230 MM', '1', '100000', '10000', NULL, '0', '0'),
('101', '65', '20', '0', '56', '59', 'PK1460X1260', 'PALLET KHUSUS 1460 MM X 1260 MM', '1', '100000', '10000', NULL, '0', '0'),
('102', '65', '20', '0', '57', '60', 'PK1460X1270', 'PALLET KHUSUS 1460 MM X 1270 MM', '2', '100000', '10000', NULL, '0', '0'),
('103', '65', '20', '0', '55', '58', 'PK730X1250', 'PALLET KHUSUS 730 MM X 1250 MM', '1', '45000', '4500', NULL, '0', '0'),
('104', '66', '20', '3500', '-1', '0', '', NULL, '0', '0', '0', NULL, '0', '0'),
('105', '67', '20', '3500', '-1', '0', '', NULL, '0', '31350000', '0', NULL, '0', '0'),
('106', '68', '20', '3500', '-1', '0', '', NULL, '0', '20900000', '0', NULL, '0', '0'),
('107', '69', '20', '3500', '-1', '0', '', NULL, '0', '3960000', '0', NULL, '0', '0');

### Structure of table `0_supp_trans` ###

DROP TABLE IF EXISTS `0_supp_trans`;

CREATE TABLE `0_supp_trans` (
  `trans_no` int(11) unsigned NOT NULL DEFAULT '0',
  `type` smallint(6) unsigned NOT NULL DEFAULT '0',
  `supplier_id` int(11) unsigned NOT NULL DEFAULT '0',
  `reference` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `supp_reference` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tran_date` date NOT NULL DEFAULT '0000-00-00',
  `due_date` date NOT NULL DEFAULT '0000-00-00',
  `ov_amount` double NOT NULL DEFAULT '0',
  `ov_discount` double NOT NULL DEFAULT '0',
  `ov_gst` double NOT NULL DEFAULT '0',
  `rate` double NOT NULL DEFAULT '1',
  `alloc` double NOT NULL DEFAULT '0',
  `tax_included` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`type`,`trans_no`,`supplier_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `tran_date` (`tran_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_supp_trans` ###

INSERT INTO `0_supp_trans` VALUES
('1', '20', '2', 'INV/202012/0218', 'INV/202012/0218', '2021-01-04', '2021-02-03', '0', '0', '0', '1', '0', '0'),
('2', '20', '2', 'INV-202012/0218.', 'INV-202012/0218.', '2021-01-04', '2021-01-04', '46800000', '0', '4680000', '1', '0', '0'),
('3', '20', '5', 'I/CDI/I/2021', 'I/CDI/I/2021', '2021-04-01', '2021-04-01', '0', '0', '0', '1', '0', '0'),
('4', '20', '6', '182/CTL/2020', '182/CTL/2020', '2021-01-04', '2021-01-18', '3600000', '0', '0', '1', '0', '0'),
('5', '20', '5', 'I/CDI/I/2021', 'I/CDI/I/2021', '2021-01-04', '2021-01-18', '18550000', '0', '-371000', '1', '0', '0'),
('6', '20', '14', '7150048171', '7150048171', '2021-01-05', '2021-02-04', '9337500', '0', '933750', '1', '0', '0'),
('7', '20', '15', '221220/VIP/034', '221220/VIP/034', '2021-01-05', '2021-02-04', '33000000', '0', '3300000', '1', '0', '0'),
('8', '20', '4', '30/XII/2020', '30/XII/2020', '2021-01-05', '2021-01-12', '200000', '0', '0', '1', '0', '0'),
('9', '20', '4', '31/XII/2020', '31/XII/2020', '2021-01-05', '2021-01-12', '400000', '0', '0', '1', '0', '0'),
('10', '20', '4', '32/XII/2020', '32/XII/2020', '2021-01-05', '2021-01-12', '675000', '0', '0', '1', '0', '0'),
('11', '20', '4', '33/XII/2020', '33/XII/2020', '2021-01-05', '2021-01-12', '1440000', '0', '0', '1', '0', '0'),
('12', '20', '4', '34/XII/2020', '34/XII/2020', '2021-01-05', '2021-01-05', '1200000', '0', '0', '1', '0', '0'),
('13', '20', '4', '35/XII/2020', '35/XII/2020', '2021-01-05', '2021-01-12', '400000', '0', '0', '1', '0', '0'),
('14', '20', '4', '36/XII/2020', '36/XII/2020', '2021-01-05', '2021-01-12', '3070000', '0', '0', '1', '0', '0'),
('15', '20', '4', '37/XII/2020', '37/XII/2020', '2021-01-05', '2021-01-12', '9445000', '0', '0', '1', '0', '0'),
('16', '20', '4', '40/XII/2020', '40/XII/2020', '2021-01-05', '2021-01-12', '450000', '0', '0', '1', '0', '0'),
('17', '20', '4', '42/XII/2020', '42/XII/2020', '2021-01-05', '2021-01-12', '4050000', '0', '0', '1', '0', '0'),
('18', '20', '4', '43/XII/2020', '43/XII/2020', '2021-01-05', '2021-01-12', '2250000', '0', '0', '1', '0', '0'),
('19', '20', '4', '44/XII/2020', '44/XII/2020', '2021-01-06', '2021-01-13', '2445000', '0', '0', '1', '0', '0'),
('20', '20', '4', '46/XII/2020', '46/XII/2020', '2021-01-06', '2021-01-13', '2981000', '0', '0', '1', '0', '0'),
('21', '20', '17', 'FJJPL/2020000667', 'FJJPL/2020000667', '2021-01-01', '2021-03-02', '24462900', '0', '0', '1', '0', '0'),
('22', '20', '18', 'SIJKT201200021', 'SIJKT201200021', '2021-01-01', '2021-03-02', '47552535', '0', '0', '1', '0', '0'),
('23', '20', '19', '3943/INV/PTYI/XI/20', '3943/INV/PTYI/XI/20', '2021-01-01', '2021-03-02', '21671840.3', '0', '0', '1', '0', '0'),
('24', '20', '19', '4006/INV/PTYI/XII/20', '4006/INV/PTYI/XII/20', '2021-01-01', '2021-03-02', '49430865', '0', '0', '1', '0', '0'),
('25', '20', '19', '4012/INV/PTYI/XII/20	', '4012/INV/PTYI/XII/20	', '2021-01-01', '2021-03-02', '36515600', '0', '0', '1', '0', '0'),
('26', '20', '20', 'INL201100188', 'INL201100188', '2021-01-01', '2021-04-01', '100100000', '0', '0', '1', '0', '0'),
('27', '20', '20', '116/X/2020', '116/X/2020', '2021-01-01', '2021-01-06', '0', '0', '0', '1', '0', '0'),
('28', '20', '21', '116/X/2020.', '116/X/2020.', '2021-01-01', '2021-04-01', '5400000', '0', '0', '1', '0', '0'),
('29', '20', '21', '140/XII/2020	', '140/XII/2020	', '2021-01-01', '2021-04-01', '22110000', '0', '0', '1', '0', '0'),
('30', '20', '21', '141/XII/2020', '141/XII/2020', '2021-01-01', '2021-04-01', '45980000', '0', '0', '1', '0', '0'),
('31', '20', '2', 'INV/202011/0194', 'INV/202011/0194', '2021-01-01', '2021-03-02', '101200000', '0', '0', '1', '0', '0'),
('32', '20', '2', 'INV/202012/0201	', 'INV/202012/0201	', '2021-01-01', '2021-03-02', '51480000', '0', '0', '1', '0', '0'),
('33', '20', '6', '179/CTL/2020', '179/CTL/2020', '2021-01-01', '2021-02-14', '3800000', '0', '0', '1', '0', '0'),
('34', '20', '6', '181/CTL/2020', '181/CTL/2020', '2021-01-01', '2021-01-06', '10870000', '0', '0', '1', '0', '0'),
('35', '20', '6', '180/CTL/2020', '180/CTL/2020', '2021-01-01', '2021-02-14', '7200000', '0', '0', '1', '0', '0'),
('36', '20', '7', '20P00944', '20P00944', '2021-01-01', '2021-03-02', '55954800', '0', '0', '1', '0', '0'),
('37', '20', '7', '20P00960', '20P00960', '2021-01-01', '2021-03-02', '112281400', '0', '0', '1', '0', '0'),
('38', '20', '7', '20P00974', '20P00974', '2021-01-01', '2021-03-02', '58300000', '0', '0', '1', '0', '0'),
('39', '20', '7', '20P00982', '20P00982', '2021-01-01', '2021-03-02', '172870500', '0', '0', '1', '0', '0'),
('40', '20', '22', '10706', '10706', '2021-01-01', '2021-03-02', '5712000', '0', '0', '1', '0', '0'),
('41', '20', '23', '415/AP/2020', '415/AP/2020', '2021-01-01', '2021-03-02', '3570000', '0', '0', '1', '0', '0'),
('42', '20', '23', 'O330-200452204', 'O330-200452204', '2021-01-01', '2021-03-02', '3862700', '0', '0', '1', '0', '0'),
('43', '20', '23', '0075/SGI/12/20', '0075/SGI/12/20', '2021-01-01', '2021-03-02', '990000', '0', '0', '1', '0', '0'),
('44', '20', '14', '7150047979', '7150047979', '2021-01-01', '2021-01-30', '11412500', '0', '1141250', '1', '0', '0'),
('45', '20', '14', '7150047619	', '7150047619	', '2021-01-01', '2021-03-02', '23650000', '0', '0', '1', '0', '0'),
('46', '20', '26', '12/000000151F', '12/000000151F', '2021-01-01', '2021-03-02', '3996000', '0', '0', '1', '0', '0'),
('47', '20', '27', 'WFP1438/XII/20', 'WFP1438/XII/20', '2021-01-01', '2021-03-02', '7507500', '0', '0', '1', '0', '0'),
('48', '20', '27', 'WFP6868/XI/20', 'WFP6868/XI/20', '2021-01-01', '2021-03-02', '4504500', '0', '0', '1', '0', '0'),
('49', '20', '28', '005/FJE-F/XII/2020	', '005/FJE-F/XII/2020	', '2021-01-01', '2021-03-02', '2485000', '0', '0', '1', '0', '0'),
('50', '20', '28', '004/FJE-F/X/2020', '004/FJE-F/X/2020', '2021-01-01', '2021-03-02', '4927800', '0', '0', '1', '0', '0'),
('51', '20', '29', '00000609/20', '00000609/20', '2021-01-01', '2021-03-02', '25221625', '0', '0', '1', '0', '0'),
('52', '20', '30', '92233700/10/CAJ/20', '92233700/10/CAJ/20', '2021-01-01', '2021-01-06', '33000000', '0', '0', '1', '0', '0'),
('53', '20', '30', '92233701/10/CAJ/20	', '92233701/10/CAJ/20	', '2021-01-01', '2021-03-02', '19800000', '0', '0', '1', '0', '0'),
('54', '20', '30', '92233699/10/CAJ/20', '92233699/10/CAJ/20', '2021-01-06', '2021-01-06', '94050000', '0', '0', '1', '0', '0'),
('55', '20', '30', '92233715/11/CAJ/20', '92233715/11/CAJ/20', '2021-01-01', '2021-03-02', '3850000', '0', '0', '1', '0', '0'),
('56', '20', '30', '92233739/11/CAJ/20', '92233739/11/CAJ/20', '2021-01-01', '2021-03-02', '38885000', '0', '0', '1', '0', '0'),
('57', '20', '30', '92233745/11/CAJ/20', '92233745/11/CAJ/20', '2021-01-01', '2021-03-02', '121066000', '0', '0', '1', '0', '0'),
('58', '20', '30', '92233746/11/CAJ/20', '92233746/11/CAJ/20', '2021-01-01', '2021-03-02', '113685000', '0', '0', '1', '0', '0'),
('59', '20', '15', '041220/VIP/014', '041220/VIP/014', '2021-01-01', '2021-03-02', '18150000', '0', '0', '1', '0', '0'),
('60', '20', '32', '10220/PT.MIT/XII/20/RIERY', '10220/PT.MIT/XII/20/RIERY', '2021-01-01', '2021-03-02', '4345000', '0', '0', '1', '0', '0'),
('61', '20', '5', 'XXIV/CDI/XII/2020', 'XXIV/CDI/XII/2020', '2021-01-01', '2021-01-06', '20129200', '0', '0', '1', '0', '0'),
('62', '20', '4', '38/XII/2020', '38/XII/2020', '2021-01-06', '2021-01-13', '1290000', '0', '0', '1', '0', '0'),
('63', '20', '4', '39/XII/2020', '39/XII/2020', '2021-01-06', '2021-01-13', '200000', '0', '0', '1', '0', '0'),
('64', '20', '4', '41/XII/2020', '41/XII/2020', '2021-01-06', '2021-01-13', '1400000', '0', '0', '1', '0', '0'),
('65', '20', '4', '45/XII/2020', '45/XII/2020', '2021-01-06', '2021-01-13', '1745000', '0', '0', '1', '0', '0'),
('66', '20', '2', 'SX2091120	', 'SX2091120	', '2021-01-01', '2021-03-02', '0', '0', '0', '1', '0', '0'),
('67', '20', '36', 'SX2101120', 'SX2101120', '2021-01-01', '2021-03-02', '31350000', '0', '0', '1', '0', '0'),
('68', '20', '36', 'SX2091120	.', 'SX2091120.', '2021-01-01', '2021-03-02', '20900000', '0', '0', '1', '0', '0'),
('69', '20', '37', '118-1839/SJ-APK/XI/20', '18-1839/SJ-APK/XI/20', '2021-01-01', '2021-03-02', '3960000', '0', '0', '1', '0', '0');

### Structure of table `0_suppliers` ###

DROP TABLE IF EXISTS `0_suppliers`;

CREATE TABLE `0_suppliers` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `supp_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `supp_ref` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `supp_address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `gst_no` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `contact` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `supp_account_no` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `website` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bank_account` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `curr_code` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_terms` int(11) DEFAULT NULL,
  `tax_included` tinyint(1) NOT NULL DEFAULT '0',
  `dimension_id` int(11) DEFAULT '0',
  `dimension2_id` int(11) DEFAULT '0',
  `tax_group_id` int(11) DEFAULT NULL,
  `credit_limit` double NOT NULL DEFAULT '0',
  `purchase_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `payable_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `payment_discount_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `notes` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`supplier_id`),
  KEY `supp_ref` (`supp_ref`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_suppliers` ###

INSERT INTO `0_suppliers` VALUES
('1', 'TEST', 'TEST', '', '', '', '', '', '', '', 'IDR', '2', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('2', 'ADHI JAYA METALINDO, PT', 'ADHI JAYA METALINDO, PT', '', '', '', '', '', '', '', 'IDR', '2', '0', '0', '0', '1', '0', '1422', '2100', '7103', '', '0'),
('3', 'CHANDRA ASRI PETROCHEMICAL, PT', 'CHANDRA ASRI PETROCHEMICAL, PT', '', 'Jl. Let. Jend. S. Parman Kav 62-63\r\nJakarta 11410\r\nIndonesia', '', '', '', '', '', 'IDR', '4', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('4', 'INTERNAL SHOP', 'INTERNAL SHOP', '', '', '', '', '', '', '', 'IDR', '10', '0', '0', '0', '2', '0', '', '2100', '7103', '', '0'),
('5', 'CATERING H AWAN', 'CATERING H AWAN', '', '', '', '', '', '', '', 'IDR', '8', '0', '0', '0', '2', '0', '', '2100', '7103', '', '0'),
('6', 'CV CAHAYA TRANS', 'CV CAHAYA TRANS', '', '', '', '', '', '', '', 'IDR', '8', '0', '0', '0', '2', '0', '', '2100', '7103', '', '0'),
('7', 'MEGA RAMA PLASTINDO, PT', 'MEGA RAMA PLASTINDO, PT', '', 'Daan Mogot Arcadia Blok G 9 No 2/3\r\nBatu Ceper\r\nTangerang', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('8', 'PRAMMINDO WINDUKARYA CEMERLANG, PT', 'Prammindo Windukarya Cemerlang', '', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('9', 'EKA WARNA KIMIA, PT', 'EKA WARNA KIMIA, PT', '', 'WISMA BUMIPUTERA 9TH FLOOR\r\nJL. JEND. SUDIRMAN KAV. 75 JAKARTA 12910', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('10', 'SPEEDY PRINTING, CV', 'SPEEDY PRINTING, CV', 'Komp. Mutiara Taman Palem Blok C2/33, Jakarta Barat 11730 Indonesia', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('11', 'ANDALIRA CIPTA ABADI, PT', 'ANDALIRA CIPTA ABADI, PT', 'Kawasan Industi Jababeka 2, Jl. Industri Selatan 4 Blok GG No.5N Cikarang - Bekasi', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('12', 'SURYA TEKNIK MANDIRI, PD', 'SURYA TEKNIK MANDIRI, PD', 'Pertokoan Glodok Jaya Lt.4 Blok C No. 26&amp; 37 Jakarta', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '2', '0', '', '2100', '7103', '', '0'),
('13', 'VICTORY BLESSINGS INDONESIA, PT', 'VICTORY BLESSINGS INDONESIA', '', 'KAWASAN INDUSTRI JABABEKA V JL. SCIENCE TIMUR I BLOK A5J NO.5, CIKARANG TIMUR\r\nBEKASI JAWA BARAT 17530', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('14', 'DUNIA KIMIA JAYA, PT', 'DUNIA KIMIA JAYA', '', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('15', 'VICTORY INDAH PRIMA, PT', 'VICTORY INDAH PRIMA, PT', '', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('16', 'LIBRA MAS PERMATA, PT', 'LIBRA MAS PERMATA, PT', 'Jl. Jababeka VI Blok J No. 5D\r\nCikarang Industrial Estate', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('17', 'CHEMINDO INTERBUANA', 'CHEMINDO INTERBUANA', '', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('18', 'INTIDAYA DINAMIKA SEJATI, PT', 'INTIDAYA DINAMIKA SEJATI, PT', 'JL. Pangeran Jayakarta 123 No 41', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('19', 'YAMATOGAWA INDONESIA, PT', 'YAMATOGAWA', 'JL. MODERN INDUSTRI III NO.16\r\nKAWASAN INDUSTRI MODERN CIKANDE\r\nCIKANDE SERANG 42186', '', '01.071.552.2-052.000', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('20', 'REINPLAS METAL PRIMA, PT', 'REINPLAS METAL PRIMA, PT', '', '', '', '', '', '', '', 'IDR', '5', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('21', 'MULTI TEKNINDO NUSANTARA, PT', 'MULTI TEKNINDO NUSANTARA, PT', '', '', '', '', '', '', '', 'IDR', '5', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('22', 'ECOLAB TECHNOL0GIES AND SERVICES, PT', 'ECOLAB', '', 'JL. PAHLAWAN DESA KARANGASEM TIMUR\r\nCITEUREUP, BOGOR 16810\r\n', '010.002-18.82113707', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('23', 'ADONAI PRINTING', 'ADONAI PRINTING', '', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('24', 'BALINA AGUNG PERKASA,PT', 'BALINA AGUNG PERKASA,PT', 'CIPENDAWA RAYA NAROGONG KM.7, BEKASI RT/RW 004/006\r\nBOJONG MENTENG BEKASI 17117', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('25', 'SAMATOR GAS (JABABEKA 1), PT', 'SAMATOR GAS (JABABEKA 1), PT', 'JABABEKA 1', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('26', 'BATUMAS INDAH SUKSESMAKMUR', 'BATUMAS INDAH S', '', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('27', 'WIRA FLOPACK. CV', 'WIRA FLOPACK. CV', '', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('28', 'FAJAR JAYA ELEKTRO, CV', 'FAJAR JAYA ELEKTRO, CV', '', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('29', 'BUNGA PERMATA KURNIA, PT', 'BUNGA PERMATA KURNIA, PT', '', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('30', 'CITRA ABADI JAYA, CV', 'CITRA ABADI JAYA, CV', '', '', '02.963.612.3-086.000', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('31', 'YAKIN MAJU SENTOSA, PT', 'YAKIN MAJU SENTOSA, PT', 'Cikarang Branch\r\nJl. Jababeka VII G Block R No. 1E\r\nLemah Abang, Bekasi 17530', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('32', 'MAFATI INOVASI TECHNOLOGY, PT', 'MAFATI INOVASI TECHNOLOGY, PT', '', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('33', 'WIRAFLOPACK, CV', 'WIRAFLOPACK, CV', 'Jln. kebun Kelapa RT 02 RW 03\r\nTambun-Bekasi 17510', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('34', 'MITRA TEKNIK SEJAHTERA, CV', 'MITRA TEKNIK SEJAHTERA, CV', 'JL. Kancil Raya Blok a7 No. 50 Perum Cikarang Baru\r\nKabupaten Bekasi 17530', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('35', 'GLOBAL TECHNIC INDONESIA, CV', 'GLOBAL TECHNIC INDONESIA, CV', 'Jl. Raya Imam Bonjol\r\nRuko Telaga Pesona L 01/9\r\nTelaga Sakinah\r\nCikarang Barat\r\nBekasi 17520', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('36', 'PURYTEK TUNGGAL PRIMA, PT', 'PURYTEK TUNGGAL PRIMA, PT', '', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('37', 'ANUGERAH PUTRA KENCANA, PT', 'ANUGERAH PUTRA KENCANA, PT', '', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0'),
('38', 'SARANAPRIMA NUSANTARA ABADI, PT', 'SARANAPRIMA NUSANTARA ABADI, P', 'JL. Kp. Cikedokan RT 005 RW 012\r\nDesa Sukadanau, Cibitung\r\nBekasi Jawa Barat', '', '', '', '', '', '', 'IDR', '7', '0', '0', '0', '1', '0', '', '2100', '7103', '', '0');

### Structure of table `0_sys_prefs` ###

DROP TABLE IF EXISTS `0_sys_prefs`;

CREATE TABLE `0_sys_prefs` (
  `name` varchar(35) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `category` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `length` smallint(6) DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`name`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_sys_prefs` ###

INSERT INTO `0_sys_prefs` VALUES
('accounts_alpha', 'glsetup.general', 'tinyint', '1', '0'),
('accumulate_shipping', 'glsetup.customer', 'tinyint', '1', '0'),
('add_pct', 'setup.company', 'int', '5', '-1'),
('allow_negative_prices', 'glsetup.inventory', 'tinyint', '1', '1'),
('allow_negative_stock', 'glsetup.inventory', 'tinyint', '1', '1'),
('alternative_tax_include_on_docs', 'setup.company', 'tinyint', '1', ''),
('auto_curr_reval', 'setup.company', 'smallint', '6', '1'),
('bank_charge_act', 'glsetup.general', 'varchar', '15', '8101'),
('barcodes_on_stock', 'setup.company', 'tinyint', '1', '0'),
('base_sales', 'setup.company', 'int', '11', '1'),
('bcc_email', 'setup.company', 'varchar', '100', ''),
('company_logo_report', 'setup.company', 'tinyint', '1', '0'),
('coy_logo', 'setup.company', 'varchar', '100', ''),
('coy_name', 'setup.company', 'varchar', '60', ' PT. WIRA MUSTIKA ABADI'),
('coy_no', 'setup.company', 'varchar', '25', ''),
('creditors_act', 'glsetup.purchase', 'varchar', '15', '2100'),
('curr_default', 'setup.company', 'char', '3', 'IDR'),
('debtors_act', 'glsetup.sales', 'varchar', '15', '1200'),
('default_adj_act', 'glsetup.items', 'varchar', '15', '5104'),
('default_cogs_act', 'glsetup.items', 'varchar', '15', '5101'),
('default_credit_limit', 'glsetup.customer', 'int', '11', '1000000'),
('default_delivery_required', 'glsetup.sales', 'smallint', '6', '1'),
('default_dim_required', 'glsetup.dims', 'int', '11', '20'),
('default_inv_sales_act', 'glsetup.items', 'varchar', '15', '4100'),
('default_inventory_act', 'glsetup.items', 'varchar', '15', '1420'),
('default_loss_on_asset_disposal_act', 'glsetup.items', 'varchar', '15', '1100'),
('default_prompt_payment_act', 'glsetup.sales', 'varchar', '15', '4200'),
('default_quote_valid_days', 'glsetup.sales', 'smallint', '6', '30'),
('default_receival_required', 'glsetup.purchase', 'smallint', '6', '10'),
('default_sales_act', 'glsetup.sales', 'varchar', '15', '4100'),
('default_sales_discount_act', 'glsetup.sales', 'varchar', '15', '4200'),
('default_wip_act', 'glsetup.items', 'varchar', '15', '1415'),
('default_workorder_required', 'glsetup.manuf', 'int', '11', '20'),
('deferred_income_act', 'glsetup.sales', 'varchar', '15', ''),
('depreciation_period', 'glsetup.company', 'tinyint', '1', '1'),
('domicile', 'setup.company', 'varchar', '55', ''),
('email', 'setup.company', 'varchar', '100', ''),
('exchange_diff_act', 'glsetup.general', 'varchar', '15', '6300'),
('f_year', 'setup.company', 'int', '11', '4'),
('fax', 'setup.company', 'varchar', '30', '021-89109023'),
('freight_act', 'glsetup.customer', 'varchar', '15', '4250'),
('gl_closing_date', 'setup.closing_date', 'date', '8', '2017-12-31'),
('grn_clearing_act', 'glsetup.purchase', 'varchar', '15', '1416'),
('gst_no', 'setup.company', 'varchar', '25', '21.138.722.0-431.000'),
('legal_text', 'glsetup.customer', 'tinytext', '0', ''),
('loc_notification', 'glsetup.inventory', 'tinyint', '1', ''),
('login_tout', 'setup.company', 'smallint', '6', '1800'),
('no_customer_list', 'setup.company', 'tinyint', '1', '0'),
('no_item_list', 'setup.company', 'tinyint', '1', '0'),
('no_supplier_list', 'setup.company', 'tinyint', '1', '0'),
('no_zero_lines_amount', 'glsetup.sales', 'tinyint', '1', '1'),
('past_due_days', 'glsetup.general', 'int', '11', '30'),
('phone', 'setup.company', 'varchar', '30', '021-89109980 (Hunting)'),
('po_over_charge', 'glsetup.purchase', 'int', '11', '10'),
('po_over_receive', 'glsetup.purchase', 'int', '11', '10'),
('postal_address', 'setup.company', 'tinytext', '0', 'JL. KP. JARAKOSTA RT OO3 RW 002\r\nDESA SUKADANAU\r\nCIBITUNG (CIKARANG BARAT)\r\nBEKASI 17520'),
('print_dialog_direct', 'setup.company', 'tinyint', '1', '0'),
('print_invoice_no', 'glsetup.sales', 'tinyint', '1', '0'),
('print_item_images_on_quote', 'glsetup.inventory', 'tinyint', '1', ''),
('profit_loss_year_act', 'glsetup.general', 'varchar', '15', '9990'),
('pyt_discount_act', 'glsetup.purchase', 'varchar', '15', '7103'),
('ref_no_auto_increase', 'setup.company', 'tinyint', '1', '0'),
('retained_earnings_act', 'glsetup.general', 'varchar', '15', '3400'),
('round_to', 'setup.company', 'int', '5', '1'),
('shortname_name_in_list', 'setup.company', 'tinyint', '1', ''),
('show_po_item_codes', 'glsetup.purchase', 'tinyint', '1', ''),
('suppress_tax_rates', 'setup.company', 'tinyint', '1', ''),
('tax_algorithm', 'glsetup.customer', 'tinyint', '1', '1'),
('tax_last', 'setup.company', 'int', '11', '1'),
('tax_prd', 'setup.company', 'int', '11', '1'),
('time_zone', 'setup.company', 'tinyint', '1', '0'),
('use_dimension', 'setup.company', 'tinyint', '1', '1'),
('use_fixed_assets', 'setup.company', 'tinyint', '1', '1'),
('use_manufacturing', 'setup.company', 'tinyint', '1', '1'),
('version_id', 'system', 'varchar', '11', '2.4.1');

### Structure of table `0_tag_associations` ###

DROP TABLE IF EXISTS `0_tag_associations`;

CREATE TABLE `0_tag_associations` (
  `record_id` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `tag_id` int(11) NOT NULL,
  UNIQUE KEY `record_id` (`record_id`,`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_tag_associations` ###


### Structure of table `0_tags` ###

DROP TABLE IF EXISTS `0_tags`;

CREATE TABLE `0_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` smallint(6) NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_tags` ###


### Structure of table `0_tax_group_items` ###

DROP TABLE IF EXISTS `0_tax_group_items`;

CREATE TABLE `0_tax_group_items` (
  `tax_group_id` int(11) NOT NULL DEFAULT '0',
  `tax_type_id` int(11) NOT NULL DEFAULT '0',
  `tax_shipping` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tax_group_id`,`tax_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_tax_group_items` ###

INSERT INTO `0_tax_group_items` VALUES
('1', '1', '0');

### Structure of table `0_tax_groups` ###

DROP TABLE IF EXISTS `0_tax_groups`;

CREATE TABLE `0_tax_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_tax_groups` ###

INSERT INTO `0_tax_groups` VALUES
('1', 'Tax', '0'),
('2', 'Tax Exempt', '0');

### Structure of table `0_tax_types` ###

DROP TABLE IF EXISTS `0_tax_types`;

CREATE TABLE `0_tax_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rate` double NOT NULL DEFAULT '0',
  `sales_gl_code` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `purchasing_gl_code` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_tax_types` ###

INSERT INTO `0_tax_types` VALUES
('1', '10', '2201', '1504', 'PPN 10%', '0'),
('2', '2', '2204', '2204', 'PPh 23', '0');

### Structure of table `0_trans_tax_details` ###

DROP TABLE IF EXISTS `0_trans_tax_details`;

CREATE TABLE `0_trans_tax_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_type` smallint(6) DEFAULT NULL,
  `trans_no` int(11) DEFAULT NULL,
  `tran_date` date NOT NULL,
  `tax_type_id` int(11) NOT NULL DEFAULT '0',
  `rate` double NOT NULL DEFAULT '0',
  `ex_rate` double NOT NULL DEFAULT '1',
  `included_in_price` tinyint(1) NOT NULL DEFAULT '0',
  `net_amount` double NOT NULL DEFAULT '0',
  `amount` double NOT NULL DEFAULT '0',
  `memo` tinytext COLLATE utf8_unicode_ci,
  `reg_type` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Type_and_Number` (`trans_type`,`trans_no`),
  KEY `tran_date` (`tran_date`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_trans_tax_details` ###

INSERT INTO `0_trans_tax_details` VALUES
('1', '20', '1', '2021-01-04', '1', '10', '1', '0', '0', '0', 'INV/202012/0218', '1'),
('2', '20', '2', '2021-01-04', '1', '10', '1', '0', '46800000', '4680000', 'INV-202012/0218.', '1'),
('3', '20', '3', '2021-04-01', '2', '2', '1', '0', '0', '0', 'I/CDI/I/2021', NULL),
('4', '20', '5', '2021-01-04', '2', '2', '1', '0', '-18550000', '-371000', 'I/CDI/I/2021', NULL),
('5', '20', '6', '2021-01-05', '1', '10', '1', '0', '9337500', '933750', '7150048171', '1'),
('6', '20', '7', '2021-01-05', '1', '10', '1', '0', '33000000', '3300000', '221220/VIP/034', '1'),
('7', '20', '8', '2021-01-05', '0', '0', '1', '0', '200000', '0', '30/XII/2020', '1'),
('8', '20', '9', '2021-01-05', '0', '0', '1', '0', '400000', '0', '31/XII/2020', '1'),
('9', '20', '10', '2021-01-05', '0', '0', '1', '0', '675000', '0', '32/XII/2020', '1'),
('10', '20', '11', '2021-01-05', '0', '0', '1', '0', '1440000', '0', '33/XII/2020', '1'),
('11', '20', '12', '2021-01-05', '0', '0', '1', '0', '1200000', '0', '34/XII/2020', '1'),
('12', '20', '13', '2021-01-05', '0', '0', '1', '0', '400000', '0', '35/XII/2020', '1'),
('13', '20', '14', '2021-01-05', '0', '0', '1', '0', '3070000', '0', '36/XII/2020', '1'),
('14', '20', '15', '2021-01-05', '0', '0', '1', '0', '9445000', '0', '37/XII/2020', '1'),
('15', '20', '16', '2021-01-05', '0', '0', '1', '0', '450000', '0', '40/XII/2020', '1'),
('16', '20', '17', '2021-01-05', '0', '0', '1', '0', '4050000', '0', '42/XII/2020', '1'),
('17', '20', '18', '2021-01-05', '0', '0', '1', '0', '2250000', '0', '43/XII/2020', '1'),
('18', '20', '19', '2021-01-06', '0', '0', '1', '0', '2445000', '0', '44/XII/2020', '1'),
('19', '20', '20', '2021-01-06', '0', '0', '1', '0', '2981000', '0', '46/XII/2020', '1'),
('20', '20', '44', '2021-01-01', '1', '10', '1', '0', '11412500', '1141250', '7150047979', '1'),
('21', '20', '62', '2021-01-06', '0', '0', '1', '0', '1290000', '0', '38/XII/2020', '1'),
('22', '20', '63', '2021-01-06', '0', '0', '1', '0', '200000', '0', '39/XII/2020', '1'),
('23', '20', '64', '2021-01-06', '0', '0', '1', '0', '1400000', '0', '41/XII/2020', '1'),
('24', '20', '65', '2021-01-06', '0', '0', '1', '0', '1745000', '0', '45/XII/2020', '1'),
('25', '13', '1', '2021-01-04', '1', '10', '1', '0', '0', '0', 'SJ19182', NULL),
('26', '10', '1', '2021-01-07', '1', '10', '1', '0', '0', '0', '46596652/I/FA-WMI/2021', '0'),
('27', '13', '1', '2021-01-04', '1', '10', '1', '0', '91020384', '9102038.4', 'SJ19182', NULL),
('28', '10', '2', '2021-01-04', '1', '10', '1', '0', '91020384', '9102038.4', '46596652/I/FA-WMI/2021', '0'),
('29', '13', '2', '2021-01-04', '1', '10', '1', '0', '94558464', '9455846.4', 'SJ19181', NULL),
('30', '10', '3', '2021-01-07', '1', '10', '1', '0', '0', '0', '46596654/I/FA-WMI/2021', '0'),
('31', '10', '4', '2021-01-04', '1', '10', '1', '0', '94558464', '9455846.4', '46596654/I/FA-WMI/2021', '0'),
('32', '13', '3', '2021-01-04', '1', '10', '1', '0', '59033520', '5903352', 'sj19176', NULL),
('33', '10', '5', '2021-01-04', '1', '10', '1', '0', '59033520', '5903352', '46596655/I/FA-WMI/2021', '0'),
('34', '13', '4', '2021-01-04', '1', '10', '1', '0', '22388184', '2238818.4', 'SJ19177', NULL),
('35', '10', '6', '2021-01-07', '1', '10', '1', '0', '0', '0', '46596656/I/FA-WMI/2021', '0'),
('36', '13', '5', '2021-01-04', '1', '10', '1', '0', '14484979.2', '1448497.92', 'sj19174', NULL),
('37', '10', '7', '2021-01-07', '1', '10', '1', '0', '0', '0', '46596657/I/FA-WMI/2021', '0'),
('38', '10', '8', '2021-01-04', '1', '10', '1', '0', '22388184', '2238818.4', '46596656/I/FA-WMI/2021', '0'),
('39', '10', '9', '2021-01-04', '1', '10', '1', '0', '14484979.2', '1448497.92', '46596657/I/FA-WMI/2021', '0'),
('40', '13', '6', '2021-01-04', '1', '10', '1', '0', '14069145.6', '1406914.56', 'SJ19175', NULL),
('41', '10', '10', '2021-01-04', '1', '10', '1', '0', '14069145.6', '1406914.56', '46596658/I/FA-WMI/2021', '0'),
('42', '13', '7', '2021-01-04', '1', '10', '1', '0', '25227238.4', '2522723.84', 'sj19173', NULL),
('43', '10', '11', '2021-01-07', '1', '10', '1', '0', '0', '0', '46596659/I/FA-WMI/2021', '0'),
('44', '10', '12', '2021-01-04', '1', '10', '1', '0', '25227238.4', '2522723.84', '46596659/I/FA-WMI/2021', '0'),
('45', '13', '8', '2021-01-04', '1', '10', '1', '0', '23639616', '2363961.6', 'sj19179', NULL),
('46', '10', '13', '2021-01-04', '1', '10', '1', '0', '23639616', '2363961.6', '46596660/I/FA-WMI/2020', '0'),
('47', '13', '9', '2021-01-04', '1', '10', '1', '0', '22975680', '2297568', 'sj19178', NULL),
('48', '10', '14', '2021-01-04', '1', '10', '1', '0', '22975680', '2297568', '46596661/I/FA-WMI/2021', '0');

### Structure of table `0_useronline` ###

DROP TABLE IF EXISTS `0_useronline`;

CREATE TABLE `0_useronline` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` int(15) NOT NULL DEFAULT '0',
  `ip` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `file` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `timestamp` (`timestamp`),
  KEY `ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_useronline` ###


### Structure of table `0_users` ###

DROP TABLE IF EXISTS `0_users`;

CREATE TABLE `0_users` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `real_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `role_id` int(11) NOT NULL DEFAULT '1',
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_format` tinyint(1) NOT NULL DEFAULT '0',
  `date_sep` tinyint(1) NOT NULL DEFAULT '0',
  `tho_sep` tinyint(1) NOT NULL DEFAULT '0',
  `dec_sep` tinyint(1) NOT NULL DEFAULT '0',
  `theme` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `page_size` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'A4',
  `prices_dec` smallint(6) NOT NULL DEFAULT '2',
  `qty_dec` smallint(6) NOT NULL DEFAULT '2',
  `rates_dec` smallint(6) NOT NULL DEFAULT '4',
  `percent_dec` smallint(6) NOT NULL DEFAULT '1',
  `show_gl` tinyint(1) NOT NULL DEFAULT '1',
  `show_codes` tinyint(1) NOT NULL DEFAULT '0',
  `show_hints` tinyint(1) NOT NULL DEFAULT '0',
  `last_visit_date` datetime DEFAULT NULL,
  `query_size` tinyint(1) unsigned NOT NULL DEFAULT '10',
  `graphic_links` tinyint(1) DEFAULT '1',
  `pos` smallint(6) DEFAULT '1',
  `print_profile` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `rep_popup` tinyint(1) DEFAULT '1',
  `sticky_doc_date` tinyint(1) DEFAULT '0',
  `startup_tab` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `transaction_days` int(6) NOT NULL DEFAULT '30' COMMENT 'Transaction days',
  `save_report_selections` smallint(6) NOT NULL DEFAULT '0' COMMENT 'Save Report Selection Days',
  `use_date_picker` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Use Date Picker for all Date Values',
  `def_print_destination` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Default Report Destination',
  `def_print_orientation` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Default Report Orientation',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_users` ###

INSERT INTO `0_users` VALUES
('1', 'admin', '81dc9bdb52d04dc20036dbd8313ed055', 'Administrator', '2', '', 'adm@adm.com', 'C', '1', '0', '1', '1', 'default', 'Letter', '3', '2', '4', '1', '1', '0', '0', '2021-01-07 12:14:33', '100', '1', '1', '', '1', '0', 'system', '30', '0', '1', '0', '0', '0'),
('2', 'berta', 'b16fed0014b89dd63d63b9e0dfd80d98', 'berta', '6', '', NULL, 'C', '0', '0', '0', '0', 'default', 'Letter', '2', '2', '4', '1', '1', '0', '0', '2021-01-05 02:41:43', '10', '1', '1', '', '1', '0', 'system', '30', '0', '1', '0', '0', '0'),
('3', 'irene', '9b9da82350d473ada4ee19db5da89b6c', 'irene', '11', '', NULL, 'C', '0', '0', '0', '0', 'default', 'Letter', '2', '2', '4', '1', '1', '0', '0', '2020-12-15 11:06:40', '10', '1', '1', '', '1', '0', 'system', '30', '0', '1', '0', '0', '0'),
('4', 'aulia', '6dd8ca6d20941060cbcbe2e34c0ad860', 'aulia', '12', '', NULL, 'C', '0', '0', '0', '0', 'default', 'Letter', '2', '2', '4', '1', '1', '0', '0', '2020-12-15 11:04:25', '10', '1', '1', '', '1', '0', 'system', '30', '0', '1', '0', '0', '0');

### Structure of table `0_voided` ###

DROP TABLE IF EXISTS `0_voided`;

CREATE TABLE `0_voided` (
  `type` int(11) NOT NULL DEFAULT '0',
  `id` int(11) NOT NULL DEFAULT '0',
  `date_` date NOT NULL DEFAULT '0000-00-00',
  `memo_` tinytext COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `id` (`type`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_voided` ###

INSERT INTO `0_voided` VALUES
('10', '1', '2021-01-07', ''),
('10', '3', '2021-01-07', ''),
('10', '6', '2021-01-07', ''),
('10', '7', '2021-01-07', ''),
('10', '11', '2021-01-07', ''),
('20', '1', '2021-01-04', ''),
('20', '3', '2021-01-04', 'Document reentered.'),
('20', '27', '2021-01-06', ''),
('20', '66', '2021-01-07', '');

### Structure of table `0_wo_costing` ###

DROP TABLE IF EXISTS `0_wo_costing`;

CREATE TABLE `0_wo_costing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `workorder_id` int(11) NOT NULL DEFAULT '0',
  `cost_type` tinyint(1) NOT NULL DEFAULT '0',
  `trans_type` int(11) NOT NULL DEFAULT '0',
  `trans_no` int(11) NOT NULL DEFAULT '0',
  `factor` double NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_wo_costing` ###


### Structure of table `0_wo_issue_items` ###

DROP TABLE IF EXISTS `0_wo_issue_items`;

CREATE TABLE `0_wo_issue_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `issue_id` int(11) DEFAULT NULL,
  `qty_issued` double DEFAULT NULL,
  `unit_cost` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_wo_issue_items` ###


### Structure of table `0_wo_issues` ###

DROP TABLE IF EXISTS `0_wo_issues`;

CREATE TABLE `0_wo_issues` (
  `issue_no` int(11) NOT NULL AUTO_INCREMENT,
  `workorder_id` int(11) NOT NULL DEFAULT '0',
  `reference` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `loc_code` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workcentre_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`issue_no`),
  KEY `workorder_id` (`workorder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_wo_issues` ###


### Structure of table `0_wo_manufacture` ###

DROP TABLE IF EXISTS `0_wo_manufacture`;

CREATE TABLE `0_wo_manufacture` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workorder_id` int(11) NOT NULL DEFAULT '0',
  `quantity` double NOT NULL DEFAULT '0',
  `date_` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`),
  KEY `workorder_id` (`workorder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_wo_manufacture` ###


### Structure of table `0_wo_requirements` ###

DROP TABLE IF EXISTS `0_wo_requirements`;

CREATE TABLE `0_wo_requirements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `workorder_id` int(11) NOT NULL DEFAULT '0',
  `stock_id` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `workcentre` int(11) NOT NULL DEFAULT '0',
  `units_req` double NOT NULL DEFAULT '1',
  `unit_cost` double NOT NULL DEFAULT '0',
  `loc_code` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `units_issued` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `workorder_id` (`workorder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_wo_requirements` ###


### Structure of table `0_workcentres` ###

DROP TABLE IF EXISTS `0_workcentres`;

CREATE TABLE `0_workcentres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` char(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_workcentres` ###


### Structure of table `0_workorders` ###

DROP TABLE IF EXISTS `0_workorders`;

CREATE TABLE `0_workorders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wo_ref` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `loc_code` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `units_reqd` double NOT NULL DEFAULT '1',
  `stock_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `date_` date NOT NULL DEFAULT '0000-00-00',
  `type` tinyint(4) NOT NULL DEFAULT '0',
  `required_by` date NOT NULL DEFAULT '0000-00-00',
  `released_date` date NOT NULL DEFAULT '0000-00-00',
  `units_issued` double NOT NULL DEFAULT '0',
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  `released` tinyint(1) NOT NULL DEFAULT '0',
  `additional_costs` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `wo_ref` (`wo_ref`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `0_workorders` ###
