<?php
# UNTUK PAGING (PEMBAGIAN HALAMAN)
include"config2.php";
$row = 20;
$hal = isset($_GET['hal']) ? $_GET['hal'] : 0;
$pageSql = "SELECT * FROM 0_debtor_trans";
$pageQry = mysql_query($pageSql);
$jml	 = mysql_num_rows($pageQry);
$max	 = ceil($jml/$row);
?>

<table width="1509" border="0" cellpadding="2" cellspacing="1" class="table-border">
  <tr>
    <td colspan="2" align="right"><h3><b>daftar invoce</b></h3></td>
  </tr>

  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
<td colspan="2">
<table class="table-list" width="1471" border="0" cellspacing="1" cellpadding="2">
<tr>
<th width="328" align="left"><b>No. Invoice</b></th>
<th width="97" align="left"><b>Quantity</b></th>
<th width="93" align="left">harga satuan</th>
<th width="288" align="left">Nama Barang</th>
<th width="333" align="left">customer</th>
<th width="206" align="left">Payment Term</th>
<th width="90" align="left">Tanggal</th>
<th width="90" align="left">SO</th>
</tr>
<?php
include"config2.php";

$inv = "SELECT 0_debtor_trans.*, 0_debtor_trans_details.*, 0_cust_branch.*, 0_payment_terms.*
FROM 0_debtor_trans_details
join 0_debtor_trans on 0_debtor_trans_details.debtor_trans_no = 0_debtor_trans.trans_no
join 0_cust_branch on 0_cust_branch.debtor_no = 0_debtor_trans.debtor_no
join 0_payment_terms on 0_payment_terms.terms_indicator = 0_debtor_trans.payment_terms
where 
0_debtor_trans_details.debtor_trans_type=10 
AND 0_debtor_trans.type=10
AND 0_debtor_trans_details.unit_price !=0
AND 0_debtor_trans_details.quantity !=0
ORDER BY 0_debtor_trans.tran_date DESC  
LIMIT $hal, $row
";
$invrow = mysql_query($inv);
while ($invdata = mysql_fetch_array($invrow))
{
$data=$invdata['reference'];

?>
<tr>  
<td align="left"><b><a href="cetak.php?kode=<?php echo $data ?>"><?php echo $invdata['reference'];?></b></td>  
<td align="left"><b><?php echo $invdata['quantity']; ?></b></td>
<td align="left"><b><?php echo $invdata['unit_price']; ?></b></td>
<td align="left"><b><?php echo $invdata['description']; ?></b></td>
<td align="left"><b><?php echo $invdata['br_name']; ?></b></td>
<td align="left"><b><?php echo $invdata['terms']; ?></b></td>
<td align="left"><b><?php echo $invdata['tran_date']; ?></b></td>
<td align="left"><b><a href="cetak.php?kode1=<?php echo $data ?>"><?php echo $invdata['order_']; ?></b></td>
</tr>
<?php } ?>
</table></td>
</tr>
  <tr>
    <td width="473">Jumlah data<br><?php echo $jml; ?> </td>
    <td width="1025" align="right">halaman :
	<?php
	for ($h = 1; $h <= $max; $h++) {
		$list[$h] = $row * $h - $row;
		echo " <a href='?page=Kiriman-List&hal=$list[$h]'>$h</a> ";
	}

	?>
	</td>
  </tr>
</table>