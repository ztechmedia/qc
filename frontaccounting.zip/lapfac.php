<link rel="stylesheet" href="bootstrap-4.3.1-dist/css/bootstrap.min.css">
<?php
include_once "library/lib.php";
$tanggal_awal=$_POST['tanggal_awal'];
$tanggal_akhir=$_POST['tanggal_akhir'];

?>
<h2>LIST FAKTUR</h2>

<table width="100%" class="table" border="1"> <thead class="thead-dark">
  <tr>
	<th width="28">No.</th>
	<th width="20">kode jenis Transaksi</th>
	<th width="20">kode FP pennganti</th>
	<th width="20">Tax Number</th>
	<th width="76">Masa pajak</th>
	<th width="76">Tahun Pajak</th>
	<th width="76">Tgl Faktur</th>
	<th width="76">Cust. NPWP</th>
	<th width="70">Customer</th>
	<th width="100">Alamat</th>
	<th width="40">DPP IDR</th>
	<th width="53">PPN IDR</th>
	<th width="76">PPnBM (IDR)</th>
	<th width="76">Keterangan Tambahan</th>
	<th width="76">FG_Uang Muka</th>
	<th width="76">Uang Muka DPP</th>
	<th width="76">Uang Muka PPN</th>
	<th width="76">Uang Muka PPnBM</th>
 	<th width="76">Referensi</th>
    <th width="100">Material</th>
	<th width="70">Nama Barang</th>
	<th width="42">Harga</th>
	<th width="50">Quantity</th>
	<th width="50">Harga Total</th>
	<th width="50">Diskon</th>
	<th width="50">DPP</th>
	<th width="50">PPN</th>
	<th width="50">Tarif PPnBM</th>
	<th width="50">PPnBM</th>

  </tr>
  <?php

include"config2.php";
$rincian = "SELECT 0_debtor_trans.*, 0_debtor_trans_details.*, 0_cust_branch.*, 0_payment_terms.*
FROM 0_debtor_trans_details
join 0_debtor_trans on 0_debtor_trans_details.debtor_trans_no = 0_debtor_trans.trans_no
join 0_cust_branch on 0_cust_branch.debtor_no = 0_debtor_trans.debtor_no
join 0_payment_terms on 0_payment_terms.terms_indicator = 0_debtor_trans.payment_terms
where 
0_debtor_trans_details.debtor_trans_type=10 
AND 0_debtor_trans.type=10
AND 0_debtor_trans_details.unit_price !=0
AND 0_debtor_trans_details.quantity !=0
AND tran_date BETWEEN '$tanggal_awal' AND '$tanggal_akhir'
ORDER BY reference asc
";
$tmpQry = mysql_query($rincian);
while($tmpRow = mysql_fetch_array($tmpQry))
{
error_reporting(E_ALL & ~E_NOTICE);
$no++
?>
  <tr>
	<td><?php echo $no ?></td>
	<td>01</td>
	<td>0</td>
	<td></td>
	<td></td>
	<td></td>
	<td><?php echo IndonesiaTgl ($tmpRow['tran_date']); ?></td>
	<td></td>
	<td><?php echo $tmpRow['br_name'];?></td>
	<td></td>
	<td><?php echo number_format( $tmpRow['ov_amount'],2,',','.');?></td>
	<td><?php echo number_format( $tmpRow['ov_gst'],2,',','.');?></td>
	<td>0</td>
	<td></td>
	<td>0</td>
	<td>0</td>
	<td>0</td>
	<td>0</td>
	<td><?php echo $tmpRow['reference']; ?></td>	
	<td><?php echo $tmpRow['description'];?></td>
	<td><?php echo $tmpRow['description'];?></td>
	<td><?php echo $tmpRow['unit_price'];?></td>
	<td><?php echo number_format( $tmpRow['quantity'],2,',','.');?></td>
	
	<td><?php echo number_format($tmpRow['unit_price']*$tmpRow['quantity'],2,',','.'); ?></td>
	<td>0</td>
	<td><?php echo number_format($tmpRow['unit_price']*$tmpRow['quantity'],2,',','.'); ?></td>
	<td><?php echo number_format($tmpRow['unit_tax']*$tmpRow['quantity'],2,',','.'); ?></td>
	<td>0</td>
	<td>0</td>


    </tr>
  <?php } ?>
</table>
</div>