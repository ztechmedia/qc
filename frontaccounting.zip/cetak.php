<?php
//============================================================+
// File name   : example_005.php
// Begin       : 2008-03-04
// Last Update : 2013-05-14
//
// Description : Example 005 for TCPDF class
//               Multicell
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com LTD
//               www.tecnick.com
//               info@tecnick.com
//============================================================+

/**
 * Creates an example PDF TEST document using TCPDF
 * @package com.tecnick.tcpdf
 * @abstract TCPDF - Example: Multicell
 * @author Nicola Asuni
 * @since 2008-03-04
 */

// Include the main TCPDF library (search for installation path).

require_once('tcpdf/tcpdf.php');
$no = $_GET['kode'];
include"config2.php";
$inv = "SELECT 0_debtor_trans.*, 0_debtor_trans_details.*, 0_cust_branch.*, 0_payment_terms.*
FROM 0_debtor_trans_details
join 0_debtor_trans on 0_debtor_trans_details.debtor_trans_no = 0_debtor_trans.trans_no
join 0_cust_branch on 0_cust_branch.debtor_no = 0_debtor_trans.debtor_no
join 0_payment_terms on 0_payment_terms.terms_indicator = 0_debtor_trans.payment_terms
where 
0_debtor_trans_details.debtor_trans_type=10 
AND 0_debtor_trans.type=10
AND 0_debtor_trans_details.unit_price !=0
AND 0_debtor_trans_details.quantity !=0
AND reference='$no'";
$invrow = mysql_query($inv);
$invdata = mysql_fetch_array($invrow);


$no1= $invdata['order_'];
include"config2.php";
$so = "SELECT 0_sales_orders.order_no, 0_sales_orders.reference, 0_debtor_trans.order_
FROM 0_sales_orders
join 0_debtor_trans on 0_sales_orders.order_no = 0_debtor_trans.order_
where 
order_no = '$no1'
";
$dataso = mysql_query($so);
$sono = mysql_fetch_array($dataso);

$sj= $invdata['trans_no'];
include"config2.php";
$sjj = "SELECT 0_debtor_trans.trans_no, 0_debtor_trans.reference, 0_debtor_trans.type
FROM 0_debtor_trans
where 
0_debtor_trans.type=13
AND trans_no= '$sj'"
;
$datasj = mysql_query($sjj);
$nosj = mysql_fetch_array($datasj);



// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Nicola Asuni');
$pdf->SetTitle('TCPDF Example 005');
$pdf->SetSubject('TCPDF Tutorial');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 005', PDF_HEADER_STRING);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
    require_once(dirname(__FILE__).'/lang/eng.php');
    $pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

// set font
$pdf->SetFont('times', '', 12);

// add a page
$pdf->AddPage();

// set cell padding
$pdf->setCellPaddings(1, 1, 1, 1);

// set cell margins
$pdf->setCellMargins(1, 1, 1, 1);

// set color for background
$pdf->SetFillColor(255, 255, 127);

// MultiCell($w, $h, $txt, $border=0, $align='J', $fill=0, $ln=1, $x='', $y='', $reseth=true, $stretch=0, $ishtml=false, $autopadding=true, $maxh=0)

// set some text for example
$txt = 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.';

// Multicell test
$pdf->SetFont('times', '', 20);
$pdf->MultiCell(180, 30,'INVOICE', 0, 'C', 0, 1, '', '', true, 0, false, true, 40, 'B');
$pdf->SetFont('times', '', 9.5);
$pdf->MultiCell(105, 0.5, 'Customer', 'RLT', 'L', 0, 0, '', 67, true);
$pdf->MultiCell(105, 0.5, '', 'RL', 'L', 0, 0, '', 69, true);
$pdf->MultiCell(28,0.5, 'Invoice No. :','LT', 'L', 0, 0, '120', 67, true);
$pdf->MultiCell(48,0.5, $invdata['reference'], 'RT', 'L', 0, 0, 147, 67, true);

$pdf->MultiCell(48,0.5,'', 'R', 'L', 0, 0, 147, 69, true);
$pdf->MultiCell(28,0.5, '','L', 'L', 0, 0, '120', 69, true);

$pdf->MultiCell(105, 0.5, $invdata['br_name'],'RL', 'C', 0, 0, '', 74, true);

$pdf->MultiCell(105, 0.5,'','RL', 'C', 0, 0, '', 75, true);

$pdf->MultiCell(30,0.5, 'Date :', 'L', 'L', 0, 0, '120', 75, true);
$pdf->MultiCell(48,0.5, date('d F Y', strtotime ($invdata['tran_date'])), 'R', 'L', 0, 0, 147, 75, true);

$pdf->MultiCell(48,0.5, '', 'R', 'L', 0, 0, 147, 78, true);

$pdf->MultiCell(105, 1.5, $invdata['br_address'],'RLB', 'C', 0, 0, '', 81, true, 0, false, true, 18,9, 'M', true);
$pdf->MultiCell(30,0.5, 'PO No. :', 'L', 'L', 0, 0, 120, 84, true);
$pdf->MultiCell(48,0.5, $sono['reference'],'R', 'L', 0, 0, 147, 84, true);

$pdf->MultiCell(48,0.5, '','R', 'L', 0, 0, 147, 87, true);

$pdf->MultiCell(30,0.5, 'Term Payment :', 'LB', 'L', 0, 0, 120, 92.8, true);
$pdf->MultiCell(48,0.5, $invdata['terms'],'RB', 'L', 0, 0, 147, 92.8, true);


$pdf->MultiCell(10,11.7, 'No.', 1, 'L', 0, 0, 15, 103, true);
$pdf->MultiCell(80,11.7, 'Item Description', 1, 'C', 0, 0, 25, 103, true);
$pdf->MultiCell(25,11.7, 'Qty.', 1, 'C', 0, 0, 105, 103, true);
$pdf->MultiCell(10,11.7, 'Item Unit', 1, 'C', 0, 0, 130, 103, true);
$pdf->MultiCell(27,11.7, 'Unit Price IDR', 1, 'C', 0, 0, 140, 103, true);
$pdf->MultiCell(28,11.7, 'Total IDR', 1, 'C', 0, 0, 167, 103, true);

$no = $_GET['kode'];
include"config2.php";
$rincian = "SELECT 0_debtor_trans.*, 0_debtor_trans_details.*, 0_cust_branch.*, 0_payment_terms.*
FROM 0_debtor_trans_details
join 0_debtor_trans on 0_debtor_trans_details.debtor_trans_no = 0_debtor_trans.trans_no
join 0_cust_branch on 0_cust_branch.debtor_no = 0_debtor_trans.debtor_no
join 0_payment_terms on 0_payment_terms.terms_indicator = 0_debtor_trans.payment_terms
where 
0_debtor_trans_details.debtor_trans_type=10 
AND 0_debtor_trans.type=10
AND 0_debtor_trans_details.unit_price !=0
AND 0_debtor_trans_details.quantity !=0
AND reference='$no'";
$datarincian = mysql_query($rincian);
$nomor  = 0; 

while ($data = mysql_fetch_array($datarincian)) {
$nomor++;


	
	


	$angka = $invdata['ov_amount']+$invdata['ov_gst'];
// MultiCell($w, $h, $txt, $border=0, $align='J', $fill=0, $ln=1, $x='', $y='', $reseth=true, $stretch=0, $ishtml=false, $autopadding=true, $maxh=0)
// add a page
$pdf->setCellPaddings(1, 5, 1, 1);
$pdf->Cell(10, 0,'', 0, $ln=1, 'C', 0, '', 0, false, 'T', 'C');




$pdf->Cell(10, 0,$nomor, 0, $ln=0, 'C', 0, '', 0, false, 'T', 'C');
$pdf->Cell(50, 0,$data['description'], 0, $ln=0, 'L', 0, '', 0, false, 'T', 'C');
$pdf->Cell(50, 0,number_format ($data['quantity'],2,",","."), 0, $ln=0, 'R', 0, '', 0, false, 'T', 'C');
$pdf->Cell(8, 0,'Kg.', 0, $ln=0, 'R', 0, '', 0, false, 'T', 'C');
$pdf->Cell(25, 0,number_format ($data['unit_price'],2,",","."), 0, $ln=0, 'R', 0, '', 0, false, 'T', 'C');
$pdf->Cell(27, 0,number_format ($data['quantity']*$data['unit_price'],0,",","."), 0, $ln=0, 'R', 0, '', 0, false, 'T', 'C');
$pdf->setCellHeightRatio(0.5);

}

function penyebut($nilai) {
		$nilai = abs($nilai);
		$huruf = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
		$temp = "";
		if ($nilai < 12) {
			$temp = " ". $huruf[$nilai];
		} else if ($nilai <20) {
			$temp = penyebut($nilai - 10). " belas";
		} else if ($nilai < 100) {
			$temp = penyebut($nilai/10)." puluh". penyebut($nilai % 10);
		} else if ($nilai < 200) {
			$temp = " seratus" . penyebut($nilai - 100);
		} else if ($nilai < 1000) {
			$temp = penyebut($nilai/100) . " ratus" . penyebut($nilai % 100);
		} else if ($nilai < 2000) {
			$temp = " seribu" . penyebut($nilai - 1000);
		} else if ($nilai < 1000000) {
			$temp = penyebut($nilai/1000) . " ribu" . penyebut($nilai % 1000);
		} else if ($nilai < 1000000000) {
			$temp = penyebut($nilai/1000000) . " juta" . penyebut($nilai % 1000000);
		} else if ($nilai < 1000000000000) {
			$temp = penyebut($nilai/1000000000) . " milyar" . penyebut(fmod($nilai,1000000000));
		} else if ($nilai < 1000000000000000) {
			$temp = penyebut($nilai/1000000000000) . " trilyun" . penyebut(fmod($nilai,1000000000000));
		}     
		return $temp;
	}

	function terbilang($nilai) {
		if($nilai<0) {
			$hasil = "minus ". trim(penyebut($nilai));
		} else {
			$hasil = trim(penyebut($nilai));
		}     		
		return $hasil;
	}
	$angka = $invdata['ov_amount']+$invdata['ov_gst'];
	
$pdf->MultiCell(10,80, '', 1, 'L', 0, 0, 15, 115, true);
$pdf->MultiCell(80,80, '', 1, 'L', 0, 0, 25, 115, true);
$pdf->MultiCell(25,80, '', 1, 'R', 0, 0, 105, 115, true);
$pdf->MultiCell(10,80, '', 1, 'C', 0, 0, 130, 115, true);
$pdf->MultiCell(27,80, '', 1, 'R', 0, 0, 140, 115, true);
$pdf->MultiCell(28,80, '', 1, 'R', 0, 1, 167, 115, true);
$pdf->setCellHeightRatio(1);

$pdf->MultiCell(115,3,"", 1, 'L', 0, 0, 15, 195,true, 0, false, true, 20.8, 'M', true);
$pdf->MultiCell(37,1, 'Sub Total', 'L', 'L', 0, 0, 130, 192, true);
$pdf->MultiCell(28,1, number_format ($invdata['ov_amount'],0,",","."), 'R', 'R', 0, 1, 167, 192, true);

$pdf->MultiCell(37,1, 'PPN 10 %', 'L', 'L', 0, 0, 130, 199.5, true);
$pdf->MultiCell(28,1,number_format ($invdata['ov_gst'],0,",","."), 'R', 'R', 0, 1, 167, 199.5, true);

$pdf->MultiCell(37,1, 'Total Invoice', 'LB', 'L', 0, 0, 130, 206.4, true);
$pdf->MultiCell(28,1, number_format ($invdata['ov_amount']+$invdata['ov_gst'],0,",","."), 'BR', 'R', 0, 1, 167, 206.4, true);

$pdf->setCellHeightRatio(1.2);
$pdf->MultiCell(115,3, 'Pembayaran ditranfer ke rekening PT. WIRA MUSTIKA ABADI
PANIN Cab. Bekasi Square, Bekasi Timur
A/C   0165003585 (IDR)
MANDIRI Cab. Jakarta Graha Rekso, jakarta
A/C 125-00-1338983-8 (IDR)', 0, 'L', 0, 0, 15, 219,true);
$pdf->MultiCell(80,1,  'Bekasi    ' .date('d F Y', strtotime ( $invdata['tran_date'])), 0, 'L', 0, 0, 130, 219, true);
$pdf->MultiCell(37,1, 'HARRY HANDOKO', 0, 'L', 0, 0, 130, 260, true);




// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -



// move pointer to last page
$pdf->lastPage();

// ---------------------------------------------------------

//Close and output PDF document
$pdf->Output('example_005.pdf', 'I');
?>
//============================================================+
// END OF FILE
//============================================================+