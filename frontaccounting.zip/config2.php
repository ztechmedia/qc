<?php
mysql_connect("localhost", "root","charis838");
mysql_select_db("acc_wmi_2020_01")
?>
