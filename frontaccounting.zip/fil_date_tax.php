<?php
include"config2.php";
?>
  <link href="jquery-ui-1.11.4/smoothness/jquery-ui.css" rel="stylesheet" />
  <script src="jquery-ui-1.11.4/external/jquery/jquery.js"></script>
  <script src="jquery-ui-1.11.4/jquery-ui.js"></script>
  <script src="jquery-ui-1.11.4/jquery-ui.min.js"></script>
  <link rel="stylesheet" href="jquery-ui-1.11.4/jquery-ui.theme.css">
  <link rel="stylesheet" href="bootstrap-4.3.1-dist/css/bootstrap.min.css">
  <script>
     $(document).ready(function(){
    $("#tanggal").datepicker({
	dateFormat: "yy-mm-dd"
    })
   })
   $(document).ready(function(){
    $("#tanggal1").datepicker({
	dateFormat: "yy-mm-dd"
    })
   })
  </script>



<form action="lapfac.php" method="post">
<h3>LIST INVOICE</h3>
<div class="report2">
<table>
<td>Dari tanggal </td>
		<td><input type="text" name="tanggal_awal" id = "tanggal"></td>
		<td>s/d </td>
		<td><input type="text" name="tanggal_akhir" id = "tanggal1"></td>						
</tr>


<td><input type="submit" name="simpan" value="TAMPILKAN"></td>



</table>
</form>
</div>