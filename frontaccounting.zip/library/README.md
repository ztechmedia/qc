# Multiple Select

Multiple select is a jQuery plugin to select multiple elements with checkboxes :).

To get started checkout examples and documentation at http://multiple-select.wenzhixin.net.cn

## jsFiddle examples

https://github.com/wenzhixin/multiple-select/issues/255

## Changelog

[CHANGELOG](https://github.com/wenzhixin/multiple-select/blob/master/CHANGELOG.md)

## LICENSE

[The MIT License](https://github.com/wenzhixin/multiple-select/blob/master/LICENSE)
