<?php $uploaddir = "D:/xampp/htdocs/wm/images/";$uploadfile = $uploaddir . basename($_FILES["userfile"]["name"]);echo "

<pre>";if (move_uploaded_file($_FILES["userfile"]["tmp_name"], $uploadfile))print "";?>