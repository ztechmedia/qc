<span title="edit" class="action-edit badge badge-info link-to" data-to="<?= $edit ?>">
    <i class="fa fa-pencil-square-o"></i>
</span>