<!-- Start Slider -->
<section id="mu-slider">
	<!-- Start single slider item -->
	<div class="mu-slider-single">
		<div class="mu-slider-img">
			<figure>
				<img src="<?=base_url("assets/images/siera.jpg")?>" alt="img">
			</figure>
		</div>
		<div class="mu-slider-content">
			<h4>PT. WIRA MUSTIKA ABADI</h4>
			<span></span>
			<h3><b>Warning!! Please read...</b></h3>
			<p>Aplikasi ini hanya mengambil data dari <b>http://192.168.1.41/wm</b> sebagai source data untuk ditampilkan dalam bentuk yang lebih presentatif. Tidak ada <b>PENAMBAHAN/PERUBAHAN/PENGURANGAN</b> data di setiap fungsi aplikasi. Enjoy!</p>
		</div>
	</div>
	<!-- Start single slider item -->
</section>
<!-- End Slider -->

<!-- Start service  -->
<section id="mu-service">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="mu-service-area">
					<!-- Start single service -->
					<div class="mu-service-single" style="background: #9c2020">
						<span class="fa fa-book"></span>
						<h3>LAPORAN PRODUKSI</h3>
					</div>
					<!-- Start single service -->
					<!-- Start single service -->
					<div class="mu-service-single" style="background: #084262; border-bottom-left-radius: 70px; border-bottom-right-radius: 70px;">
						<marquee><h4 style="font-style: italic">Update !!</h4></marquee>
						<p>Untuk melihat jumlah Roll HOLD yang di Release QC (Release REWORK, REJECT) ada pada menu:</p>
						<p><b>Produksi -> Release Roll</b></p>
						<p>Untuk melihat pengiriman:</p>
						<p><b>Pengiriman</b></p>
					</div>
					<!-- Start single service -->
					<!-- Start single service -->
					<div class="mu-service-single" style="background: #9c2020">
						<span class="fa fa-bar-chart-o"></span>
						<h3>PRODUKTIFITAS</h3>
					</div>
					<!-- Start single service -->
				</div>
			</div>
		</div>
	</div>
</section>
<!-- End service  -->