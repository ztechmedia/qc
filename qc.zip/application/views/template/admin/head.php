<head>
    <!-- META SECTION -->
    <title class="page-title">Admin Panel - Quality Dept 2021</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="icon" href="<?= base_url("assets/joli/img/wira.png") ?>" type="image/x-icon" />
    <!-- END META SECTION -->

    <!-- CSS INCLUDE -->
    <link rel="stylesheet" type="text/css" id="theme" href="<?= base_url('assets/joli/css/theme-white.css') ?>" />
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/datatables/datatables.min.css') ?>" />
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/sweetalert/sweetalert.css') ?>" />
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/custom/css/loader.css') ?>" />
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/custom/css/style.css') ?>" />
    <!-- EOF CSS INCLUDE -->
</head>