<!-- START X-NAVIGATION VERTICAL -->
<ul class="x-navigation x-navigation-horizontal x-navigation-panel">
    <!-- TOGGLE NAVIGATION -->
    <li class="xn-icon-button">
        <a class="x-navigation-minimize"><span class="fa fa-dedent"></span></a>
    </li>
    <!-- END TOGGLE NAVIGATION -->

    <li class="xn-icon-button pull-right">
        <a class="action-logout" data-url="<?= base_url("logout") ?>" data-redirect="<?= base_url("login") ?>">
            <span class="fa fa-sign-out"></span></a>
    </li>
</ul>
<!-- END X-NAVIGATION VERTICAL -->